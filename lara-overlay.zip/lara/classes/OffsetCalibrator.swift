//
//  OffsetCalibrator.swift
//  lara
//
//  运行时偏移自校准
//
//  为什么要这个：
//    offsets.m 里的字段偏移是硬编码的，只对作者实测过的 iOS 版本成立。
//    在未验证的版本上（比如 27.x）用错偏移去写内核 → kernel panic。
//
//  这个模块的做法：
//    既然我们有内核读权限，而有些字段的值是「自证」的
//      p_pid    应该等于 getpid()
//      p_name   应该等于自己的进程名
//      p_textvp 指向的 vnode，其 v_name 应该等于自己的可执行文件名
//      p_fd     指向的 filedesc，其 fd_cdir 指向的 vnode，v_name 应该是 "/"
//    那就在 proc / thread 结构体里扫一遍，把这些字段的真实偏移找出来。
//
//  安全性：
//    全程只读（ds_kread*），不写内核。
//    每次解引用指针前先 ds_isvalid(addr)，非法地址直接跳过，不会 panic。
//    扫描范围限制在 proc / thread 本身这块合法分配内。
//
//  用法：
//    提权成功后调 OffsetCalibrator.calibrate()
//    拿到 Result 后：
//      · 如果关键字段都校准出来 → 用校准值覆盖 offsets.m 的全局变量
//      · 如果校准失败 → 说明连读都不对，不要继续写操作
//

import Foundation

struct CalibratedOffsets {
    // proc
    var p_proc_ro: UInt32?
    var p_pid: UInt32?
    var p_name: UInt32?
    var p_fd: UInt32?
    var p_textvp: UInt32?
    var p_flag: UInt32?
    // proc_ro
    var pr_task: UInt32?
    var p_ucred: UInt32?
    // task / thread
    var task_threads_next: UInt32?
    var t_tro: UInt32?
    var tro_proc: UInt32?
    var ctid: UInt32?
    var mutex: UInt32?

    var log: [String] = []

    /// 关键字段是否齐全（够不够继续往下走）
    var enough: Bool {
        p_pid != nil && p_name != nil && p_proc_ro != nil && pr_task != nil
    }

    /// 满分（连 vnode/fd/thread 都对上了）
    var full: Bool {
        enough && p_textvp != nil && p_fd != nil && t_tro != nil
    }

    func summary() -> String {
        var s: [String] = []
        func f(_ n: String, _ v: UInt32?) {
            s.append("\(n)=\(v.map { String(format: "0x%x", $0) } ?? "?")")
        }
        f("p_proc_ro", p_proc_ro); f("p_pid", p_pid); f("p_name", p_name)
        f("p_fd", p_fd); f("p_textvp", p_textvp); f("p_flag", p_flag)
        f("pr_task", pr_task); f("p_ucred", p_ucred)
        f("t_tro", t_tro); f("tro_proc", tro_proc)
        f("ctid", ctid); f("mutex", mutex)
        return s.joined(separator: " ")
    }
}

enum OffsetCalibrator {

    private static var mgr: laramgr { laramgr.shared }

    // MARK: - 安全读

    /// 带合法性校验的读。非法地址返回 nil，绝不 panic。
    static func safe64(_ addr: UInt64) -> UInt64? {
        guard addr != 0, ds_isvalid(addr) else { return nil }
        return UInt64(ds_kread64(addr))
    }

    static func safe32(_ addr: UInt64) -> UInt32? {
        guard addr != 0, ds_isvalid(addr) else { return nil }
        return UInt32(ds_kread32(addr))
    }

    static func safeBytes(_ addr: UInt64, _ n: Int) -> Data? {
        guard addr != 0, ds_isvalid(addr), n > 0, n <= 4096 else { return nil }
        var buf = [UInt8](repeating: 0, count: n)
        buf.withUnsafeMutableBytes { p in
            ds_kreadbuf(addr, p.baseAddress, UInt64(n))
        }
        let d = Data(buf)
        // 全 0 大概率是读到了空洞，视为失败
        if d.allSatisfy({ $0 == 0 }) { return nil }
        return d
    }

    /// 判断一个值像不像内核指针
    static func isKernelPtr(_ v: UInt64) -> Bool {
        guard v != 0 else { return false }
        // 内核 VA 高位置 1（0xffff...），且在合理区间
        return v >= KernelScan.kernelBase && v < KernelScan.kernelBase + 0x4000_0000
    }

    // MARK: - 主入口

    static func calibrate() -> CalibratedOffsets {
        var r = CalibratedOffsets()

        guard ds_is_ready() else {
            r.log.append("内核未就绪")
            return r
        }
        let proc = UInt64(ds_get_our_proc())
        let task = UInt64(ds_get_our_task())
        guard proc != 0 else {
            r.log.append("our_proc 为空")
            return r
        }
        let pid = UInt32(getpid())
        let myName = "Liebao"

        r.log.append(String(format: "proc=0x%llx task=0x%llx pid=%u", proc, task, pid))

        // ── 1. p_pid ────────────────────────────────────────
        // 在 0x40..0x200 里找值等于 getpid() 的 u32，按 4 字节对齐
        var pidHits: [UInt32] = []
        var off: UInt32 = 0x40
        while off < 0x200 {
            if let v = safe32(proc + UInt64(off)), v == pid {
                pidHits.append(off)
            }
            off += 4
        }
        if pidHits.count == 1 {
            r.p_pid = pidHits[0]
            r.log.append("p_pid 校准成 0x\(String(pidHits[0], radix: 16))（唯一命中）")
        } else if pidHits.count > 1 {
            // 多个命中：最可能是离已知值 0x60 最近的那个
            let best = pidHits.min { abs(Int($0) - 0x60) < abs(Int($1) - 0x60) }!
            r.p_pid = best
            r.log.append("p_pid 有 \(pidHits.count) 个候选 \(pidHits.map { String(format: "0x%x", $0) })，按邻近 0x60 取 0x\(String(best, radix: 16))")
        } else {
            r.log.append("p_pid 未命中（0x40..0x200 内没有等于 \(pid) 的值）")
        }

        // ── 2. p_name ───────────────────────────────────────
        // 找一段等于 "Liebao\0" 的字节
        let nameBytes = Array(myName.utf8)
        var nameOff: UInt32 = 0x100
        while nameOff < 0x800 {
            if let d = safeBytes(proc + UInt64(nameOff), 32) {
                let head = Array(d.prefix(nameBytes.count))
                if head == nameBytes {
                    let nextByte = d.count > nameBytes.count ? d[nameBytes.count] : 0
                    if nextByte == 0 {
                        r.p_name = nameOff
                        r.log.append("p_name 校准成 0x\(String(nameOff, radix: 16))")
                        break
                    }
                }
            }
            nameOff += 8
        }
        if r.p_name == nil { r.log.append("p_name 未命中（找不到 \"\(myName)\" 字节串）") }

        // ── 3. pr_task / p_proc_ro ──────────────────────────
        // 先校准 proc_ro->pr_task：在 0..0x60 里找指向 task 的指针
        // 但我们得先拿到 proc_ro。两条路互相依赖，所以先扫 proc 找 proc_ro 候选，
        // 再对每个候选在其内部扫 pr_task == task。
        var procRoCands: [UInt32] = []
        var o2: UInt32 = 0x10
        while o2 < 0x80 {
            if let ptr = safe64(proc + UInt64(o2)), isKernelPtr(ptr) {
                // 在这个候选 proc_ro 里找 pr_task
                var po: UInt32 = 0x10
                while po < 0x60 {
                    if let t = safe64(ptr + UInt64(po)), t == task, task != 0 {
                        if !procRoCands.contains(o2) { procRoCands.append(o2) }
                        r.pr_task = po
                        break
                    }
                    po += 8
                }
            }
            o2 += 8
        }
        if procRoCands.count == 1 {
            r.p_proc_ro = procRoCands[0]
            r.log.append("p_proc_ro 校准成 0x\(String(procRoCands[0], radix: 16))，pr_task=0x\(String(r.pr_task ?? 0, radix: 16))")
        } else if procRoCands.count > 1 {
            let best = procRoCands.min { abs(Int($0) - 0x18) < abs(Int($1) - 0x18) }!
            r.p_proc_ro = best
            r.log.append("p_proc_ro 有 \(procRoCands.count) 个候选，取邻近 0x18 的 0x\(String(best, radix: 16))")
        } else {
            r.log.append("p_proc_ro / pr_task 未校准（找不到指向 task 的指针链）")
        }

        // ── 4. p_textvp ─────────────────────────────────────
        // 扫 proc 后半段，找指向 vnode 且该 vnode 的 v_name == "Liebao" 的指针
        let vnameOff = UInt64(off_vnode_v_name)
        if vnameOff != 0 {
            var o3: UInt32 = 0x400
            while o3 < 0x780 {
                if let vp = safe64(proc + UInt64(o3)), isKernelPtr(vp) {
                    if let d = safeBytes(vp + vnameOff, 32) {
                        let head = Array(d.prefix(nameBytes.count))
                        if head == nameBytes {
                            r.p_textvp = o3
                            r.log.append("p_textvp 校准成 0x\(String(o3, radix: 16))（vnode.v_name == \(myName)）")
                            break
                        }
                    }
                }
                o3 += 8
            }
        }
        if r.p_textvp == nil { r.log.append("p_textvp 未校准") }

        // ── 5. p_fd ─────────────────────────────────────────
        // 扫 proc 中段，找指向 filedesc 且其 fd_cdir 指向的 vnode.v_name == "/" 的指针
        let cdirOff = UInt64(off_filedesc_fd_cdir)
        if cdirOff != 0 && vnameOff != 0 {
            var o4: UInt32 = 0x80
            while o4 < 0x240 {
                if let fp = safe64(proc + UInt64(o4)), isKernelPtr(fp) {
                    if let cd = safe64(fp + cdirOff), isKernelPtr(cd) {
                        if let d = safeBytes(cd + vnameOff, 4) {
                            if d.first == UInt8(ascii: "/") && d[1] == 0 {
                                r.p_fd = o4
                                r.log.append("p_fd 校准成 0x\(String(o4, radix: 16))（fd_cdir.v_name == /）")
                                break
                            }
                        }
                    }
                }
                o4 += 8
            }
        }
        if r.p_fd == nil { r.log.append("p_fd 未校准") }

        // ── 6. thread: t_tro / tro_proc / ctid / mutex ──────
        if task != 0, off_task_threads_next != 0 {
            if let q = safe64(task + UInt64(off_task_threads_next)), isKernelPtr(q) {
                var th = safe64(q) ?? 0
                if !isKernelPtr(th) { th = q }
                if isKernelPtr(th) {
                    let troProcOff = UInt64(off_thread_ro_tro_proc)
                    // t_tro
                    var to: UInt32 = 0x200
                    while to < 0x500 {
                        if let tro = safe64(th + UInt64(to)), isKernelPtr(tro) {
                            if troProcOff != 0, let tp = safe64(tro + troProcOff), tp == proc {
                                r.t_tro = to
                                r.tro_proc = UInt32(troProcOff)
                                r.log.append("t_tro 校准成 0x\(String(to, radix: 16))（tro_proc == our_proc）")
                                break
                            }
                        }
                        to += 8
                    }
                    // ctid：弱判定，取 0x300..0x500 里第一个 1..100000 的 u32
                    var co: UInt32 = 0x300
                    while co < 0x500 {
                        if let v = safe32(th + UInt64(co)), v > 0, v < 100000 {
                            r.ctid = co
                            r.log.append("ctid 候选 0x\(String(co, radix: 16)) = \(v)（弱判定）")
                            break
                        }
                        co += 4
                    }
                } else {
                    r.log.append("task_threads_next 解引用失败")
                }
            }
        }
        if r.t_tro == nil { r.log.append("t_tro 未校准") }

        // ── 7. 与硬编码值对比 ────────────────────────────────
        r.log.append("── 与 offsets.m 现值对比 ──")
        func cmp(_ n: String, _ cal: UInt32?, _ cur: UInt32) {
            if let c = cal {
                let same = (c == cur)
                r.log.append(String(format: "%@: 校准 0x%x / 现值 0x%x  %@",
                                    n, c, cur, same ? "一致" : "★不一致"))
            }
        }
        cmp("p_proc_ro", r.p_proc_ro, off_proc_p_proc_ro)
        cmp("p_pid", r.p_pid, off_proc_p_pid)
        cmp("p_fd", r.p_fd, off_proc_p_fd)
        cmp("p_textvp", r.p_textvp, off_proc_p_textvp)
        cmp("pr_task", r.pr_task, off_proc_ro_pr_task)
        cmp("t_tro", r.t_tro, off_thread_t_tro)

        mgr.logmsg("[cal] " + r.log.joined(separator: " | "))
        return r
    }

    /// 把校准结果写回 offsets.m 的全局变量（后续 darksword 就用新值）
    static func apply(_ r: CalibratedOffsets) {
        if let v = r.p_proc_ro { off_proc_p_proc_ro = v }
        if let v = r.p_pid { off_proc_p_pid = v }
        if let v = r.p_name { off_proc_p_name = v }
        if let v = r.p_fd { off_proc_p_fd = v }
        if let v = r.p_textvp { off_proc_p_textvp = v }
        if let v = r.p_flag { off_proc_p_flag = v }
        if let v = r.pr_task { off_proc_ro_pr_task = v }
        if let v = r.t_tro { off_thread_t_tro = v }
        if let v = r.tro_proc { off_thread_ro_tro_proc = v }
        if let v = r.ctid { off_thread_ctid = v }
        if let v = r.mutex { off_thread_mutex_lck_mtx_data = v }
        mgr.logmsg("[cal] 已把校准值写回全局偏移")
    }
}
