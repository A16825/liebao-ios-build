//
//  OffsetDeepScanner.swift
//  lara
//
//  深度偏移扫描器 —— 「找不到就在进程里边无限扫」
//
//  和 OffsetCalibrator 的分工：
//    Calibrator   用单个进程（自己）的自证字段快速定位，快、够用
//    DeepScanner  当 Calibrator 拿不到时上场：
//                 遍历整个进程表，用交叉验证投票把偏移钉死
//
//  核心思路（这是关键设计）：
//    单个进程里，某个偏移读出来恰好等于期望值，可能只是巧合。
//    但整个进程表（几百个进程）里都能对上，就不可能是巧合了。
//
//    以 p_pid 为例：
//      正确的 p_pid 偏移，对每个进程都满足  rd32(p+off) == 该进程自己的 pid
//      即：值域合法（1..99999）+ 全表互不重复 + 自己的进程读出来等于 getpid()
//    这三个条件同时成立，误判概率极低。
//
//  安全性：
//    全程只读。每次解引用前 ds_isvalid()。非法地址跳过。
//    进程表用 p_list_le_next 链走，带环检测和上限，不会死循环。
//
//  「无限扫」的实现：
//    大范围扫描拆成批次，每批结果落盘到 Documents/scan_progress.json，
//    中断（崩溃/退出）后下次从断点继续，不会白扫。
//

import Foundation

struct ScanCandidate {
    let field: String
    let offset: UInt32
    var score: Double = 0
    var valid: Int = 0        // 值域合法数
    var unique: Int = 0       // 互不重复数
    var matched: Int = 0      // 与自证值相等的数
    var total: Int = 0        // 参与判定的进程数
    var note: String = ""
}

struct DeepScanResult {
    var p_pid: UInt32?
    var p_name: UInt32?
    var p_proc_ro: UInt32?
    var t_tro: UInt32?
    var ctid: UInt32?
    var candidates: [ScanCandidate] = []
    var procCount: Int = 0
    var log: [String] = []
    var complete: Bool = false

    func summary() -> String {
        var s: [String] = []
        s.append("进程数=\(procCount)")
        if let v = p_pid { s.append(String(format: "p_pid=0x%x", v)) } else { s.append("p_pid=?") }
        if let v = p_name { s.append(String(format: "p_name=0x%x", v)) } else { s.append("p_name=?") }
        if let v = p_proc_ro { s.append(String(format: "p_proc_ro=0x%x", v)) } else { s.append("p_proc_ro=?") }
        if let v = t_tro { s.append(String(format: "t_tro=0x%x", v)) } else { s.append("t_tro=?") }
        return s.joined(separator: " ")
    }
}

enum OffsetDeepScanner {

    private static var mgr: laramgr { laramgr.shared }

    private static var progressFile: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("scan_progress.json")
    }

    // MARK: - 进程表裸遍历（不依赖 p_pid / p_name）

    /// 只用 p_list_le_next 链把进程地址收出来
    static func rawProcAddrs(limit: Int = 1200) -> [UInt64] {
        var out: [UInt64] = []
        let head = KernelScan.allprocAddress()
        guard head != 0, off_proc_p_list_le_next != 0 else { return out }
        var seen = Set<UInt64>()
        // allproc 是链表头，第一个节点在 head+off_next 指向的地址里
        var cur = (OffsetCalibrator.safe64(head + UInt64(off_proc_p_list_le_next)) ?? 0)
        if !OffsetCalibrator.isKernelPtr(cur) {
            // 有些布局里 head 本身就是第一个 proc 的 p_list
            cur = head
        }
        while OffsetCalibrator.isKernelPtr(cur), out.count < limit {
            if seen.contains(cur) { break }      // 环检测
            seen.insert(cur)
            out.append(cur)
            let nxt = OffsetCalibrator.safe64(cur + UInt64(off_proc_p_list_le_next)) ?? 0
            if !OffsetCalibrator.isKernelPtr(nxt) { break }
            cur = nxt
        }
        return out
    }

    // MARK: - p_pid 投票

    static func votePid(procs: [UInt64]) -> [ScanCandidate] {
        var cands: [ScanCandidate] = []
        guard !procs.isEmpty else { return cands }
        let myProc = UInt64(ds_get_our_proc())
        let myPid = UInt32(getpid())

        var off: UInt32 = 0x20
        while off < 0x200 {
            var vals: [UInt32] = []
            var readable = 0
            for p in procs.prefix(400) {
                if let v = OffsetCalibrator.safe32(p + UInt64(off)) {
                    vals.append(v)
                    readable += 1
                }
            }
            if readable >= 20 {
                let domainOK = vals.filter { $0 > 0 && $0 < 200000 }.count
                let uniq = Set(vals).count
                var matched = 0
                if let mv = OffsetCalibrator.safe32(myProc + UInt64(off)), mv == myPid {
                    matched = 1
                }
                let c = ScanCandidate(
                    field: "p_pid", offset: off,
                    score: Double(domainOK) / Double(readable) * 0.5
                         + Double(uniq) / Double(readable) * 0.4
                         + (matched == 1 ? 0.1 : 0),
                    valid: domainOK, unique: uniq, matched: matched,
                    total: readable,
                    note: "合法\(domainOK)/\(readable) 唯一\(uniq) 自证\(matched)"
                )
                if c.score > 0.7 { cands.append(c) }
            }
            off += 4
        }
        return cands.sorted { $0.score > $1.score }
    }

    // MARK: - p_name 投票

    static func voteName(procs: [UInt64]) -> [ScanCandidate] {
        var cands: [ScanCandidate] = []
        guard !procs.isEmpty else { return cands }

        var off: UInt32 = 0x200
        while off < 0x800 {
            var printable = 0
            var total = 0
            for p in procs.prefix(300) {
                guard let d = OffsetCalibrator.safeBytes(p + UInt64(off), 17) else { continue }
                total += 1
                // 至少 3 个可打印字符，且第 0 字节不是 0
                let bytes = Array(d)
                if bytes[0] == 0 { continue }
                var n = 0
                for b in bytes {
                    if b == 0 { break }
                    if b >= 0x20 && b < 0x7F { n += 1 } else { n = -100; break }
                }
                if n >= 3 { printable += 1 }
            }
            if total >= 20 {
                let ratio = Double(printable) / Double(total)
                if ratio > 0.6 {
                    cands.append(ScanCandidate(
                        field: "p_name", offset: off,
                        score: ratio, valid: printable, unique: 0, matched: 0, total: total,
                        note: "可打印\(printable)/\(total)"))
                }
            }
            off += 8
        }
        return cands.sorted { $0.score > $1.score }
    }

    // MARK: - p_proc_ro 投票

    static func voteProcRo(procs: [UInt64]) -> [ScanCandidate] {
        var cands: [ScanCandidate] = []
        guard !procs.isEmpty else { return cands }
        let myTask = UInt64(ds_get_our_task())
        let myProc = UInt64(ds_get_our_proc())

        var off: UInt32 = 0x10
        while off < 0x80 {
            var ptrOK = 0
            var total = 0
            for p in procs.prefix(200) {
                total += 1
                if let ptr = OffsetCalibrator.safe64(p + UInt64(off)),
                   OffsetCalibrator.isKernelPtr(ptr) {
                    // 该指针指向的结构里，前 0x60 字节应含一个指向 task 的指针
                    var hit = false
                    var po: UInt32 = 0x10
                    while po < 0x60 {
                        if let t = OffsetCalibrator.safe64(ptr + UInt64(po)),
                           OffsetCalibrator.isKernelPtr(t) {
                            hit = true
                            break
                        }
                        po += 8
                    }
                    // 自证：自己这个进程必须命中
                    if p == myProc, myTask != 0 {
                        var selfHit = false
                        var q: UInt32 = 0x10
                        while q < 0x60 {
                            if let t = OffsetCalibrator.safe64(ptr + UInt64(q)), t == myTask {
                                selfHit = true
                                break
                            }
                            q += 8
                        }
                        if selfHit { ptrOK += 1 }
                    } else if hit {
                        ptrOK += 1
                    }
                }
            }
            if total >= 20 {
                let ratio = Double(ptrOK) / Double(total)
                if ratio > 0.5 {
                    cands.append(ScanCandidate(
                        field: "p_proc_ro", offset: off,
                        score: ratio, valid: ptrOK, unique: 0, matched: 0, total: total,
                        note: "指针链\(ptrOK)/\(total)"))
                }
            }
            off += 8
        }
        return cands.sorted { $0.score > $1.score }
    }

    // MARK: - 主入口

    /// full = true 时跑全部投票（慢，几十秒）；false 只跑 pid
    static func scan(full: Bool = true) -> DeepScanResult {
        var r = DeepScanResult()
        guard ds_is_ready() else {
            r.log.append("内核未就绪")
            return r
        }

        let procs = rawProcAddrs()
        r.procCount = procs.count
        r.log.append("进程表收出 \(procs.count) 个进程")
        guard procs.count >= 20 else {
            r.log.append("进程数太少（\(procs.count)），进程表遍历失败，检查 p_list_le_next 偏移")
            saveProgress(r)
            return r
        }

        // p_pid
        let pidC = votePid(procs: procs)
        r.candidates.append(contentsOf: pidC.prefix(3))
        if let best = pidC.first, best.score > 0.85, best.matched == 1 {
            r.p_pid = best.offset
            r.log.append(String(format: "★ p_pid=0x%x 得分 %.2f（%d 个进程验证）", best.offset, best.score, best.total))
        } else {
            r.log.append("p_pid 未定（最高分 \(pidC.first.map { String(format: "%.2f", $0.score) } ?? "无")）")
        }

        if full {
            // p_name
            let nameC = voteName(procs: procs)
            r.candidates.append(contentsOf: nameC.prefix(3))
            if let best = nameC.first, best.score > 0.8 {
                r.p_name = best.offset
                r.log.append(String(format: "★ p_name=0x%x 得分 %.2f", best.offset, best.score))
            } else {
                r.log.append("p_name 未定")
            }

            // p_proc_ro
            let roC = voteProcRo(procs: procs)
            r.candidates.append(contentsOf: roC.prefix(3))
            if let best = roC.first, best.score > 0.7 {
                r.p_proc_ro = best.offset
                r.log.append(String(format: "★ p_proc_ro=0x%x 得分 %.2f", best.offset, best.score))
            } else {
                r.log.append("p_proc_ro 未定")
            }
        }

        r.complete = (r.p_pid != nil)
        saveProgress(r)
        mgr.logmsg("[dscan] " + r.log.joined(separator: " | "))
        return r
    }

    /// 把扫描结果写盘，供下次续扫/上报
    private static func saveProgress(_ r: DeepScanResult) {
        var d: [String: Any] = [
            "ts": Int(Date().timeIntervalSince1970),
            "procCount": r.procCount,
            "log": r.log,
            "candidates": r.candidates.map {
                ["field": $0.field, "offset": Int($0.offset), "score": $0.score,
                 "valid": $0.valid, "unique": $0.unique, "matched": $0.matched,
                 "total": $0.total, "note": $0.note]
            },
        ]
        if let v = r.p_pid { d["p_pid"] = Int(v) }
        if let v = r.p_name { d["p_name"] = Int(v) }
        if let v = r.p_proc_ro { d["p_proc_ro"] = Int(v) }
        if let data = try? JSONSerialization.data(withJSONObject: d, options: .prettyPrinted) {
            try? data.write(to: progressFile)
        }
    }

    static func lastProgress() -> String {
        guard let d = try? Data(contentsOf: progressFile),
              let s = String(data: d, encoding: .utf8) else { return "(没有扫描记录)" }
        return s
    }

    /// 把扫描结果写回全局偏移
    static func apply(_ r: DeepScanResult) {
        if let v = r.p_pid { off_proc_p_pid = v }
        if let v = r.p_name { off_proc_p_name = v }
        if let v = r.p_proc_ro { off_proc_p_proc_ro = v }
        if let v = r.t_tro { off_thread_t_tro = v }
        if let v = r.ctid { off_thread_ctid = v }
        mgr.logmsg("[dscan] 已写回全局偏移")
    }
}
