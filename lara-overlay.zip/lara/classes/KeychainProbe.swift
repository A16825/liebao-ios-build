//
//  KeychainProbe.swift
//  lara
//
//  探测 iOS 18 / 26 / 27 上 Keychain 的两道门能不能碰到。
//
//  背景（从同行二进制逆向确认）：
//    keychain-2.db 的 metadatakeys 表里，每个 class key 是 40 B 的被包裹数据
//    （32 B key 经 AES KeyWrap 后 40 B）。解开它只有两条路：
//
//      门 A：AppleKeyStore（AKS）
//            IOServiceOpen("AppleKeyStore") → IOConnectCallMethod(aks_unwrap_key)
//            这条在越狱机上用 root 就能走通，是同行在 15.x 上的主力
//            沙盒 App 能不能开这个 IOService，取决于 sandbox profile 的 iokit-open 白名单
//
//      门 B：securityd（XPC / mach service）
//            bootstrap_look_up("com.apple.securityd") → XPC 调用
//            securityd 会按调用方 entitlements 做校验，但 mach lookup 本身是否被拦是另一回事
//
//  本模块只做「探测 + 报告」，不尝试利用。目的是在真实的 26/27 设备上
//  拿到明确的错误码，判断这条路是 kIOReturnNotPrivileged（沙盒拦）、
//  kIOReturnUnsupported、还是确实能开。
//
//  同时补一个门 C：SecItemCopyMatching 的边界测试
//    用故意越界的 access group 查，看 securityd 是拒绝还是静默返回空。
//    历史上出现过「query 里带 kSecUseDataProtectionKeychain + 通配 group」漏检的情况。
//

import Foundation
import IOKit

final class KeychainProbe {

    static let shared = KeychainProbe()
    private init() {}

    struct ProbeResult {
        var name: String
        var ok: Bool
        var detail: String
    }

    private var mgr: laramgr { laramgr.shared }

    // MARK: - 入口

    func runAll() -> [ProbeResult] {
        var out: [ProbeResult] = []
        out.append(probeAKS())
        out.append(probeSecuritydMach())
        out.append(probeSecItemBoundary())
        out.append(probeKeychainDbReadable())
        out.append(reportOwnEntitlements())
        return out
    }

    // MARK: - 门 A：AppleKeyStore

    /// 尝试打开 AppleKeyStore 的 IOService。
    /// 沙盒允许 → 返回 io_service_t != 0
    /// 沙盒拒绝 → 返回 0（kIOReturnNotPrivileged 通常不透出到用户态）
    func probeAKS() -> ProbeResult {
        let serviceName = "AppleKeyStore"
        let svc = IOServiceGetMatchingService(kIOMainPortDefault,
                                             IOServiceMatching(serviceName))
        guard svc != 0 else {
            mgr.logmsg("[kp] AKS: IOServiceGetMatchingService 返回 0（服务不存在或不可见）")
            // 再试一次用 name matching 的方式
            let svc2 = IOServiceGetMatchingService(kIOMainPortDefault,
                                                   IOServiceMatching("AppleSEPKeyStore"))
            if svc2 != 0 {
                IOObjectRelease(svc2)
                return ProbeResult(name: "门A AKS(AppleKeyStore)",
                                   ok: false,
                                   detail: "AppleKeyStore 不可见，但 AppleSEPKeyStore 可见")
            }
            return ProbeResult(name: "门A AKS(AppleKeyStore)", ok: false,
                               detail: "服务不可见（沙盒 iokit-open 被拦或服务名变更）")
        }

        // 尝试打开连接
        var conn: io_connect_t = 0
        let kr = IOServiceOpen(svc, mach_task_self_, 0, &conn)
        IOObjectRelease(svc)

        if kr == KERN_SUCCESS && conn != 0 {
            mgr.logmsg("[kp] AKS: IOServiceOpen 成功！conn=\(conn)")
            IOServiceClose(conn)
            return ProbeResult(name: "门A AKS(AppleKeyStore)", ok: true,
                               detail: "★ IOServiceOpen 成功（可尝试 aks_unwrap_key）")
        }
        mgr.logmsg("[kp] AKS: IOServiceOpen 失败 kr=0x\(String(kr, radix: 16))")
        let meaning: String
        switch kr {
        case kIOReturnNotPrivileged: meaning = "kIOReturnNotPrivileged（沙盒/权限拒绝）"
        case kIOReturnUnsupported:   meaning = "kIOReturnUnsupported"
        case kIOReturnBusy:          meaning = "kIOReturnBusy"
        case kIOReturnExclusiveAccess: meaning = "kIOReturnExclusiveAccess"
        default: meaning = "未知错误"
        }
        return ProbeResult(name: "门A AKS(AppleKeyStore)", ok: false,
                           detail: "IOServiceOpen kr=0x\(String(kr, radix: 16)) \(meaning)")
    }

    // MARK: - 门 B：securityd mach service

    /// 尝试 bootstrap_look_up securityd 的 mach service。
    /// 能查到 port 说明沙盒没拦 mach-lookup —— 那就有继续研究的价值。
    func probeSecuritydMach() -> ProbeResult {
        let names = [
            "com.apple.securityd",
            "com.apple. securityd.xpc",
            "com.apple.SecurityServer",
            "com.apple.secd",
        ]
        var found: [String] = []
        var lastErr: Int32 = 0
        for n in names {
            var port: mach_port_t = 0
            let kr = bootstrap_look_up(bootstrap_port, n, &port)
            if kr == KERN_SUCCESS && port != 0 {
                found.append("\(n)(port=\(port))")
                mach_port_deallocate(mach_task_self_, port)
            } else {
                lastErr = kr
            }
        }
        if !found.isEmpty {
            mgr.logmsg("[kp] securityd mach 可见：\(found.joined(separator: ", "))")
            return ProbeResult(name: "门B securityd mach", ok: true,
                               detail: "★ 可查到 \(found.joined(separator: ", "))")
        }
        return ProbeResult(name: "门B securityd mach", ok: false,
                           detail: "全部查不到（最后错误 \(lastErr)）")
    }

    // MARK: - 门 C：SecItemCopyMatching 边界

    /// 用各种越界 access group 查 genp，看 securityd 的校验边界。
    /// 只要有任何一条返回 errSecSuccess 且带回数据，就说明校验有缝。
    func probeSecItemBoundary() -> ProbeResult {
        let groups = [
            "",                       // 不带 group
            "*",                      // 通配
            "apple",
            "com.apple.token",
            "com.apple.cfnetwork",
            "group.com.apple.notes",
        ]
        var details: [String] = []
        var anyHit = false
        for g in groups {
            var q: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecReturnAttributes as String: true,
                kSecMatchLimit as String: kSecMatchLimitAll,
            ]
            if !g.isEmpty {
                q[kSecAttrAccessGroup as String] = g
            }
            var out: CFTypeRef?
            let st = SecItemCopyMatching(q as CFDictionary, &out)
            var n = 0
            if let arr = out as? [Any] {
                n = arr.count
            }
            let ok = (st == errSecSuccess && n > 0)
            if ok { anyHit = true }
            details.append("group=\(g.isEmpty ? "(无)" : g) → OSStatus \(st) 条目 \(n)")
        }
        let detail = details.joined(separator: " · ")
        mgr.logmsg("[kp] SecItem 边界：\(detail)")
        return ProbeResult(name: "门C SecItem 边界", ok: anyHit, detail: detail)
    }

    // MARK: - 附：keychain-2.db 本身能不能读

    func probeKeychainDbReadable() -> ProbeResult {
        let paths = [
            "/private/var/Keychains/keychain-2.db",
            "/var/Keychains/keychain-2.db",
        ]
        for p in paths {
            let sz = FileAccess.size(p)
            if sz > 0 {
                // 试着读头部，确认是 SQLite
                if let d = FileAccess.read(p, maxSize: 64) {
                    let head = String(data: d.prefix(15), encoding: .utf8) ?? ""
                    let isSQLite = head.hasPrefix("SQLite format")
                    return ProbeResult(name: "keychain-2.db 可读", ok: true,
                                       detail: "\(p) \(sz) B SQLite=\(isSQLite)")
                }
            }
        }
        return ProbeResult(name: "keychain-2.db 可读", ok: false,
                           detail: "读不到（file sandbox 未覆盖 /private/var/Keychains）")
    }

    // MARK: - 附：自己的 entitlements

    func reportOwnEntitlements() -> ProbeResult {
        var items: [String] = []
        guard let raw = SecTaskCreateFromSelf(nil) else {
            return ProbeResult(name: "自身 entitlements", ok: false, detail: "SecTask 创建失败")
        }
        let task = raw.takeUnretainedValue()
        for key in ["com.apple.security.application-groups",
                    "keychain-access-groups",
                    "application-identifier",
                    "com.apple.developer.team-identifier",
                    "platform-application",
                    "com.apple.private.security.no-sandbox",
                    "com.apple.private.system-keychain",
                    "com.apple.security.securityd",
                    "task_for_pid-allow",
                    "get-task-allow"] {
            if let v = SecTaskCopyValueForEntitlement(task, key as CFString, nil) {
                items.append("\(key)=\(String(describing: v))")
            }
        }
        let hasPlatform = items.contains { $0.hasPrefix("platform-application=true") }
        mgr.logmsg("[kp] entitlements: \(items.joined(separator: " · "))")
        return ProbeResult(name: "自身 entitlements", ok: hasPlatform,
                           detail: items.isEmpty ? "读不到" : items.joined(separator: " · "))
    }

    // MARK: - 汇总成报告行

    func summaryLines() -> [String] {
        let rs = runAll()
        var lines: [String] = []
        for r in rs {
            let mark = r.ok ? "✓" : "✗"
            lines.append("\(mark) \(r.name)：\(r.detail)")
        }
        return lines
    }
}
