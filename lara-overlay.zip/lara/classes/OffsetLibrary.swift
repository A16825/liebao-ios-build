//
//  OffsetLibrary.swift
//  lara
//
//  自我迭代的偏移来源系统（三级 + 双向回流）
//
//  设计目标（用户要求）：
//    · 现成的马上找到        → 本地缓存 + 服务端库，命中即用
//    · 找不到的自己扫        → OffsetCalibrator 自证扫描
//    · 死磕到底              → OffsetScanner 大范围分批扫（可断点续扫）
//    · 结果都回传            → 成功失败都上报，服务端越积越准
//    · 换任何目标都能复用    → 这套骨架与具体漏洞无关
//
//  三级来源：
//    ① 本地缓存   UserDefaults，key = 系统版本|CPU家族|build
//    ② 服务端库   GET  /dl/offsets.php?k=<key>
//    ③ 内置硬编码 offsets.m 的现值（兜底）
//  另有一路补充：
//    ④ 运行时自校准 OffsetCalibrator（提权后可用，能纠正上面三级的错误）
//
//  回流：
//    report() 把 {设备, 版本, build, 各级来源, 校准结果, 扫描证据, 失败原因}
//    打包 POST 到 /dl/offsets.php
//

import Foundation
import UIKit
import Combine

// MARK: - 数据结构

struct OffsetEntry: Codable {
    var key: String = ""
    var ios: String = ""
    var cpu: String = ""
    var build: String = ""
    var offsets: [String: UInt32] = [:]
    var confidence: String = "unknown"   // high / medium / low / guess
    var source: String = ""              // calibrate / server / derive / manual
    var sampleCount: Int = 0
    var updated: String = ""
    var note: String = ""
}

struct OffsetResolveResult {
    enum Tier: String {
        case localCache = "本地缓存"
        case server = "服务端库"
        case hardcoded = "内置硬编码"
        case none = "无"
    }
    var tier: Tier = .none
    var entry: OffsetEntry?
    var detail: String = ""
}

// MARK: - 库

final class OffsetLibrary {

    static let shared = OffsetLibrary()

    /// 读：静态 JSON（这台服务器有 JS 反爬层，只有静态文件和 POST 能直通）
    var libraryURL: String {
        get { UserDefaults.standard.string(forKey: "offset.libraryURL") ?? "http://www.vivi9.top/dl/offsets.json" }
        set { UserDefaults.standard.set(newValue, forKey: "offset.libraryURL") }
    }

    /// 写：POST 到 PHP
    var reportURL: String {
        get { UserDefaults.standard.string(forKey: "offset.reportURL") ?? "http://www.vivi9.top/dl/offsets.php" }
        set { UserDefaults.standard.set(newValue, forKey: "offset.reportURL") }
    }

    var enabled: Bool {
        get {
            let v = UserDefaults.standard.object(forKey: "offset.libraryEnabled")
            return v == nil ? true : UserDefaults.standard.bool(forKey: "offset.libraryEnabled")
        }
        set { UserDefaults.standard.set(newValue, forKey: "offset.libraryEnabled") }
    }

    private var mgr: laramgr { laramgr.shared }

    // MARK: key

    /// 版本 + CPU 家族 + build 三元组
    func currentKey() -> String {
        let v = UIDevice.current.systemVersion
        let cpu = Self.cpuFamilyName()
        let build = Self.osBuild()
        return "\(v)|\(cpu)|\(build)"
    }

    static func cpuFamilyName() -> String {
        var family: UInt32 = 0
        var size = MemoryLayout<UInt32>.size
        sysctlbyname("hw.cpufamily", &family, &size, nil, 0)
        // 常见取值 → 可读名
        let map: [UInt32: String] = [
            0x1b588bb3: "A14",   // FIRESTORM_ICESTORM
            0xda33d83d: "A15",   // BLIZZARD_AVALANCHE
            0x8765edea: "A16",   // COLL
            0x4e5f1a3b: "A17",   // IBIZA
            0x8c7b0a2e: "A18",   // TUPAI
        ]
        if let n = map[family] { return n }
        var machine = "?"
        var msize = 64
        var buf = [CChar](repeating: 0, count: msize)
        if sysctlbyname("hw.machine", &buf, &msize, nil, 0) == 0 {
            machine = String(cString: buf)
        }
        return "\(machine)_\(String(family, radix: 16))"
    }

    static func osBuild() -> String {
        var size = 0
        if sysctlbyname("kern.osversion", nil, &size, nil, 0) != 0 { return "?" }
        var buf = [CChar](repeating: 0, count: max(size, 1))
        if sysctlbyname("kern.osversion", &buf, &size, nil, 0) != 0 { return "?" }
        return String(cString: buf)
    }

    // MARK: 本地缓存

    private func cacheKey(_ k: String) -> String { "offset.cache." + k }

    func loadLocal(_ k: String) -> OffsetEntry? {
        guard let d = UserDefaults.standard.data(forKey: cacheKey(k)) else { return nil }
        return try? JSONDecoder().decode(OffsetEntry.self, from: d)
    }

    func saveLocal(_ e: OffsetEntry) {
        if let d = try? JSONEncoder().encode(e) {
            UserDefaults.standard.set(d, forKey: cacheKey(e.key))
            mgr.logmsg("[olib] 已缓存 \(e.key) confidence=\(e.confidence)")
        }
    }

    // MARK: 三级解析

    func resolve() -> OffsetResolveResult {
        let key = currentKey()
        mgr.logmsg("[olib] 查询 key=\(key)")

        // ① 本地缓存
        if let e = loadLocal(key), e.confidence == "high" || e.confidence == "medium" {
            mgr.logmsg("[olib] ★ 本地缓存命中，\(e.offsets.count) 个偏移 confidence=\(e.confidence)")
            return OffsetResolveResult(tier: .localCache, entry: e,
                                       detail: "\(e.offsets.count) 项 / \(e.confidence) / \(e.source)")
        }

        // ② 服务端
        if enabled, let e = fetchServer(key) {
            if e.confidence == "high" || e.confidence == "medium" {
                mgr.logmsg("[olib] ★ 服务端命中，\(e.offsets.count) 个偏移")
                saveLocal(e)
                return OffsetResolveResult(tier: .server, entry: e,
                                           detail: "\(e.offsets.count) 项 / \(e.confidence) / \(e.source)")
            }
            mgr.logmsg("[olib] 服务端有记录但置信度低（\(e.confidence)），不采用")
        }

        return OffsetResolveResult(tier: .hardcoded, entry: nil,
                                   detail: "没有可用记录，用内置硬编码值")
    }

    /// 拉整个偏移库（静态 JSON），再按 key 取出自己那一条
    private func fetchServer(_ key: String) -> OffsetEntry? {
        guard let url = URL(string: libraryURL) else { return nil }
        var req = URLRequest(url: url)
        req.timeoutInterval = 15
        req.setValue("lara-offset/2", forHTTPHeaderField: "User-Agent")
        req.cachePolicy = .reloadIgnoringLocalCacheData

        let sem = DispatchSemaphore(value: 0)
        var out: Data?
        URLSession.shared.dataTask(with: req) { d, r, e in
            out = d
            if let he = e { self.mgr.logmsg("[olib] 拉库失败 \(he.localizedDescription)") }
            sem.signal()
        }.resume()
        _ = sem.wait(timeout: .now() + 20)
        guard let d = out, d.count > 2 else { return nil }

        // 期望结构：{"version":2,"entries":{"<key>":{...}}}
        guard let root = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else {
            mgr.logmsg("[olib] 库格式不对（可能被反爬层替换成 HTML）")
            return nil
        }
        guard let entries = root["entries"] as? [String: Any] else {
            mgr.logmsg("[olib] 库里没有 entries")
            return nil
        }
        guard let raw = entries[key] else {
            mgr.logmsg("[olib] 库里没有 \(key)（共 \(entries.count) 条）")
            return nil
        }
        guard let one = try? JSONSerialization.data(withJSONObject: raw),
              let e = try? JSONDecoder().decode(OffsetEntry.self, from: one) else {
            return nil
        }
        return e
    }

    // MARK: 回流：上报

    /// 把这一轮的解析 + 校准 + 扫描结果打包上报
    func report(ios: String, cpu: String, build: String,
                tier: String, used: [String: UInt32],
                calibrated: [String: UInt32],
                mismatched: [String],
                stageReached: Int, ok: Bool,
                scanLog: String) {
        let key = "\(ios)|\(cpu)|\(build)"
        let payload: [String: Any] = [
            "action": "report",
            "key": key,
            "ios": ios,
            "cpu": cpu,
            "build": build,
            "tier": tier,
            "used": used.mapValues { Int($0) },
            "calibrated": calibrated.mapValues { Int($0) },
            "mismatched": mismatched,
            "stageReached": stageReached,
            "ok": ok,
            "device": KeychainDumpManager.sysctlString("hw.machine") ?? "?",
            "scanLog": String(scanLog.prefix(4000)),
            "ts": Int(Date().timeIntervalSince1970),
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: payload) else { return }
        guard let url = URL(string: reportURL) else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("lara-offset/2", forHTTPHeaderField: "User-Agent")
        req.timeoutInterval = 20
        URLSession.shared.uploadTask(with: req, from: body) { d, r, e in
            let code = (r as? HTTPURLResponse)?.statusCode ?? -1
            self.mgr.logmsg("[olib] 上报 HTTP \(code) \(e == nil ? "" : (e?.localizedDescription ?? ""))")
        }.resume()
    }

    /// 把校准结果作为「高置信」写进本地缓存（下次启动直接命中）
    func promoteFromCalibration(_ cal: CalibratedOffsets) {
        let key = currentKey()
        var e = OffsetEntry()
        e.key = key
        e.ios = UIDevice.current.systemVersion
        e.cpu = Self.cpuFamilyName()
        e.build = Self.osBuild()
        e.source = "calibrate"
        e.confidence = cal.full ? "high" : (cal.enough ? "medium" : "low")
        e.updated = ISO8601DateFormatter().string(from: Date())
        e.sampleCount = 1
        func put(_ n: String, _ v: UInt32?) { if let v { e.offsets[n] = v } }
        put("p_proc_ro", cal.p_proc_ro)
        put("p_pid", cal.p_pid)
        put("p_name", cal.p_name)
        put("p_fd", cal.p_fd)
        put("p_textvp", cal.p_textvp)
        put("pr_task", cal.pr_task)
        put("t_tro", cal.t_tro)
        put("tro_proc", cal.tro_proc)
        put("ctid", cal.ctid)
        put("mutex", cal.mutex)
        if !e.offsets.isEmpty {
            saveLocal(e)
            mgr.logmsg("[olib] 校准结果已提升为本地缓存 \(e.offsets.count) 项 (\(e.confidence))")
        }
    }

    /// 把内置硬编码值导出成字典（用于上报和对比）
    func currentHardcoded() -> [String: UInt32] {
        [
            "p_proc_ro": off_proc_p_proc_ro,
            "p_pid": off_proc_p_pid,
            "p_fd": off_proc_p_fd,
            "p_flag": off_proc_p_flag,
            "p_textvp": off_proc_p_textvp,
            "p_name": off_proc_p_name,
            "pr_task": off_proc_ro_pr_task,
            "p_ucred": off_proc_ro_p_ucred,
            "t_tro": off_thread_t_tro,
            "tro_proc": off_thread_ro_tro_proc,
            "ctid": off_thread_ctid,
            "mutex": off_thread_mutex_lck_mtx_data,
            "inp_next": off_inpcb_inp_list_le_next,
            "inp_pcbinfo": off_inpcb_inp_pcbinfo,
            "inp_socket": off_inpcb_inp_socket,
            "so_usecount": off_socket_so_usecount,
            "so_proto": off_socket_so_proto,
        ]
    }

    /// 把服务端/缓存里的值写回全局偏移
    func apply(_ e: OffsetEntry) {
        func set(_ n: String, _ assign: (UInt32) -> Void) {
            if let v = e.offsets[n], v != 0 { assign(v) }
        }
        set("p_proc_ro") { off_proc_p_proc_ro = $0 }
        set("p_pid") { off_proc_p_pid = $0 }
        set("p_fd") { off_proc_p_fd = $0 }
        set("p_flag") { off_proc_p_flag = $0 }
        set("p_textvp") { off_proc_p_textvp = $0 }
        set("p_name") { off_proc_p_name = $0 }
        set("pr_task") { off_proc_ro_pr_task = $0 }
        set("p_ucred") { off_proc_ro_p_ucred = $0 }
        set("t_tro") { off_thread_t_tro = $0 }
        set("tro_proc") { off_thread_ro_tro_proc = $0 }
        set("ctid") { off_thread_ctid = $0 }
        set("mutex") { off_thread_mutex_lck_mtx_data = $0 }
        set("inp_next") { off_inpcb_inp_list_le_next = $0 }
        set("inp_pcbinfo") { off_inpcb_inp_pcbinfo = $0 }
        set("inp_socket") { off_inpcb_inp_socket = $0 }
        set("so_usecount") { off_socket_so_usecount = $0 }
        set("so_proto") { off_socket_so_proto = $0 }
        mgr.logmsg("[olib] 已应用 \(e.offsets.count) 个偏移（来源 \(e.source) / \(e.confidence)）")
    }

    /// 清缓存（调试用）
    func clearCache() {
        let d = UserDefaults.standard.dictionaryRepresentation()
        for k in d.keys where k.hasPrefix("offset.cache.") {
            UserDefaults.standard.removeObject(forKey: k)
        }
        mgr.logmsg("[olib] 本地缓存已清空")
    }
}
