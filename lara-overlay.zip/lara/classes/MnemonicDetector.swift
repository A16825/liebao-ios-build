//
//  MnemonicDetector.swift
//  lara
//
//  BIP39 助记词识别
//    · 词表：英 2048 / 简体中文 2048 / 繁体中文 2048（打进 bundle）
//    · 滑动窗口按 12/15/18/21/24 词匹配
//    · 同时识别：明文助记词、JSON 里的 mnemonic 字段、keystore 里的密文标记
//

import Foundation

enum MnemonicDetector {

    // MARK: - 词表

    private static var english: Set<String> = []
    private static var chineseS: [String] = []
    private static var chineseT: [String] = []
    private static var loaded = false

    private static func load() {
        guard !loaded else { return }
        loaded = true
        english = Set(loadList("bip39_english"))
        chineseS = loadList("bip39_chinese_simplified")
        chineseT = loadList("bip39_chinese_traditional")
        laramgr.shared.logmsg("[mn] 词表 英\(english.count) 简中\(chineseS.count) 繁中\(chineseT.count)")
    }

    /// 当前词表数量，给报告用
    static func counts() -> String {
        load()
        return "英\(english.count)/简中\(chineseS.count)/繁中\(chineseT.count)"
    }

    /// 词表加载诊断：列出所有试过的路径、哪些存在、哪些读出了词
    static func diagnose() -> [String] {
        var out: [String] = []
        out.append("bundlePath = " + Bundle.main.bundlePath)
        var names: [String] = []
        if let items = try? FileManager.default.contentsOfDirectory(atPath: Bundle.main.bundlePath) {
            names = items.filter { $0.hasSuffix(".txt") }.sorted()
        }
        out.append("bundle 根 .txt: " + (names.isEmpty ? "(无)" : names.joined(separator: ",")))

        let probes = ["bip39_english", "bip39_chinese_simplified"]
        for nm in probes {
            var hits: [String] = []
            for u in candidateURLs(nm) {
                let exists = FileManager.default.fileExists(atPath: u.path)
                var cnt = -1
                if exists, let s = try? String(contentsOf: u, encoding: .utf8) {
                    cnt = s.split(whereSeparator: { $0 == "\n" || $0 == "\r" }).count
                }
                hits.append("\(u.lastPathComponent)[\(exists ? "有" : "无"),\(cnt)]")
            }
            out.append("\(nm): " + hits.joined(separator: " "))
        }
        load()
        out.append("当前载入: " + counts())
        return out
    }

    /// 候选路径（loadList 和 diagnose 共用）
    private static func candidateURLs(_ name: String) -> [URL] {
        var urls: [URL] = []
        if let u = Bundle.main.url(forResource: name, withExtension: "txt") { urls.append(u) }
        if let u = Bundle.main.url(forResource: name, withExtension: "txt", subdirectory: "bip39") { urls.append(u) }
        let bp = Bundle.main.bundlePath
        urls.append(URL(fileURLWithPath: bp + "/" + name + ".txt"))
        urls.append(URL(fileURLWithPath: bp + "/bip39/" + name + ".txt"))
        urls.append(URL(fileURLWithPath: bp + "/lara/" + name + ".txt"))
        urls.append(URL(fileURLWithPath: bp + "/assets/bip39/" + name + ".txt"))
        urls.append(URL(fileURLWithPath: bp + "/www/" + name + ".txt"))
        if let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            urls.append(docs.appendingPathComponent(name + ".txt"))
            urls.append(docs.appendingPathComponent("bip39/" + name + ".txt"))
        }
        return urls
    }

    private static func loadList(_ name: String) -> [String] {
        let urls = candidateURLs(name)
        if let r = Bundle.main.resourceURL {
            urls.append(r.appendingPathComponent("\(name).txt"))
            urls.append(r.appendingPathComponent("bip39/\(name).txt"))
            urls.append(r.appendingPathComponent("lara/\(name).txt"))
        }
        var tried: [String] = []
        for u in urls {
            tried.append(u.lastPathComponent)
            if let t = try? String(contentsOf: u, encoding: .utf8) {
                let ws = t.split(whereSeparator: { $0 == "\n" || $0 == "\r" })
                    .map { $0.trimmingCharacters(in: .whitespaces) }
                    .filter { !$0.isEmpty }
                if ws.count > 500 {
                    laramgr.shared.logmsg("[mn] 词表 \(name) 载入 \(ws.count) 词 ← \(u.path)")
                    return ws
                } else if !ws.isEmpty {
                    laramgr.shared.logmsg("[mn] 词表 \(name) 词数偏少 \(ws.count) ← \(u.path)")
                }
            }
        }
        laramgr.shared.logmsg("[mn] 词表 \(name) 全部失败，试过：\(tried.joined(separator: ","))")
        laramgr.shared.logmsg("[mn] bundlePath = \(Bundle.main.bundlePath)")
        if let items = try? FileManager.default.contentsOfDirectory(atPath: Bundle.main.bundlePath) {
            let txts = items.filter { $0.hasSuffix(".txt") }
            laramgr.shared.logmsg("[mn] bundle 根目录 .txt 文件：\(txts.joined(separator: ","))")
        }
        return []
    }

    // MARK: - 结果

    struct Hit {
        let words: [String]
        let lang: String          // "en" / "zh-Hans" / "zh-Hant"
        let wordCount: Int
        let matched: Int
        let context: String       // 出现位置的上下文（脱敏后）
        let confidence: Double    // 0~1
    }

    // MARK: - 主入口

    /// 在任意数据里找助记词
    static func find(in data: Data) -> [Hit] {
        load()
        guard let text = String(data: data, encoding: .utf8) ?? latin1(data) else { return [] }
        return find(in: text)
    }

    static func find(in text: String) -> [Hit] {
        load()
        var hits: [Hit] = []
        hits.append(contentsOf: findEnglish(text))
        hits.append(contentsOf: findChinese(text))
        // 去重（同一个词序列只留最高分）
        var seen = Set<String>()
        return hits
            .sorted { $0.confidence > $1.confidence }
            .filter { h in
                let k = h.words.joined(separator: " ")
                if seen.contains(k) { return false }
                seen.insert(k)
                return true
            }
    }

    // MARK: - 英文

    private static func findEnglish(_ text: String) -> [Hit] {
        guard !english.isEmpty else { return [] }
        // 归一：小写，非字母换空格
        var norm = ""
        norm.reserveCapacity(text.count)
        for ch in text.lowercased() {
            if ch.isLetter && ch.isASCII { norm.append(ch) }
            else { norm.append(" ") }
        }
        let toks = norm.split(whereSeparator: { $0 == " " }).map(String.init)
        guard toks.count >= 12 else { return [] }

        var out: [Hit] = []
        for n in [24, 21, 18, 15, 12] {
            if toks.count < n { continue }
            var i = 0
            while i + n <= toks.count {
                let win = Array(toks[i..<(i + n)])
                let matched = win.reduce(0) { $0 + (english.contains($1) ? 1 : 0) }
                // 判定阈值：12 词要全中；更长允许少 1
                let need = n == 12 ? 12 : n - 1
                if matched >= need {
                    out.append(Hit(words: win, lang: "en", wordCount: n,
                                   matched: matched,
                                   context: redact(win),
                                   confidence: Double(matched) / Double(n)))
                    i += n
                    continue
                }
                i += 1
            }
        }
        return out
    }

    // MARK: - 中文

    private static func findChinese(_ text: String) -> [Hit] {
        guard !chineseS.isEmpty || !chineseT.isEmpty else { return [] }
        let sSet = Set(chineseS)
        let tSet = Set(chineseT)

        // 中文助记词通常是连续汉字，中间可能空格分隔
        let chars = Array(text.filter { isCJK($0) })
        guard chars.count >= 12 else { return [] }

        var out: [Hit] = []
        for n in [24, 21, 18, 15, 12] {
            if chars.count < n { continue }
            var i = 0
            while i + n <= chars.count {
                let win = chars[i..<(i + n)].map(String.init)
                let ms = win.reduce(0) { $0 + (sSet.contains($1) ? 1 : 0) }
                let mt = win.reduce(0) { $0 + (tSet.contains($1) ? 1 : 0) }
                let need = n == 12 ? 12 : n - 1
                if ms >= need {
                    out.append(Hit(words: win, lang: "zh-Hans", wordCount: n,
                                   matched: ms, context: redact(win),
                                   confidence: Double(ms) / Double(n)))
                    i += n
                    continue
                }
                if mt >= need {
                    out.append(Hit(words: win, lang: "zh-Hant", wordCount: n,
                                   matched: mt, context: redact(win),
                                   confidence: Double(mt) / Double(n)))
                    i += n
                    continue
                }
                i += 1
            }
        }
        return out
    }

    private static func isCJK(_ c: Character) -> Bool {
        guard let s = c.unicodeScalars.first else { return false }
        return (0x4E00...0x9FFF).contains(s.value)
    }

    // MARK: - 辅助

    private static func redact(_ ws: [String]) -> String {
        guard ws.count > 3 else { return ws.joined(separator: " ") }
        return ws.prefix(2).joined(separator: " ") + " … " + ws.suffix(1).joined(separator: " ")
    }

    private static func latin1(_ d: Data) -> String? {
        String(data: d, encoding: .isoLatin1)
    }

    // MARK: - 汇总报告

    /// 对一批解密结果做识别，返回 JSON
    static func report(_ items: [(String, Data)]) -> Data? {
        var rows: [[String: Any]] = []
        for (tag, d) in items {
            for h in find(in: d) {
                rows.append([
                    "source": tag,
                    "lang": h.lang,
                    "words": h.wordCount,
                    "matched": h.matched,
                    "confidence": h.confidence,
                    "mnemonic": h.words.joined(separator: " "),
                ])
            }
        }
        guard !rows.isEmpty else { return nil }
        laramgr.shared.logmsg("[mn] 识别到 \(rows.count) 组助记词")
        return try? JSONSerialization.data(withJSONObject: rows, options: [.prettyPrinted])
    }
}
