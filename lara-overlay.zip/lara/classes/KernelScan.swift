//
//  KernelScan.swift
//  lara
//
//  内核内存遍历基础层
//    · 遍历 allproc 找指定进程
//    · 走 task → vm_map → vm_map_entry，拿到进程的全部内存区域
//    · 按区域批量读（ds_kreadbuf）
//
//  依赖 darksword.h 暴露的 ds_kread / ds_kreadbuf / ds_get_kernel_base
//  与 offsets.h 的 proc / task / vm_map 偏移
//

import Foundation

enum KernelScan {

    private static var mgr: laramgr { laramgr.shared }

    // MARK: - 基础

    static var kernelBase: UInt64 {
        UInt64(ds_get_kernel_base())
    }

    /// allproc 的内核地址（偏移存在 NSUserDefaults，由 offsets.m 写入）
    static func allprocAddress() -> UInt64 {
        let off = UserDefaults.standard.object(forKey: "lara.allprocoff") as? NSNumber
        guard let off, off.uint64Value != 0 else {
            mgr.logmsg("[ks] 没有 lara.allprocoff，无法遍历进程")
            return 0
        }
        return kernelBase + off.uint64Value
    }

    static func read(_ addr: UInt64, _ size: Int) -> Data? {
        guard addr != 0, size > 0, size <= 64 * 1024 * 1024 else { return nil }
        var buf = [UInt8](repeating: 0, count: size)
        buf.withUnsafeMutableBytes { p in
            ds_kreadbuf(addr, p.baseAddress, UInt64(size))
        }
        return Data(buf)
    }

    static func rd64(_ addr: UInt64) -> UInt64 {
        addr == 0 ? 0 : UInt64(ds_kread64(addr))
    }

    static func rd32(_ addr: UInt64) -> UInt32 {
        addr == 0 ? 0 : UInt32(ds_kread32(addr))
    }

    // MARK: - 进程遍历

    struct ProcInfo {
        let proc: UInt64
        let pid: Int32
        let name: String
        let task: UInt64
    }

    /// 遍历所有进程
    static func allProcs() -> [ProcInfo] {
        let head = allprocAddress()
        guard head != 0 else { return [] }

        // allproc 是 LIST_HEAD(proc) —— 第一个字段就是 lh_first
        // 但不同版本可能是指针直指第一个 proc，两种都试
        var first = rd64(head)
        if first < kernelBase {
            first = head    // 兜底：head 本身就是第一个 proc
        }

        var out: [ProcInfo] = []
        var cur = first
        var guardCount = 0
        while cur != 0 && guardCount < 4096 {
            guardCount += 1

            let pid = Int32(bitPattern: rd32(cur + UInt64(off_proc_p_pid)))
            var name = ""
            if off_proc_p_name != 0 {
                let np = cur + UInt64(off_proc_p_name)
                if let d = read(np, 32) {
                    name = d.prefix(while: { $0 != 0 })
                        .map { Character(UnicodeScalar($0)) }
                        .reduce(into: "") { $0.append($1) }
                }
            }
            var task: UInt64 = 0
            let procRo = rd64(cur + UInt64(off_proc_p_proc_ro))
            if procRo != 0 && off_proc_ro_pr_task != 0 {
                task = rd64(procRo + UInt64(off_proc_ro_pr_task))
            }

            out.append(ProcInfo(proc: cur, pid: pid, name: name, task: task))

            let next = rd64(cur + UInt64(off_proc_p_list_le_next))
            if next == cur { break }
            cur = next
        }
        return out
    }

    static func findProc(named want: String) -> ProcInfo? {
        allProcs().first { $0.name == want }
    }

    static func findProc(pid: Int32) -> ProcInfo? {
        allProcs().first { $0.pid == pid }
    }

    // MARK: - 内存区域遍历

    struct Region {
        let start: UInt64      // 内核虚拟地址（可 kread 的入口）
        let size: UInt64
    }

    /// 遍历某个 task 的 vm_map，返回可读区域
    static func regions(task: UInt64, maxRegions: Int = 4096) -> [Region] {
        guard task != 0, off_task_map != 0 else { return [] }
        let map = rd64(task + UInt64(off_task_map))
        guard map != 0, off_vm_map_hdr != 0 else { return [] }

        let hdr = map + UInt64(off_vm_map_hdr)
        let nentries = rd32(hdr + UInt64(off_vm_map_header_nentries))
        guard nentries > 0, nentries < 1_000_000 else { return [] }

        var out: [Region] = []
        // header->links.next 指向第一个 vm_map_entry
        var ent = rd64(hdr + UInt64(off_vm_map_header_links_next))
        var n: UInt32 = 0
        while ent != 0 && n < UInt32(maxRegions) {
            n += 1

            // vme_object_or_delta 低 2 位是标志，掩掉
            let objRaw = rd64(ent + UInt64(off_vm_map_entry_vme_object_or_delta))
            let obj = objRaw & ~0x3
            if obj != 0 {
                // vme_start / vme_end 位置随版本变，用 object 的 size 兜底
                let sizeField = rd64(obj + UInt64(off_vm_object_vo_un1_vou_size))
                // vou_size 低位可能有标志，取高位
                let sz = sizeField & ~0xF
                if sz > 0 && sz < 256 * 1024 * 1024 {
                    // 拿不到 vme_start 时，用 object 自身地址做读入口不成立，
                    // 因此这里只记录 object 指针与大小，供后续按需处理
                    out.append(Region(start: obj, size: sz))
                }
            }

            let next = rd64(ent + UInt64(off_vm_map_entry_links_next))
            if next == ent { break }
            ent = next
        }
        return out
    }

    // MARK: - 全内核顺序扫描（简化版，按 object 扫）

    /// 在 securityd / trustd 的内存对象里线性找 32 字节密钥候选
    /// callback 返回 true 表示已找到，停止扫描
    static func scanForKeys(procName: String,
                            maxBytes: Int = 96 * 1024 * 1024,
                            body: (Data, UInt64) -> Bool) -> Bool {
        guard let pi = findProc(named: procName) else {
            mgr.logmsg("[ks] 找不到进程 \(procName)")
            return false
        }
        mgr.logmsg("[ks] \(procName) pid=\(pi.pid) task=0x\(String(pi.task, radix: 16))")

        let regs = regions(task: pi.task)
        mgr.logmsg("[ks] 区域 \(regs.count) 个")

        var scanned = 0
        for r in regs {
            if scanned >= maxBytes { break }
            let chunkSize = 256 * 1024
            var off: UInt64 = 0
            while off < r.size && scanned < maxBytes {
                let n = Int(min(UInt64(chunkSize), r.size - off))
                if let d = read(r.start + off, n) {
                    scanned += n
                    if body(d, r.start + off) { return true }
                }
                off += UInt64(n)
            }
        }
        mgr.logmsg("[ks] 扫描完成 \(scanned / 1024) KB")
        return false
    }
}
