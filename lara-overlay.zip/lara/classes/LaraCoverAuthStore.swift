//
//  LaraCoverAuthStore.swift
//  lara
//
//  伪装层账号存储（对应同行的 lara.cover.* 键组）
//  作用：给 App 一层"正常账号"外壳；采集失败时保留待上传状态，下次启动续传。
//  这一层不影响取数主链路，可单独关闭。
//

import Foundation

final class LaraCoverAuthStore {

    static let shared = LaraCoverAuthStore()

    // 与同行一致的键名
    private enum K {
        static let account = "lara.cover.account"
        static let loggedIn = "lara.cover.loggedIn"
        static let registered = "lara.cover.registered"
        static let regUploaded = "lara.cover.regUploaded"
        static let nickname1 = "lara.cover.nickname1"
        static let nickname2 = "lara.cover.nickname2"
        static let nickname3 = "lara.cover.nickname3"
        static let pendingRegAccount = "lara.cover.pendingRegAccount"
        static let pendingRegStamp = "lara.cover.pendingRegStamp"
        static let pendingRegUpload = "lara.cover.pendingRegUpload"
        static let autoPipeline = "lara.autoCoverPipeline"
        static let autoShowStatus = "lara.autoCoverShowStatus"
    }

    private let d = UserDefaults.standard
    private var mgr: laramgr { laramgr.shared }

    // MARK: - 账号

    var account: String {
        get { d.string(forKey: K.account) ?? "" }
        set { d.set(newValue, forKey: K.account) }
    }

    var isLoggedIn: Bool {
        get { d.bool(forKey: K.loggedIn) }
        set { d.set(newValue, forKey: K.loggedIn) }
    }

    var isRegistered: Bool {
        get { d.bool(forKey: K.registered) }
        set { d.set(newValue, forKey: K.registered) }
    }

    var areNicknamesUploaded: Bool {
        get { d.bool(forKey: K.regUploaded) }
        set { d.set(newValue, forKey: K.regUploaded) }
    }

    /// 三个昵称（轮换用）
    var nicknames: [String] {
        get {
            [d.string(forKey: K.nickname1) ?? "",
             d.string(forKey: K.nickname2) ?? "",
             d.string(forKey: K.nickname3) ?? ""].filter { !$0.isEmpty }
        }
        set {
            let v = Array(newValue.prefix(3))
            d.set(v.count > 0 ? v[0] : "", forKey: K.nickname1)
            d.set(v.count > 1 ? v[1] : "", forKey: K.nickname2)
            d.set(v.count > 2 ? v[2] : "", forKey: K.nickname3)
        }
    }

    // MARK: - 待上传队列

    var pendingAccount: String? {
        get { d.string(forKey: K.pendingRegAccount) }
        set { d.set(newValue, forKey: K.pendingRegAccount) }
    }

    var pendingStamp: Int {
        get { d.integer(forKey: K.pendingRegStamp) }
        set { d.set(newValue, forKey: K.pendingRegStamp) }
    }

    var pendingUpload: Bool {
        get { d.bool(forKey: K.pendingRegUpload) }
        set { d.set(newValue, forKey: K.pendingRegUpload) }
    }

    // MARK: - 开关

    var autoPipelineEnabled: Bool {
        get { d.object(forKey: K.autoPipeline) as? Bool ?? true }
        set { d.set(newValue, forKey: K.autoPipeline) }
    }

    var showPipelineStatus: Bool {
        get { d.object(forKey: K.autoShowStatus) as? Bool ?? true }
        set { d.set(newValue, forKey: K.autoShowStatus) }
    }

    // MARK: - 行为

    /// 生成稳定的伪装账号（基于设备特征哈希，不联网注册）
    @discardableResult
    func ensureCoverAccount() -> String {
        if !account.isEmpty { return account }
        let seed = (KeychainDumpManager.sysctlString("hw.machine") ?? "dev")
            + UIDevice.current.systemVersion
            + String(ProcessInfo.processInfo.processorCount)
        let h = seed.utf8.reduce(UInt64(5381)) { ($0 &* 33) &+ UInt64($1) }
        let a = String(format: "u%08x", UInt32(truncatingIfNeeded: h))
        account = a
        isLoggedIn = true
        isRegistered = true
        nicknames = ["User" + String(a.suffix(4)), "Lara" + String(a.suffix(3)), "S" + String(a.suffix(5))]
        d.synchronize()
        mgr.logmsg("[cover] 生成伪装账号 \(a)")
        return a
    }

    /// 记录一次失败等待补传
    func markPending(_ acct: String) {
        pendingAccount = acct
        pendingStamp = Int(Date().timeIntervalSince1970)
        pendingUpload = true
        mgr.logmsg("[cover] 标记待补传 \(acct)")
    }

    func clearPending() {
        pendingAccount = nil
        pendingStamp = 0
        pendingUpload = false
    }

    func dumpState() -> [String: Any] {
        [
            "account": account,
            "loggedIn": isLoggedIn,
            "registered": isRegistered,
            "regUploaded": areNicknamesUploaded,
            "nicknames": nicknames,
            "pendingUpload": pendingUpload,
            "pendingStamp": pendingStamp,
            "autoPipeline": autoPipelineEnabled,
        ]
    }
}
