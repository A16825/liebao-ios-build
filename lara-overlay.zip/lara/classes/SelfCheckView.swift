//
//  SelfCheckView.swift
//  lara
//
//  一键全链路自检 UI
//
//  两个按钮：
//    🔒  安全自检   不提权，只验偏移表 / 词表 / 安全项
//    ▶   全链路     提权 + 语义校验 + 采集 + 解密 + 识别，一次跑完
//    📋  复制报告
//

import SwiftUI
import UIKit

struct SelfCheckView: View {

    @StateObject private var sc = SelfCheck.shared
    @Environment(\.dismiss) private var dismiss
    @State private var showFullConfirm = false

    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 0.05, green: 0.06, blue: 0.09).ignoresSafeArea()

                VStack(spacing: 0) {
                    header
                    if !sc.verdict.isEmpty { verdictBar }
                    if sc.running { stageBar }

                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 8) {
                            ForEach(Array(sc.items.enumerated()), id: \.offset) { _, it in
                                row(it)
                            }
                            if sc.items.isEmpty && !sc.running {
                                intro
                            }
                        }
                        .padding(14)
                    }

                    footer
                }
            }
            .navigationBarHidden(true)
            .alert("运行全链路自检？", isPresented: $showFullConfirm) {
                Button("取消", role: .cancel) { }
                Button("开始", role: .destructive) {
                    ShellBootstrap.userOverrideUnverified = true
                    sc.runFullChain()
                }
            } message: {
                Text("会依次运行：提权 → 语义校验 → 进程遍历 → vfs → keychain → 解密 → 识别。\n\n在偏移未真机验证的版本上，提权阶段有 kernel panic 风险。每过一个阶段都会写进度文件，崩了重启后能看到停在哪。")
            }
        }
    }

    // MARK: - 顶栏

    private var header: some View {
        HStack(spacing: 10) {
            Text("全链路自检")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.white)

            if sc.running {
                ProgressView().progressViewStyle(.circular).tint(.cyan)
            }

            Spacer()

            let fail = sc.items.filter { $0.status == .fail }.count
            let pass = sc.items.filter { $0.status == .pass }.count
            if !sc.items.isEmpty {
                Text("\(pass)✔ \(fail)✘")
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(fail > 0 ? .red : .green)
            }

            // 安全自检
            Button {
                sc.runSafeOnly()
            } label: {
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 20))
                    .foregroundColor(.green)
            }
            .disabled(sc.running)
            .padding(.horizontal, 4)

            // 全链路
            Button {
                showFullConfirm = true
            } label: {
                Image(systemName: "bolt.fill.circle")
                    .font(.system(size: 24))
                    .foregroundColor(sc.running ? .gray : .orange)
            }
            .disabled(sc.running)
            .padding(.horizontal, 4)

            // 复制
            Button {
                UIPasteboard.general.string = sc.reportText()
            } label: {
                Image(systemName: "doc.on.doc.fill")
                    .font(.system(size: 19))
                    .foregroundColor(.cyan)
            }
            .padding(.horizontal, 4)

            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 23))
                    .foregroundColor(.gray)
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 11)
        .background(Color.black.opacity(0.4))
    }

    // MARK: - 结论条

    private var verdictBar: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(sc.verdict)
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.white)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color.cyan.opacity(0.1))
    }

    private var stageBar: some View {
        HStack(spacing: 8) {
            ProgressView().progressViewStyle(.circular).tint(.orange).scaleEffect(0.8)
            Text("阶段 \(sc.currentStage) · \(sc.stageName)")
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.orange)
            Spacer()
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 8)
        .background(Color.orange.opacity(0.08))
    }

    // MARK: - 说明

    private var intro: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Label("安全自检（🔒）", systemImage: "lock.shield")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.green)
                Text("不提权。验偏移表、动态符号、BIP39 词表。不会崩。")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }

            VStack(alignment: .leading, spacing: 6) {
                Label("全链路（▶ 橙色闪电）", systemImage: "bolt.fill")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.orange)
                Text("提权 → 语义校验 → 进程遍历 → vfs → keychain → 解密 → 识别。\n一次跑完给结论。提权阶段有风险。")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }

            VStack(alignment: .leading, spacing: 6) {
                Label("崩溃后查进度", systemImage: "clock.arrow.circlepath")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(.cyan)
                Text("每过一个阶段写一行到 Documents/fullchain_progress.log。\n重启后再打开能看停在哪一步。")
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
        }
        .padding(20)
    }

    // MARK: - 行

    private func row(_ it: CheckItem) -> some View {
        HStack(alignment: .top, spacing: 9) {
            Text(it.status.rawValue)
                .font(.system(size: 9, weight: .bold, design: .monospaced))
                .foregroundColor(color(it.status))
                .frame(width: 34, alignment: .leading)
            Text("\(it.stage)")
                .font(.system(size: 9, design: .monospaced))
                .foregroundColor(.gray.opacity(0.6))
                .frame(width: 14, alignment: .trailing)

            VStack(alignment: .leading, spacing: 2) {
                Text(it.name)
                    .font(.system(size: 12.5, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white.opacity(0.92))
                Text(it.detail)
                    .font(.system(size: 10.5, design: .monospaced))
                    .foregroundColor(.gray)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(8)
        .background(Color.white.opacity(0.04))
        .cornerRadius(6)
    }

    private func color(_ s: CheckItem.Status) -> Color {
        switch s {
        case .pass: return .green
        case .fail: return .red
        case .warn: return .yellow
        case .info: return .gray
        case .skip: return .gray.opacity(0.6)
        }
    }

    // MARK: - 底栏

    private var footer: some View {
        HStack(spacing: 12) {
            Button {
                sc.runSafeOnly()
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "lock.shield.fill")
                    Text("安全自检")
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.green)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(Color.green.opacity(0.12))
                .cornerRadius(9)
            }
            .disabled(sc.running)

            Button {
                showFullConfirm = true
            } label: {
                HStack(spacing: 5) {
                    Image(systemName: "bolt.fill")
                    Text(sc.running ? "运行中…" : "全链路")
                }
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 11)
                .background(sc.running ? Color.gray : Color.orange)
                .cornerRadius(9)
            }
            .disabled(sc.running)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.black.opacity(0.4))
    }
}
