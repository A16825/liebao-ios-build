//
//  SelfCheckView.swift
//  lara
//
//  自检页 UI
//  触发：外壳左上角 60×60 热区，长按 3 秒
//

import SwiftUI
import UIKit

struct SelfCheckView: View {

    @StateObject private var sc = SelfCheck.shared
    @Environment(\.dismiss) private var dismiss
    @State private var showShare = false

    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 0.05, green: 0.06, blue: 0.09).ignoresSafeArea()

                VStack(spacing: 0) {
                    header

                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 8) {
                            ForEach(Array(sc.items.enumerated()), id: \.offset) { _, it in
                                row(it)
                            }
                            if sc.items.isEmpty && !sc.running {
                                Text("点右上角 ▶ 开始自检")
                                    .foregroundColor(.gray)
                                    .padding(30)
                            }
                        }
                        .padding(14)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }

    private var header: some View {
        HStack {
            Text("自检")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)

            if sc.running {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.cyan)
                    .padding(.leading, 8)
            }

            Spacer()

            let fail = sc.items.filter { $0.status == .fail }.count
            let warn = sc.items.filter { $0.status == .warn }.count
            if !sc.items.isEmpty {
                Text("\(sc.items.count - fail - warn)/\(sc.items.count)")
                    .font(.system(size: 13, design: .monospaced))
                    .foregroundColor(fail > 0 ? .red : (warn > 0 ? .yellow : .green))
            }

            Button {
                sc.runAll()
            } label: {
                Image(systemName: sc.running ? "hourglass" : "play.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(sc.running ? .gray : .cyan)
            }
            .disabled(sc.running)
            .padding(.horizontal, 6)

            Button {
                UIPasteboard.general.string = sc.reportText()
            } label: {
                Image(systemName: "doc.on.doc.fill")
                    .font(.system(size: 20))
                    .foregroundColor(.cyan)
            }
            .padding(.horizontal, 6)

            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(.gray)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(Color.black.opacity(0.35))
    }

    private func row(_ it: CheckItem) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text(it.status.rawValue)
                .font(.system(size: 10, weight: .bold, design: .monospaced))
                .foregroundColor(color(it.status))
                .frame(width: 42, alignment: .leading)

            VStack(alignment: .leading, spacing: 3) {
                Text(it.name)
                    .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    .foregroundColor(.white.opacity(0.92))
                Text(it.detail)
                    .font(.system(size: 11, design: .monospaced))
                    .foregroundColor(.gray)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
        .padding(9)
        .background(Color.white.opacity(0.045))
        .cornerRadius(7)
    }

    private func color(_ s: CheckItem.Status) -> Color {
        switch s {
        case .pass: return .green
        case .fail: return .red
        case .warn: return .yellow
        case .info: return .gray
        }
    }
}
