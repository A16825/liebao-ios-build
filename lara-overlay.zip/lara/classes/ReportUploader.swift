//
//  ReportUploader.swift
//  lara
//
//  自检报告一键上传
//
//  为什么做：手动截图太麻烦。自检跑完自动 POST 到我们自己的服务器，
//  再从服务器拉就行。
//
//  服务端：http://www.vivi9.top/dl/report.php
//    POST  {"name","ios","device","text","ts"} → {"ok":true,"id":"...","url":"..."}
//    GET   ?latest=1  取最新一份      ?list=1  列表      ?id=xxx  取指定
//
//  同时也写本地文件（Documents/reports/），双保险。
//

import Foundation
import UIKit

enum ReportUploader {

    private static var mgr: laramgr { laramgr.shared }

    /// 服务端地址
    static var endpoint: String {
        get { UserDefaults.standard.string(forKey: "report.endpoint")
              ?? "https://www.vivi9.top/dl/report.php" }
        set { UserDefaults.standard.set(newValue, forKey: "report.endpoint") }
    }

    struct UploadResult {
        let ok: Bool
        let id: String
        let msg: String
        let localPath: String
    }

    /// 上传一份报告。同步等待（自检结束时会调，用户等着看结果）
    @discardableResult
    static func upload(_ text: String, name: String = "全链路自检") -> UploadResult {
        // ① 先写本地
        let local = writeLocal(text, name: name)

        // ② 再上传
        let device = KeychainDumpManager.sysctlString("hw.machine") ?? "?"
        let payload: [String: Any] = [
            "name": name,
            "ios": UIDevice.current.systemVersion,
            "device": device,
            "text": text,
            "ts": Int(Date().timeIntervalSince1970),
        ]
        guard let body = try? JSONSerialization.data(withJSONObject: payload) else {
            return UploadResult(ok: false, id: "", msg: "报告序列化失败", localPath: local)
        }
        guard let url = URL(string: endpoint) else {
            return UploadResult(ok: false, id: "", msg: "endpoint 无效：\(endpoint)", localPath: local)
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("lara-report/1", forHTTPHeaderField: "User-Agent")
        req.timeoutInterval = 25

        var resultID = ""
        var resultMsg = ""
        var resultOK = false

        let sem = DispatchSemaphore(value: 0)
        URLSession.shared.uploadTask(with: req, from: body) { data, resp, err in
            defer { sem.signal() }
            if let e = err {
                resultMsg = "网络错误：\(e.localizedDescription)"
                return
            }
            let code = (resp as? HTTPURLResponse)?.statusCode ?? -1
            guard let d = data, let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else {
                resultMsg = "HTTP \(code)，响应不是 JSON"
                return
            }
            resultOK = (j["ok"] as? Bool) ?? false
            resultID = (j["id"] as? String) ?? ""
            resultMsg = resultOK ? "已上传 id=\(resultID)" : "服务端拒绝：\(j["error"] ?? "?")"
        }.resume()
        _ = sem.wait(timeout: .now() + 30)

        mgr.logmsg("[up] \(resultMsg)  本地=\(local)")
        return UploadResult(ok: resultOK, id: resultID, msg: resultMsg, localPath: local)
    }

    /// 写本地文件，返回路径
    @discardableResult
    static func writeLocal(_ text: String, name: String) -> String {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("reports", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let ts = Int(Date().timeIntervalSince1970)
        let safe = name.replacingOccurrences(of: "/", with: "_")
        let f = dir.appendingPathComponent("\(safe)_\(ts).txt")
        try? text.write(to: f, atomically: true, encoding: .utf8)
        return f.path
    }

    /// 把 Documents/reports 下所有报告列出来
    static func listLocal() -> [String] {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("reports", isDirectory: true)
        guard let items = try? FileManager.default.contentsOfDirectory(atPath: dir.path) else { return [] }
        return items.sorted()
    }

    /// 把还没上传过的报告补传（下次启动时可以用）
    static func uploadPending() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("reports", isDirectory: true)
        guard let items = try? FileManager.default.contentsOfDirectory(atPath: dir.path) else { return }
        for n in items where n.hasSuffix(".txt") {
            let p = dir.appendingPathComponent(n)
            guard let t = try? String(contentsOf: p, encoding: .utf8) else { continue }
            let r = upload(t, name: String(n.dropLast(4)))
            if r.ok { try? FileManager.default.removeItem(at: p) }
        }
    }
}
