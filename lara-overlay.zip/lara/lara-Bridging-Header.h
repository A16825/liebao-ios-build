//
//  lara-Bridging-Header.h
//  lara
//

@import UIKit;
#import <Foundation/Foundation.h>

#import "darksword.h"
#import "offsets.h"
#import "utils.h"
#import "vnode.h"
#import "apfs.h"
#import "vfs.h"
#import "sbx.h"
#import "IconServices.h"
#import "rc.h"
#import "RemoteCall.h"
#import "decrypt.h"
#import "persistence.h"
#import "ota.h"
#import "screentime.h"

// 沙盒逃逸（iOS 26.x / 27.x 可用，不需要越狱、不需要内核漏洞）
#import "exploits/worse_query.h"
#import "exploits/pathleak.h"

// 参数矩阵探测器：找出哪一组 (class, identifier, flags) 不需要 App Group 也能签 extension
// 返回逐组结果，每行 "class|identifier|flags|result"，遇到第一个 OK 就停
extern NSString *wq_matrix(NSString *target, NSString *cachesPath,
                           NSString *bundleId, NSString *appGroup);
// 单组尝试，返回 >=0 的 token 句柄表示成功
extern int64_t wq_try(NSString *target, NSString *cachesPath,
                      uint64_t cls, NSString *identifier,
                      uint64_t flags, BOOL verbose);

// SecTask：读自己的 entitlements 拿 App Group（私有 API，手动声明）
typedef struct __SecTask *SecTaskRef;
extern SecTaskRef SecTaskCreateFromSelf(CFAllocatorRef allocator);
extern CFTypeRef SecTaskCopyValueForEntitlement(SecTaskRef task,
                                                CFStringRef entitlement,
                                                CFErrorRef *error);

#import <zlib.h>

long findcachedataoff(const char *mgkey);
void LaraClearIconCache(void);

@interface UIDevice(Private)
+ (BOOL)_hasHomeButton;
@end

void test(NSString *path);

NS_ASSUME_NONNULL_BEGIN

@interface VarCleanBridge : NSObject

+ (NSDictionary *)loadRulesNamed:(NSString *)resourceName
                        inBundle:(NSBundle *)bundle
                           error:(NSError * _Nullable * _Nullable)error;

+ (BOOL)probePathExists:(NSString *)path
            isDirectory:(BOOL *)isDirectory
              isSymlink:(BOOL *)isSymlink;

@end

NS_ASSUME_NONNULL_END
